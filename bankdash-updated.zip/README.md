# BankDash — Admin Dashboard (Next.js)

This project turns the Figma file **Admin-Dashboard-UI** into code, with layouts for desktop (1440px), tablet (1024px) and mobile (375px). It also adds Login, Signup and Forgot Password pages, which the Figma file does not include. They use the same design language.

Figma: `https://www.figma.com/design/ruNJ0MAU3jKcGAPbZej5nG/Admin-Dashboard-UI`

---

## Stack

| Concern    | Choice |
|------------|--------|
| Framework  | Next.js 15 (App Router, React 19, TypeScript) |
| Styling    | Tailwind CSS v4. Design tokens live in `src/app/globals.css` (`@theme`) |
| UI kit     | shadcn/ui (new-york): chart, button, input, label, card, checkbox, switch, table, tabs, avatar, separator, sheet, select, popover, calendar, dialog, alert-dialog, dropdown-menu, command, sonner, input-otp, radio-group, textarea, tooltip, badge, scroll-area, form |
| State      | Zustand (persisted to localStorage) — `src/lib/store.ts` |
| Dates      | date-fns + react-day-picker (shadcn Calendar) |
| Charts     | shadcn **Chart** (`ChartContainer`, `ChartTooltip`) + Recharts 3 |
| Animation  | Framer Motion 11 |
| Fonts      | Inter, Lato and Montserrat via `@fontsource/*`, bundled locally with no Google Fonts network call |
| Icons      | Custom SVG components (`src/components/**/icons.tsx`) plus a few from lucide-react |

---

## Getting started

```bash
npm install
npm run dev        # http://localhost:3000
npm run build && npm start
npm run lint
```

Requires Node 18.18+ (tested on Node 22).

---

## Routes

| Route | Page | Figma frame (desktop / tablet / mobile) |
|---|---|---|
| `/` | Dashboard (Overview) | Main Dashboard / Dashboard for Tab / Dashboard for Mobile |
| `/transactions` | Transactions | Transaction / Transaction for Tab / … for Mobile |
| `/accounts` | Accounts | Accounts / Accounts Tab / … for Mobile |
| `/investments` | Investments | Investments / Investments Tab / … for Mobile |
| `/credit-cards` | Credit Cards | Credit Cards / Credit Cards Tab / … for Mobile |
| `/loans` | Loans | Loan / Loans Tab / Loans for Mobile |
| `/services` | Services | Services / Services Tab / … for Mobile |
| `/settings` | Setting: Edit Profile tab | Setting Page 1 |
| `/settings?tab=preferences` | Setting: Preferences tab | Setting Page 2 |
| `/settings?tab=security` | Setting: Security tab | Setting Page 3 |
| `/privileges` | My Privileges | *Not in Figma*. Built from the same components so the nav link works |
| `/login` | Sign In | *Not in Figma*. New design |
| `/signup` | Sign Up | *Not in Figma*. New design |
| `/forgot-password` | Forgot Password (email → OTP → new password → done) | *Not in Figma*. New design |

---

## Project structure

```
src/
├─ app/
│  ├─ layout.tsx                 # fonts + globals
│  ├─ globals.css                # Tailwind v4 theme: BankDash tokens + shadcn vars
│  ├─ not-found.tsx
│  ├─ (auth)/                    # login, signup, forgot-password (no sidebar)
│  └─ (dashboard)/               # sidebar + header shell
│     ├─ layout.tsx
│     ├─ page.tsx                # Dashboard
│     └─ transactions | accounts | investments | credit-cards | loans | services | settings | privileges
├─ components/
│  ├─ ui/                        # shadcn/ui primitives (chart.tsx = shadcn Chart)
│  ├─ layout/                    # sidebar, header (search, icons, mobile drawer), nav config
│  ├─ shared/                    # BankCard, Section/Panel, Logo, motion helpers
│  ├─ auth/                      # AuthShell, fields, forms, forgot-password flow
│  ├─ dashboard/ transactions/ accounts/ investments/ credit-cards/ loans/ services/ settings/
│  └─ icons.tsx                  # shared SVG icon set
├─ hooks/use-breakpoint.ts       # JS breakpoint for chart bar sizes
└─ lib/utils.ts                  # cn()
public/images/avatars/           # photos exported from Figma
design-reference/                # Figma screenshots (desktop/tablet/mobile) for each page, to diff against
```

---

## Design tokens

Defined in `src/app/globals.css` and used as Tailwind classes such as `text-bd-primary` and `bg-bd-page`.

| Token | Hex | Use |
|---|---|---|
| `bd-primary` | `#343C6A` | Headings (Figma "Primary 2") |
| `bd-blue` | `#2D60FF` | Active nav, links ("Primary 3") |
| `bd-royal` | `#1814F3` | Buttons, bars, lines |
| `bd-teal` | `#16DBCC` | Secondary bars, toggles |
| `bd-pink` | `#FE5C73` | Notification ("Secondery") |
| `bd-green` / `bd-red` | `#41D4A8` / `#FF4B4A` | +/− amounts |
| `bd-text` | `#232323` | Body text |
| `bd-muted` | `#718EBF` | Labels, axis, secondary text |
| `bd-nav` | `#B1B1B1` | Inactive nav |
| `bd-page` | `#F5F7FA` | Page background |
| `bd-input` | `#EDF1F7` | Pill inputs |
| `bd-border` / `bd-card-border` | `#E6EFF5` / `#DFEAF2` | Dividers, input borders |

**Typography:** Inter is used for all UI text. The Figma text styles:

| Style | Spec |
|---|---|
| Heading one | 28 / Semi Bold |
| Heading two | 22 / Semi Bold |
| Heading three | 18 / Medium |
| Body one | 16 / Regular |
| Body two | 15 / Regular |

Lato is used for bank-card text.

**Radius / shadow:** cards use 25px at desktop, 20px at tablet and 15px at mobile. Shadow 1 is `4px 4px 18px -2px rgba(231,228,232,.8)` (`shadow-bd`).

## Breakpoints

| Figma frame | Tailwind | Sidebar |
|---|---|---|
| Mobile 375 | default | hidden; hamburger opens a shadcn `Sheet` drawer |
| Tablet 1024 | `lg:` | 231px |
| Desktop 1440 | `xl:` | 250px |

Desktop sizes are exact Figma pixel values. Grid columns use `fr` ratios taken from the Figma widths, so 1280–1440px scales proportionally.

---

## Charts (shadcn Chart + Recharts)

| Page | Chart | Recharts type |
|---|---|---|
| Dashboard | Weekly Activity | `BarChart`, rounded 15px bars |
| Dashboard | Expense Statistics | `PieChart` with a custom exploded-sector `shape` |
| Dashboard | Balance History | `AreaChart`, natural curve + gradient |
| Transactions | My Expense | `BarChart`, highlighted active month |
| Accounts | Debit & Credit Overview | `BarChart` |
| Investments | Yearly Total Investment | `LineChart` |
| Investments | Monthly Revenue | `LineChart` |
| Credit Cards | Card Expense Statistics | `PieChart` with varying radii |

Every chart is wrapped in `ChartContainer` with a `ChartConfig`, so colours come from CSS variables and the tooltips are shadcn `ChartTooltipContent`.

## Animations (Framer Motion)

- **Page transitions:** fade/slide on each route change (`PageTransition` in the dashboard layout).
- **Staggered entrance:** sections enter one after another via `<Stagger>` + `<FadeUp>` / `<Section>`; list and table rows via `listContainer` / `listItem`.
- **Sidebar:** the active indicator slides between items (shared `layoutId`), items enter in sequence, and hovering nudges the item.
- **Header:** the page title cross-fades; the icon buttons rotate and press.
- **Bank cards:** 3D tilt and a shine sweep on hover.
- **Panels:** lift on hover.
- **Charts:** Recharts entry animations; the pie slice pops out on hover.
- **Number counters:** `<CountUp>` animates numbers up on the Accounts and Investments stats.
- **Settings tabs:** the underline slides between tabs (`layoutId`); content cross-fades.
- **Buttons:** Quick Transfer "Send" has a fly-out animation; Save shows saving → saved.
- **Auth pages:**
  - floating cards on the brand panel and a rotating decorative ring;
  - a shake on validation errors;
  - an animated password-strength meter;
  - forgot-password steps slide between each other; the OTP inputs enter in sequence.
- **Reduced motion:** honoured via `prefers-reduced-motion`.

## Auth pages (new)

All three pages share `AuthShell`. On desktop and tablet it is a split layout: a brand panel on the left (blue card gradient, floating `BankCard`s) and the form on the right. On mobile the form appears alone below the logo. The inputs reuse the Setting-page field style (50px height, `#DFEAF2` border, 15px radius, `#1814F3` buttons).

| Page | What it does |
|---|---|
| **Login** | Email + password (show/hide), remember-me, forgot link, Google button, validation. Redirects to `/` on success. |
| **Signup** | Full name, email, password + strength meter, confirm password, terms checkbox. |
| **Forgot Password** | 4 steps: email → 6-digit OTP (auto-advance, paste, resend countdown) → new password → success. |

The API calls are stubbed with `setTimeout`. Search for `TODO: replace` to wire up your backend (for example NextAuth or your own API).

---

---

## Functionality

Everything clickable works. **No native form controls are used.** Selects, dates, checkboxes, OTP, radios, switches and dialogs are all shadcn components, wrapped in BankDash styling in `src/components/shared/form-controls.tsx`:

| Wrapper | Built on |
|---|---|
| `SelectField` | shadcn Select |
| `DatePicker` | shadcn Popover + Calendar |
| `ExpiryPicker` | two shadcn Selects |
| `CheckboxField` | shadcn Checkbox |
| `TextInput` | shadcn Input |

### Demo auth

`src/middleware.ts` sends any dashboard route to `/login?next=…` unless the `bd_session` cookie is set.

- **Login:** any valid email plus a password of 6+ characters signs you in. "Remember me" keeps the cookie for 30 days. You are then sent back to `next`.
- **Logout:** open the avatar menu (or the mobile drawer footer), choose Log out and confirm.

### Shared state (`src/lib/store.ts`)

The store holds: `user`, `preferences`, `security`, `cards`, `transactions`, `notifications`.

- Pages read from and write to it, so changes show up everywhere. Examples:
  - a card added on Credit Cards appears on the Dashboard;
  - a Quick Transfer creates a transaction and lowers the card balance;
  - a profile photo saved in Settings updates the header avatar.
- It is persisted to `localStorage` under `bankdash-store`. To reset, run `localStorage.removeItem("bankdash-store")` in the browser console.
- Every action (`addCard`, `updateCard`, `addTransaction`, `notify`, …) is where an API call would go.

### What each part does

| Area | Interactions |
|---|---|
| Header | **Search:** a ⌘K / Ctrl+K / `/` command palette for pages, quick actions, cards and transactions. **Settings:** gear link. **Notifications:** popover with unread badge and All/Unread filter. You can mark all read, dismiss one, clear all, or click one to go to the related page. **Avatar:** menu with Profile, Preferences, Security, Settings and Log out (with a confirm dialog). |
| Dashboard | **Cards:** click for a details dialog; "See All" goes to Credit Cards. **Recent transactions:** click for a details dialog and receipt download. **Quick Transfer:** pick a person and enter an amount (validated against the card balance). A confirm dialog appears, then the transaction is created, the balance drops, and you get a notification and toast. |
| Transactions | **Tabs:** All / Income / Expense filter the list, with working pagination. **Rows:** click a row for details; "Download" saves a real receipt (`.html`, printable to PDF). **Add Card:** "+ Add Card" jumps to the Add New Card form. |
| Accounts | **Stat cards** link to their pages. **Last Transaction:** click for details and receipt. **Debit/Credit chart:** period Select. **Invoices:** click for a dialog and download. |
| Investments | **Holdings:** click for a details dialog with a mini chart and a Buy/Sell form (RadioGroup). **Trending stocks:** click for a dialog. **Yearly chart:** range Select. |
| Credit Cards | **Card list:** View Details opens a dialog to set a card as Primary, Block/Unblock it, or Remove it (each with a confirm). **Add New Card:** Select, number auto-format with a Luhn check, and a date picker; the new card animates into the list. **Card Setting:** Block card, Change PIN (InputOTP), and add to Google Pay / Apple Pay / Apple Store. **Pie chart:** legend toggles slices. |
| Loans | **Repay:** dialog with amount, source card (Select) and date (DatePicker). The balance and totals update, and a fully repaid loan shows "Paid". **Loan stat cards:** open an "Apply for loan" dialog. |
| Services | **Details:** "View Details", the row itself, or a highlight card opens a service dialog. **Apply:** a form with a plan Select, amount and terms Checkbox. |
| My Privileges | Activate or deactivate (with confirm). Manage opens a dialog. Locked items show a tooltip. |
| Settings | **Edit Profile:** saved to the store. Uses a DatePicker for DOB, a Country Select, and an avatar upload (resized to 256px). **Preferences:** Currency and Time Zone Selects plus notification switches. **Security:** 2FA switch and Change Password (validated). |
| Auth | **Login, Signup, Forgot password:** email → InputOTP code → new password. **Terms:** opens in a dialog. **Google button:** shows a "not configured" toast. |

All money and security actions show a toast (sonner) and add a notification to the bell.

---

## Known deviations from Figma

1. **Icons and vector assets are hand-built SVGs, not Figma's exported files.** The build sandbox's network policy blocked `figma.com`, so Figma's SVG/PNG export URLs could not be downloaded.
   - They match the layout, size and colour closely but are not byte-identical.
   - To swap in the originals, export them from Figma (right-click → Copy/Export as SVG) and replace the components in `src/components/**/icons.tsx`. Keep `fill="currentColor"` so active/hover colours still work.
2. **Photos are exported at their 1× display size.** These are the avatars and the profile picture in `public/images/avatars`. Re-export them at 2× from Figma for sharper results on retina screens.
3. **"Mont Heavy DEMO" (logo font) is a paid demo font.** It is replaced by Montserrat 900. Drop a licensed Mont woff2 into `public/fonts` and update `--font-mont` to use it.
4. **Lato Semibold → Lato Bold.** `@fontsource/lato` ships 400/700 only, so the bank-card numbers render at 700 instead of 600.
5. **Figma copy is kept verbatim**, typos included ("Diposit", "Envestment Value", "Namain Card", "$125,0000"). Fix these in the components if you want.
6. **Sample data is hard-coded in each component.** Replace it with API data as needed.

## Verifying against Figma

`design-reference/` contains the Figma render of every frame. Compare by running the app at 1440 / 1024 / 375 wide, screenshotting, and overlaying the matching PNG.
