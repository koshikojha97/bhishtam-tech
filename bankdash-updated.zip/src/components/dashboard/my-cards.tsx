"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { BankCard } from "@/components/shared/bank-card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { dialogBox, dialogTitle, ghostBtn, primaryBtn } from "@/components/transactions/tx-shared";
import { money, useApp, type Card } from "@/lib/store";
import { cn } from "@/lib/utils";

/** "My Cards" row — first two cards from the store; click opens a details dialog. */
export function MyCards({ cardClassName, limit = 2 }: { cardClassName?: string; limit?: number }) {
  const cards = useApp((s) => s.cards).slice(0, limit);
  const [openId, setOpenId] = useState<string | null>(null);
  const card = useApp((s) => s.cards.find((c) => c.id === openId)) ?? null;

  return (
    <>
      <div className="no-scrollbar -mx-[25px] flex snap-x scroll-px-[25px] gap-[20px] overflow-x-auto px-[25px] lg:mx-0 lg:grid lg:grid-cols-2 lg:gap-[25px] lg:overflow-visible lg:px-0 xl:gap-[30px]">
        {cards.map((c) => (
          <div
            key={c.id}
            role="button"
            tabIndex={0}
            aria-label={`Card ending ${c.number.slice(-4)} details`}
            onClick={() => setOpenId(c.id)}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                setOpenId(c.id);
              }
            }}
            className="relative w-[265px] shrink-0 cursor-pointer snap-start rounded-[15px] outline-none focus-visible:ring-[3px] focus-visible:ring-bd-royal/30 lg:w-auto xl:rounded-[25px]"
          >
            <BankCard
              card={{ balance: money(c.balance), holder: c.holder, validThru: c.validThru, number: c.number, variant: c.variant }}
              className={cn(cardClassName, c.blocked && "opacity-60 grayscale-[40%]")}
            />
            {c.blocked && (
              <span className="pointer-events-none absolute inset-0 flex items-center justify-center rounded-[15px] bg-white/30 xl:rounded-[25px]">
                <span className="rounded-full bg-bd-primary/85 px-[14px] py-[5px] text-[12px] font-semibold tracking-wide text-white xl:text-[14px]">Blocked</span>
              </span>
            )}
          </div>
        ))}
      </div>
      <CardDetailsDialog card={card} onOpenChange={(o) => !o && setOpenId(null)} />
    </>
  );
}

export function CardDetailsDialog({ card, onOpenChange }: { card: Card | null; onOpenChange: (open: boolean) => void }) {
  return (
    <Dialog open={!!card} onOpenChange={onOpenChange}>
      <DialogContent className={dialogBox}>
        {card && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }} className="flex flex-col gap-[18px]">
            <DialogHeader>
              <DialogTitle className={dialogTitle}>Card Details</DialogTitle>
              <DialogDescription className="text-[14px] text-bd-muted">
                {card.type} card · {card.blocked ? "Blocked" : "Active"}
              </DialogDescription>
            </DialogHeader>
            <dl className="divide-y divide-bd-border text-[14px]">
              {(
                [
                  ["Card Number", card.number],
                  ["Card Holder", card.holder],
                  ["Name on Card", card.nameOnCard],
                  ["Valid Thru", card.validThru],
                  ["Bank", card.bank],
                  ["Balance", money(card.balance)],
                ] as const
              ).map(([k, v]) => (
                <div key={k} className="flex justify-between gap-4 py-[10px]">
                  <dt className="text-bd-muted">{k}</dt>
                  <dd className="font-medium text-bd-primary">{v}</dd>
                </div>
              ))}
            </dl>
            <DialogFooter className="gap-[10px]">
              <Button variant="outline" className={ghostBtn} onClick={() => onOpenChange(false)}>
                Close
              </Button>
              <Button asChild className={primaryBtn}>
                <Link href="/credit-cards">Manage</Link>
              </Button>
            </DialogFooter>
          </motion.div>
        )}
      </DialogContent>
    </Dialog>
  );
}
