"use client";

import { Pie, PieChart, Sector, type PieSectorDataItem } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { Panel } from "@/components/shared/section";

/** Order + offsets tuned to match the exploded pie in Figma. */
const data = [
  { key: "entertainment", label: "Entertainment", value: 30, fill: "#343C6A", explode: 10, r: 0.92 },
  { key: "bill", label: "Bill Expense", value: 15, fill: "#FC7900", explode: 16, r: 0.88 },
  { key: "others", label: "Others", value: 35, fill: "#1814F3", explode: 6, r: 0.98 },
  { key: "investment", label: "Investment", value: 20, fill: "#FA00FF", explode: 10, r: 1 },
];

const config = {
  entertainment: { label: "Entertainment", color: "#343C6A" },
  bill: { label: "Bill Expense", color: "#FC7900" },
  others: { label: "Others", color: "#1814F3" },
  investment: { label: "Investment", color: "#FA00FF" },
} satisfies ChartConfig;

const RAD = Math.PI / 180;

function ExplodedSector(props: PieSectorDataItem & { isActive?: boolean }) {
  const { cx = 0, cy = 0, midAngle = 0, outerRadius = 0, startAngle, endAngle, fill, payload, isActive } = props;
  const p = payload as (typeof data)[number];
  const scale = outerRadius / 120;
  const off = (p.explode + (isActive ? 6 : 0)) * scale;
  const dx = Math.cos(-midAngle * RAD) * off;
  const dy = Math.sin(-midAngle * RAD) * off;
  const r = outerRadius * p.r;
  // label position
  const lr = r * 0.58;
  const lx = cx + dx + Math.cos(-midAngle * RAD) * lr;
  const ly = cy + dy + Math.sin(-midAngle * RAD) * lr;
  return (
    <g style={{ transition: "transform .25s" }}>
      <Sector cx={cx + dx} cy={cy + dy} innerRadius={0} outerRadius={r} startAngle={startAngle} endAngle={endAngle} fill={fill} />
      <text x={lx} y={ly - 6 * scale} textAnchor="middle" fill="#fff" fontWeight={700} fontSize={Math.max(11, 16 * scale)}>
        {p.value}%
      </text>
      <text x={lx} y={ly + 11 * scale} textAnchor="middle" fill="#fff" fontWeight={700} fontSize={Math.max(8, 13 * scale)}>
        {p.label}
      </text>
    </g>
  );
}

export function ExpenseStatistics() {
  return (
    <Panel className="flex h-full items-center justify-center p-[15px] xl:p-[25px]">
      <ChartContainer config={config} className="aspect-square h-[230px] w-full max-w-[300px] xl:h-[260px]">
        <PieChart>
          <ChartTooltip content={<ChartTooltipContent nameKey="key" hideLabel />} />
          <Pie
            data={data}
            dataKey="value"
            nameKey="key"
            startAngle={150}
            endAngle={-210}
            outerRadius="92%"
            stroke="none"
            isAnimationActive
            animationDuration={1000}
            shape={ExplodedSector}
          />
        </PieChart>
      </ChartContainer>
    </Panel>
  );
}
