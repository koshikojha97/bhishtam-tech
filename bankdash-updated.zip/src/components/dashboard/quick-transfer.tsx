"use client";

import { useState } from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";
import { ChevronRightIcon, SendIcon } from "@/components/icons";
import { Panel } from "@/components/shared/section";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { dialogBox, dialogTitle, ghostBtn, primaryBtn } from "@/components/transactions/tx-shared";
import { money, useApp } from "@/lib/store";
import { cn } from "@/lib/utils";

const PEOPLE = [
  { name: "Livia Bator", role: "CEO", img: "/images/avatars/livia-bator.png" },
  { name: "Randy Press", role: "Director", img: "/images/avatars/randy-press.png" },
  { name: "Workman", role: "Designer", img: "/images/avatars/workman.png" },
  { name: "Livia Bator", role: "CEO", img: "/images/avatars/livia-bator.png" },
  { name: "Randy Press", role: "Director", img: "/images/avatars/randy-press.png" },
];

export function QuickTransfer() {
  const [selected, setSelected] = useState(0);
  const [offset, setOffset] = useState(0);
  const [amount, setAmount] = useState("525.50");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [shake, setShake] = useState(0);
  const [confirm, setConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const card = useApp((s) => s.cards[0]);
  const updateCard = useApp((s) => s.updateCard);
  const addTransaction = useApp((s) => s.addTransaction);
  const notify = useApp((s) => s.notify);
  const person = PEOPLE[selected];
  const value = Number(amount.replace(/[$,\s]/g, ""));

  const validate = () => {
    if (!amount.trim() || !Number.isFinite(value)) return "Enter a valid amount";
    if (value <= 0) return "Amount must be greater than 0";
    if (!card) return "No card available";
    if (card.blocked) return "Your primary card is blocked";
    if (value > card.balance) return `Amount exceeds card balance (${money(card.balance)})`;
    return "";
  };

  const send = () => {
    if (!card) return;
    setLoading(true);
    setTimeout(() => {
      const amt = Math.round(value * 100) / 100;
      addTransaction({ description: person.name, type: "Transfer", card: `${card.number.slice(-4)} ****`, amount: -amt });
      updateCard(card.id, { balance: Math.round((card.balance - amt) * 100) / 100 });
      notify({ title: "Transfer sent", body: `You sent ${money(amt)} to ${person.name}`, kind: "transaction", href: "/transactions" });
      toast.success(`${money(amt)} sent to ${person.name}`);
      setLoading(false);
      setConfirm(false);
      setSent(true);
      setTimeout(() => setSent(false), 1600);
    }, 750);
  };
  const visible = [0, 1, 2].map((i) => ({ ...PEOPLE[(offset + i) % PEOPLE.length], idx: (offset + i) % PEOPLE.length }));

  return (
    <Panel className="flex h-full flex-col justify-center px-[20px] py-[22px] xl:px-[25px] xl:py-[35px]">
      <div className="flex items-center justify-between">
        <div className="flex flex-1 justify-between pr-[10px] xl:pr-[20px]">
          <AnimatePresence mode="popLayout" initial={false}>
            {visible.map((p) => {
              const active = p.idx === selected;
              return (
                <motion.button
                  layout
                  key={p.idx}
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -30 }}
                  whileHover={{ y: -3 }}
                  onClick={() => setSelected(p.idx)}
                  aria-pressed={active}
                  className="flex flex-col items-center text-center"
                >
                  <Image
                    src={p.img}
                    alt={p.name}
                    width={70}
                    height={70}
                    className={cn("size-[50px] rounded-full transition-shadow xl:size-[70px]")}
                  />
                  <span className={cn("mt-[12px] text-[12px] text-bd-text xl:mt-[15px] xl:text-[16px]", active && "font-bold")}>{p.name}</span>
                  <span className={cn("mt-[2px] text-[12px] text-bd-muted xl:mt-[5px] xl:text-[15px]", active && "font-bold")}>{p.role}</span>
                </motion.button>
              );
            })}
          </AnimatePresence>
        </div>
        <motion.button
          aria-label="Next"
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.92 }}
          onClick={() => setOffset((o) => (o + 1) % PEOPLE.length)}
          className="flex size-[40px] shrink-0 items-center justify-center rounded-full bg-bd-surface text-bd-muted shadow-bd xl:size-[50px]"
        >
          <ChevronRightIcon />
        </motion.button>
      </div>

      <form
        className="mt-[22px] flex items-center gap-[20px] lg:gap-[15px] xl:mt-[30px] xl:gap-[27px]"
        onSubmit={(e) => {
          e.preventDefault();
          const err = validate();
          setError(err);
          if (err) {
            setShake((n) => n + 1);
            return;
          }
          setConfirm(true);
        }}
      >
        <label htmlFor="qt-amount" className="shrink-0 text-[12px] text-bd-muted xl:text-[16px]">
          Write Amount
        </label>
        <motion.div
          key={shake}
          animate={shake ? { x: [0, -8, 8, -5, 5, 0] } : undefined}
          transition={{ duration: 0.4 }}
          className={cn("flex h-[40px] min-w-0 flex-1 items-center rounded-[50px] bg-bd-input xl:h-[50px]", error && "ring-1 ring-bd-red")}
        >
          <Input
            id="qt-amount"
            inputMode="decimal"
            value={amount}
            aria-invalid={!!error || undefined}
            aria-describedby={error ? "qt-error" : undefined}
            onChange={(e) => {
              setAmount(e.target.value);
              if (error) setError("");
            }}
            className="h-full w-full min-w-[56px] flex-1 rounded-none border-0 bg-transparent pr-[6px] pl-[20px] text-[12px] text-bd-muted shadow-none outline-none focus-visible:ring-0 aria-invalid:ring-0 md:text-[12px] lg:pl-[16px] xl:pl-[30px] xl:text-[16px] xl:md:text-[16px] dark:bg-transparent"
          />
          <motion.button
            type="submit"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.96 }}
            className="flex h-full w-[100px] shrink-0 items-center justify-center gap-[10px] rounded-[50px] bg-bd-royal text-[13px] font-medium text-white shadow-bd xl:w-[125px] xl:gap-[12px] xl:text-[16px]"
          >
            <AnimatePresence mode="wait" initial={false}>
              <motion.span key={sent ? "s" : "n"} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                {sent ? "Sent!" : "Send"}
              </motion.span>
            </AnimatePresence>
            <motion.span animate={sent ? { x: [0, 30, -30, 0], opacity: [1, 0, 0, 1] } : {}} transition={{ duration: 0.8 }}>
              <SendIcon className="h-[16px] w-[18px] xl:h-[23px] xl:w-[26px]" />
            </motion.span>
          </motion.button>
        </motion.div>
      </form>
      <AnimatePresence>
        {error && (
          <motion.p
            id="qt-error"
            role="alert"
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mt-[8px] text-right text-[12px] text-bd-red xl:text-[13px]"
          >
            {error}
          </motion.p>
        )}
      </AnimatePresence>

      <AlertDialog open={confirm} onOpenChange={(o) => !loading && setConfirm(o)}>
        <AlertDialogContent className={dialogBox}>
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-[18px]">
            <AlertDialogHeader className="place-items-start text-left">
              <AlertDialogTitle className={dialogTitle}>
                Send {money(Number.isFinite(value) ? value : 0)} to {person.name}?
              </AlertDialogTitle>
              <AlertDialogDescription className="text-[14px] text-bd-muted">
                The amount will be deducted from your card ending {card?.number.slice(-4)} (balance {money(card?.balance ?? 0)}).
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="gap-[10px]">
              <AlertDialogCancel disabled={loading} className={ghostBtn}>
                Cancel
              </AlertDialogCancel>
              <AlertDialogAction
                disabled={loading}
                className={primaryBtn}
                onClick={(e) => {
                  e.preventDefault();
                  send();
                }}
              >
                {loading ? "Sending…" : "Send"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </motion.div>
        </AlertDialogContent>
      </AlertDialog>
    </Panel>
  );
}
