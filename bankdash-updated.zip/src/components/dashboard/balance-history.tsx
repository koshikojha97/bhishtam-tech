"use client";

import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { Panel } from "@/components/shared/section";

const MONTHS = ["Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan"];

/** x = month index (fractional) so the curve matches the Figma wave between month gridlines. */
const data = [
  { x: 0, balance: 100 },
  { x: 0.55, balance: 320 },
  { x: 1.1, balance: 230 },
  { x: 1.75, balance: 480 },
  { x: 2.25, balance: 440 },
  { x: 2.95, balance: 780 },
  { x: 3.7, balance: 225 },
  { x: 4.6, balance: 570 },
  { x: 5.3, balance: 235 },
  { x: 5.95, balance: 640 },
  { x: 6.6, balance: 590 },
];

const config = { balance: { label: "Balance", color: "#1814F3" } } satisfies ChartConfig;

export function BalanceHistory() {
  return (
    <Panel className="h-full px-[12px] pt-[20px] pb-[10px] xl:px-[25px] xl:pt-[30px] xl:pb-[20px]">
      <ChartContainer config={config} className="aspect-auto h-[190px] w-full lg:h-[200px] xl:h-[222px]">
        <AreaChart data={data} margin={{ left: -10, right: 0, top: 6, bottom: 0 }}>
          <defs>
            <linearGradient id="bh-fill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#2D60FF" stopOpacity={0.25} />
              <stop offset="100%" stopColor="#2D60FF" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="var(--color-bd-card-border)" strokeDasharray="4 4" />
          <XAxis
            dataKey="x"
            type="number"
            domain={[0, 6.6]}
            ticks={[0, 1, 2, 3, 4, 5, 6]}
            tickFormatter={(v: number) => MONTHS[v] ?? ""}
            tickLine={false}
            axisLine={{ stroke: "var(--color-bd-muted)" }}
            tickMargin={10}
            tick={{ fill: "var(--color-bd-muted)", fontSize: 14 }}
            padding={{ left: 0, right: 0 }}
          />
          <YAxis
            ticks={[0, 200, 400, 600, 800]}
            domain={[0, 800]}
            tickLine={false}
            axisLine={{ stroke: "var(--color-bd-muted)" }}
            tickMargin={8}
            tick={{ fill: "var(--color-bd-muted)", fontSize: 13 }}
          />
          <ChartTooltip
            content={<ChartTooltipContent indicator="line" labelFormatter={(_, p) => MONTHS[Math.round(Number(p?.[0]?.payload?.x ?? 0))] ?? ""} />}
          />
          <Area
            type="natural"
            dataKey="balance"
            stroke="var(--color-balance)"
            strokeWidth={3}
            fill="url(#bh-fill)"
            animationDuration={1400}
            activeDot={{ r: 6, fill: "#1814F3", stroke: "var(--color-bd-surface)", strokeWidth: 3 }}
          />
        </AreaChart>
      </ChartContainer>
    </Panel>
  );
}
