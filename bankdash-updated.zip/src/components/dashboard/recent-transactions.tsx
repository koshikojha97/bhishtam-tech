"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { CardStackIcon, CoinIcon, PaypalIcon } from "@/components/icons";
import { Panel } from "@/components/shared/section";
import { listContainer, listItem } from "@/components/shared/motion";
import { TxDetailDialog, fmtTxDate } from "@/components/transactions/tx-shared";
import { money, useApp, type Transaction, type TxType } from "@/lib/store";
import { cn } from "@/lib/utils";

const ICONS: Record<TxType, { icon: typeof CoinIcon; bg: string; fg: string }> = {
  Shopping: { icon: CardStackIcon, bg: "bg-bd-tint-yellow", fg: "text-[#FFBB38]" },
  Service: { icon: PaypalIcon, bg: "bg-bd-tint-blue", fg: "text-[#396AFF]" },
  Deposit: { icon: PaypalIcon, bg: "bg-bd-tint-blue", fg: "text-[#396AFF]" },
  Transfer: { icon: CoinIcon, bg: "bg-bd-tint-teal", fg: "text-[#16DBCC]" },
};

export function RecentTransactions() {
  const transactions = useApp((s) => s.transactions);
  const latest = useMemo(
    () => [...transactions].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 3),
    [transactions],
  );
  const [open, setOpen] = useState<Transaction | null>(null);

  return (
    <Panel className="h-full px-[18px] py-[15px] lg:px-[15px] lg:py-[15px] xl:px-[25px] xl:py-[25px]">
      <motion.ul variants={listContainer} initial="hidden" animate="show" className="flex flex-col gap-[10px] xl:gap-[10px]">
        {latest.map((t) => {
          const ic = ICONS[t.type] ?? ICONS.Transfer;
          const positive = t.amount > 0;
          return (
            <motion.li key={t.id} variants={listItem} whileHover={{ x: 4 }}>
              <button
                type="button"
                onClick={() => setOpen(t)}
                className="flex w-full items-center gap-[12px] rounded-[12px] text-left outline-none focus-visible:ring-[3px] focus-visible:ring-bd-royal/20 xl:gap-[15px]"
              >
                <span className={cn("flex size-[50px] shrink-0 items-center justify-center rounded-full lg:size-[45px] xl:size-[55px]", ic.bg, ic.fg)}>
                  <ic.icon className="size-[20px] xl:size-[28px]" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[14px] leading-tight font-medium text-bd-text lg:text-[14px] xl:overflow-visible xl:text-[16px] xl:whitespace-normal">{t.description}</span>
                  <span className="mt-[4px] block whitespace-nowrap text-[12px] text-bd-muted lg:text-[12px] xl:mt-[7px] xl:text-[15px]">{fmtTxDate(t.date, "d MMMM yyyy")}</span>
                </span>
                <span className={cn("shrink-0 pl-1 text-[11px] font-medium lg:text-[11px] xl:text-[16px]", positive ? "text-bd-green" : "text-bd-red")}>
                  {money(t.amount, true)}
                </span>
              </button>
            </motion.li>
          );
        })}
      </motion.ul>
      <TxDetailDialog tx={open} onOpenChange={(o) => !o && setOpen(null)} />
    </Panel>
  );
}
