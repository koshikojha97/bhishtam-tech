"use client";

import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { Panel } from "@/components/shared/section";
import { useBreakpoint } from "@/hooks/use-breakpoint";

const data = [
  { day: "Sat", deposit: 480, withdraw: 240 },
  { day: "Sun", deposit: 350, withdraw: 130 },
  { day: "Mon", deposit: 330, withdraw: 260 },
  { day: "Tue", deposit: 480, withdraw: 370 },
  { day: "Wed", deposit: 150, withdraw: 240 },
  { day: "Thu", deposit: 390, withdraw: 240 },
  { day: "Fri", deposit: 400, withdraw: 330 },
];

const config = {
  deposit: { label: "Deposit", color: "#1814F3" },
  withdraw: { label: "Withdraw", color: "#16DBCC" },
} satisfies ChartConfig;

function Legend() {
  return (
    <div className="flex justify-end gap-[20px] xl:gap-[30px]">
      {[
        { label: "Diposit", color: "bg-bd-teal" },
        { label: "Withdraw", color: "bg-[#FF82AC]" },
      ].map((l) => (
        <span key={l.label} className="flex items-center gap-[10px] text-[12px] text-bd-muted xl:text-[15px]">
          <span className={`size-[12px] rounded-full xl:size-[15px] ${l.color}`} />
          {l.label}
        </span>
      ))}
    </div>
  );
}

export function WeeklyActivity() {
  const bp = useBreakpoint();
  const bar = bp === "xl" ? 15 : bp === "lg" ? 10 : 7;
  return (
    <Panel className="h-full px-[18px] pt-[20px] pb-[12px] lg:px-[20px] xl:px-[30px] xl:pt-[28px] xl:pb-[20px]">
      <Legend />
      <ChartContainer config={config} className="mt-[12px] aspect-auto h-[200px] w-full lg:h-[205px] xl:mt-[18px] xl:h-[245px]">
        <BarChart data={data} barGap={bp === "xl" ? 12 : bp === "lg" ? 8 : 4} barCategoryGap={bp === "sm" ? "18%" : "28%"} margin={{ left: -16, right: 0, top: 6, bottom: 0 }}>
          <CartesianGrid vertical={false} stroke="var(--color-bd-grid)" />
          <XAxis dataKey="day" tickLine={false} axisLine={false} tickMargin={12} tick={{ fill: "var(--color-bd-muted)", fontSize: 13 }} />
          <YAxis
            tickLine={false}
            axisLine={false}
            ticks={[0, 100, 200, 300, 400, 500]}
            domain={[0, 500]}
            tickMargin={8}
            tick={{ fill: "var(--color-bd-muted)", fontSize: 13 }}
          />
          <ChartTooltip cursor={{ fill: "var(--color-bd-input)", radius: 10 }} content={<ChartTooltipContent />} />
          <Bar dataKey="deposit" fill="var(--color-deposit)" radius={30} barSize={bar} animationDuration={900} />
          <Bar dataKey="withdraw" fill="var(--color-withdraw)" radius={30} barSize={bar} animationDuration={900} animationBegin={150} />
        </BarChart>
      </ChartContainer>
    </Panel>
  );
}
