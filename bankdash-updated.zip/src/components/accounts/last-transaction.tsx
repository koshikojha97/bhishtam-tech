"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { Download } from "lucide-react";
import { toast } from "sonner";
import { Panel } from "@/components/shared/section";
import { listContainer, listItem } from "@/components/shared/motion";
import { money, useApp, type Transaction, type TxType } from "@/lib/store";
import { downloadFile, receiptHtml } from "@/lib/download";
import { cn } from "@/lib/utils";
import { BdDialog, DetailRows, GhostButton, PrimaryButton } from "./dialog-kit";
import { HandCoinIcon, RenewIcon, ToolsIcon, UserOutlineIcon } from "./icons";

const LOOK: Record<TxType, { icon: typeof RenewIcon; bg: string; fg: string }> = {
  Shopping: { icon: RenewIcon, bg: "bg-bd-tint-teal", fg: "text-[#16DBCC]" },
  Service: { icon: ToolsIcon, bg: "bg-bd-tint-blue", fg: "text-[#396AFF]" },
  Transfer: { icon: UserOutlineIcon, bg: "bg-bd-tint-pink", fg: "text-[#FF82AC]" },
  Deposit: { icon: HandCoinIcon, bg: "bg-bd-tint-yellow", fg: "text-[#FFBB38]" },
};

const COLS =
  "lg:grid lg:grid-cols-[57px_minmax(0,132fr)_minmax(0,74fr)_minmax(0,77fr)_minmax(0,76fr)_auto] " +
  "xl:grid-cols-[80px_minmax(0,187fr)_minmax(0,115fr)_minmax(0,120fr)_minmax(0,133fr)_auto]";

const fmtDate = (iso: string) => format(new Date(iso), "d MMM yyyy");
/** Transactions from the last 24h are still "Pending" in this demo. */
const statusOf = (t: Transaction) => (Date.now() - new Date(t.date).getTime() < 864e5 ? "Pending" : "Completed");

export function LastTransaction() {
  const txs = useApp((s) => s.transactions);
  const latest = [...txs].sort((a, b) => +new Date(b.date) - +new Date(a.date)).slice(0, 3);
  const [sel, setSel] = useState<Transaction | null>(null);

  const download = (t: Transaction) => {
    downloadFile(
      `receipt-${t.txId.replace("#", "")}.html`,
      receiptHtml("Transaction receipt", [
        ["Description", t.description],
        ["Transaction ID", t.txId],
        ["Type", t.type],
        ["Card", t.card],
        ["Date", format(new Date(t.date), "d MMM yyyy, h:mm a")],
        ["Status", statusOf(t)],
        ["Amount", money(t.amount, true)],
      ]),
      "text/html;charset=utf-8",
    );
    toast.success("Receipt downloaded");
  };

  return (
    <Panel className="h-full px-[20px] py-[20px] lg:px-[18px] lg:py-[15px] xl:px-[25px] xl:py-[25px]">
      {latest.length === 0 && <p className="py-6 text-center text-[14px] text-bd-muted">No transactions yet</p>}
      <motion.ul variants={listContainer} initial="hidden" animate="show" className="flex flex-col gap-[12px] lg:gap-[10px]">
        {latest.map((t) => {
          const look = LOOK[t.type] ?? LOOK.Transfer;
          return (
            <motion.li key={t.id} variants={listItem} whileHover={{ x: 4 }}>
              <button
                type="button"
                onClick={() => setSel(t)}
                aria-label={`${t.description}, ${money(t.amount, true)} — view details`}
                className={cn(
                  "flex w-full cursor-pointer items-center gap-[12px] rounded-[12px] text-left text-bd-muted outline-none focus-visible:ring-[3px] focus-visible:ring-bd-royal/30 lg:gap-0",
                  COLS,
                )}
              >
                <span
                  className={cn(
                    "flex size-[45px] shrink-0 items-center justify-center rounded-[15px] lg:size-[40px] lg:rounded-[12px] xl:size-[55px] xl:rounded-[20px]",
                    look.bg,
                    look.fg,
                  )}
                >
                  <look.icon className="size-[20px] lg:size-[20px] xl:size-[27px]" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[14px] leading-[17px] font-medium text-bd-text lg:text-[12px] lg:leading-[15px] xl:text-[16px] xl:leading-[19px]">
                    {t.description}
                  </p>
                  <p className="mt-[4px] text-[12px] leading-[15px] lg:mt-[4px] xl:mt-[7px] xl:text-[15px] xl:leading-[18px]">{fmtDate(t.date)}</p>
                </div>
                <span className="hidden truncate text-[12px] lg:block xl:text-[16px]">{t.type}</span>
                <span className="hidden truncate text-[12px] lg:block xl:text-[16px]">{t.card}</span>
                <span className="hidden truncate text-[12px] lg:block xl:text-[16px]">{statusOf(t)}</span>
                <span className={cn("shrink-0 text-right text-[12px] font-medium xl:text-[16px]", t.amount >= 0 ? "text-[#16DBAA]" : "text-bd-pink")}>
                  {money(t.amount, true)}
                </span>
              </button>
            </motion.li>
          );
        })}
      </motion.ul>

      <BdDialog open={!!sel} onOpenChange={(o) => !o && setSel(null)} title="Transaction details" description={sel?.description}>
        {sel && (
          <>
            <p className={cn("mb-[16px] text-[28px] font-semibold", sel.amount >= 0 ? "text-[#16DBAA]" : "text-bd-pink")}>{money(sel.amount, true)}</p>
            <DetailRows
              rows={[
                ["Transaction ID", sel.txId],
                ["Type", sel.type],
                ["Card", sel.card],
                ["Date", format(new Date(sel.date), "d MMM yyyy, h:mm a")],
                ["Status", statusOf(sel)],
              ]}
            />
            <div className="mt-[20px] flex flex-col-reverse gap-[10px] sm:flex-row sm:justify-end">
              <GhostButton onClick={() => setSel(null)}>Close</GhostButton>
              <PrimaryButton onClick={() => download(sel)}>
                <Download className="size-4" /> Download receipt
              </PrimaryButton>
            </div>
          </>
        )}
      </BdDialog>
    </Panel>
  );
}
