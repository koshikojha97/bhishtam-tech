"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Panel } from "@/components/shared/section";
import { CountUp, listContainer } from "@/components/shared/motion";
import { cn } from "@/lib/utils";
import { HandCoinIcon, MoneyBagIcon, PiggyBankIcon, ReceiptCoinIcon } from "./icons";

const STATS = [
  { label: "My Balance", value: 12750, href: "/credit-cards", hint: "View your cards", icon: MoneyBagIcon, bg: "bg-bd-tint-yellow", fg: "text-[#FFBB38]" },
  { label: "Income", value: 5600, href: "/transactions", hint: "View income transactions", icon: HandCoinIcon, bg: "bg-bd-tint-blue", fg: "text-[#396AFF]" },
  { label: "Expense", value: 3460, href: "/transactions", hint: "View expense transactions", icon: ReceiptCoinIcon, bg: "bg-bd-tint-pink", fg: "text-[#FF82AC]" },
  { label: "Total Saving", value: 7920, href: "/investments", hint: "View investments", icon: PiggyBankIcon, bg: "bg-bd-tint-teal", fg: "text-[#16DBCC]" },
];

const pop = {
  hidden: { opacity: 0, y: 16, scale: 0.97 },
  show: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] as const } },
};

export function StatCards() {
  return (
    <motion.div
      variants={listContainer}
      initial="hidden"
      animate="show"
      className="mt-[5px] grid grid-cols-2 gap-[15px] lg:mt-[2px] lg:grid-cols-4 lg:gap-[25px] xl:mt-[6px] xl:gap-[30px]"
    >
      {STATS.map((s) => (
        <motion.div key={s.label} variants={pop} className="min-w-0">
          <Link
            href={s.href}
            aria-label={`${s.label}: ${s.hint}`}
            title={s.hint}
            className="block rounded-[15px] outline-none focus-visible:ring-[3px] focus-visible:ring-bd-royal/30 lg:rounded-[20px] xl:rounded-[25px]"
          >
            <Panel className="group flex h-[85px] cursor-pointer items-center justify-center gap-[10px] px-[10px] lg:h-[90px] lg:gap-[12px] xl:h-[120px] xl:gap-[15px]">
              <span
                className={cn(
                  "flex size-[45px] shrink-0 items-center justify-center rounded-full transition-transform duration-300 group-hover:scale-110 group-hover:rotate-[-6deg] lg:size-[50px] xl:size-[70px]",
                  s.bg,
                  s.fg,
                )}
              >
                <s.icon className="size-[20px] xl:size-[30px]" />
              </span>
              <div className="min-w-0">
                <p className="truncate text-[12px] leading-[15px] text-bd-muted xl:text-[16px] xl:leading-[19px]">{s.label}</p>
                <CountUp
                  value={s.value}
                  prefix="$"
                  className="mt-[4px] block text-[16px] leading-[19px] font-semibold text-bd-text xl:mt-[7px] xl:text-[25px] xl:leading-[30px]"
                />
              </div>
            </Panel>
          </Link>
        </motion.div>
      ))}
    </motion.div>
  );
}
