"use client";

import { useState } from "react";
import { Bar, BarChart, XAxis, YAxis } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { Panel } from "@/components/shared/section";
import { FadeUp } from "@/components/shared/motion";
import { MiniSelect } from "./dialog-kit";
import { useBreakpoint } from "@/hooks/use-breakpoint";

type Period = "this-week" | "last-week" | "this-month";

/** "This week" = bar heights from the desktop Figma frame (px), ×10 → dollars; the others are demo data. */
const DATASETS: Record<Period, { label: string; debited: string; credited: string; suffix: string; data: { day: string; debit: number; credit: number }[] }> = {
  "this-week": {
    label: "This week",
    debited: "$7,560",
    credited: "$5,420",
    suffix: "in this Week",
    data: [
      { day: "Sat", debit: 1350, credit: 2340 },
      { day: "Sun", debit: 1060, credit: 1860 },
      { day: "Mon", debit: 1020, credit: 1390 },
      { day: "Tue", debit: 2120, credit: 1230 },
      { day: "Wed", debit: 1500, credit: 2140 },
      { day: "Thu", debit: 1580, credit: 1050 },
      { day: "Fri", debit: 1790, credit: 2160 },
    ],
  },
  "last-week": {
    label: "Last week",
    debited: "$6,980",
    credited: "$7,140",
    suffix: "last Week",
    data: [
      { day: "Sat", debit: 980, credit: 1420 },
      { day: "Sun", debit: 640, credit: 860 },
      { day: "Mon", debit: 1240, credit: 1180 },
      { day: "Tue", debit: 1410, credit: 960 },
      { day: "Wed", debit: 870, credit: 1300 },
      { day: "Thu", debit: 1020, credit: 640 },
      { day: "Fri", debit: 820, credit: 780 },
    ],
  },
  "this-month": {
    label: "This month",
    debited: "$28,410",
    credited: "$24,950",
    suffix: "in this Month",
    data: [
      { day: "Week 1", debit: 6980, credit: 7140 },
      { day: "Week 2", debit: 7560, credit: 5420 },
      { day: "Week 3", debit: 6420, credit: 6630 },
      { day: "Week 4", debit: 7450, credit: 5760 },
    ],
  },
};

const PERIODS = (Object.keys(DATASETS) as Period[]).map((k) => ({ value: k, label: DATASETS[k].label }));

/** Bar colours swap on mobile in Figma (orange/blue) vs tablet+desktop (blue/amber) — driven by CSS vars. */
const config = {
  debit: { label: "Debit", color: "var(--debit)" },
  credit: { label: "Credit", color: "var(--credit)" },
} satisfies ChartConfig;

const SIZES = {
  xl: { bar: 30, gap: 10, radius: 10, margin: -15, axis: 29, tickMargin: 12, tick: 14 },
  lg: { bar: 20, gap: 8, radius: 7, margin: -9, axis: 25, tickMargin: 10, tick: 12 },
  sm: { bar: 10, gap: 5, radius: 4, margin: -9, axis: 25, tickMargin: 10, tick: 12 },
} as const;

function Legend() {
  return (
    <div className="ml-auto flex items-center gap-[20px] xl:gap-[26px]">
      {[
        { label: "Debit", cls: "bg-[#4C78FF] shadow-[inset_0_0_15px_rgba(17,52,133,0.5)]" },
        { label: "Credit", cls: "bg-[#FF82AC] shadow-[inset_0_0_15px_rgba(172,13,108,0.5)]" },
      ].map((l) => (
        <span key={l.label} className="flex items-center gap-[10px] text-[12px] leading-[15px] text-bd-muted xl:text-[16px] xl:leading-[19px]">
          <span className={`size-[12px] rounded-[4px] xl:size-[15px] xl:rounded-[5px] ${l.cls}`} />
          {l.label}
        </span>
      ))}
    </div>
  );
}

/** Renders its own section heading so the period selector can sit where "See All" would. */
export function DebitCreditOverview() {
  const s = SIZES[useBreakpoint()];
  const [period, setPeriod] = useState<Period>("this-week");
  const set = DATASETS[period];
  return (
    <FadeUp className="flex min-w-0 flex-col">
      <div className="mb-[15px] flex items-center justify-between gap-3 lg:mb-[18px] xl:mb-[20px]">
        <h2 className="leading-normal text-[16px] font-semibold text-bd-primary lg:text-[18px] xl:text-[22px]">Debit &amp; Credit Overview</h2>
        <MiniSelect value={period} onValueChange={(v) => setPeriod(v as Period)} options={PERIODS} label="Period" />
      </div>
      <Panel className="h-full px-[21px] pt-[18px] pb-[17px] lg:px-[18px] xl:px-[30px] xl:pt-[28px] xl:pb-[27px]">
        <div className="flex items-center">
          <p className="hidden text-[12px] leading-[15px] text-bd-muted lg:block xl:text-[16px] xl:leading-[19px]">
            <span className="text-bd-primary">{set.debited}</span> Debited &amp; <span className="text-bd-primary">{set.credited}</span> Credited {set.suffix}
          </p>
          <Legend />
        </div>
        <ChartContainer
          config={config}
          className="mt-[7px] aspect-auto h-[188px] w-full [--credit:#1814F3] [--debit:#FC7900] lg:mt-[8px] lg:h-[212px] lg:[--credit:#FCAA0B] lg:[--debit:#1A16F3] xl:mt-[16px] xl:h-[274px]"
        >
          <BarChart key={period} data={set.data} barGap={s.gap} margin={{ left: s.margin, right: s.margin, top: 0, bottom: 0 }}>
            <XAxis
              dataKey="day"
              interval={0}
              tickLine={false}
              axisLine={false}
              height={s.axis}
              tickMargin={s.tickMargin}
              tick={{ fill: "var(--color-bd-muted)", fontSize: s.tick }}
            />
            <YAxis hide domain={[0, (max: number) => max * 1.05]} />
            <ChartTooltip cursor={{ fill: "var(--color-bd-input)", radius: 10 }} content={<ChartTooltipContent />} />
            <Bar dataKey="debit" fill="var(--color-debit)" barSize={s.bar} radius={s.radius} animationDuration={900} />
            <Bar dataKey="credit" fill="var(--color-credit)" barSize={s.bar} radius={s.radius} animationDuration={900} animationBegin={150} />
          </BarChart>
        </ChartContainer>
      </Panel>
    </FadeUp>
  );
}
