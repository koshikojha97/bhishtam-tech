"use client";

/**
 * BankDash-styled dialog building blocks shared by the Accounts, Investments and Loans pages.
 * shadcn Dialog restyled: white, radius 20→25, 22px semibold title, royal-blue primary button.
 */
import { useState } from "react";
import { motion, useAnimationControls } from "framer-motion";
import { Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

export function BdDialog({
  open,
  onOpenChange,
  title,
  description,
  children,
  className,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title: string;
  description?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className={cn(
          "max-h-[calc(100svh-2rem)] gap-0 overflow-y-auto rounded-[20px] border-none bg-bd-surface p-[22px] sm:max-w-[460px] xl:rounded-[25px] xl:p-[30px]",
          className,
        )}
      >
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}>
          <DialogHeader className="mb-[18px] text-left">
            <DialogTitle className="text-[20px] leading-tight font-semibold text-bd-primary xl:text-[22px]">{title}</DialogTitle>
            {description ? (
              <DialogDescription className="text-[13px] text-bd-muted xl:text-[14px]">{description}</DialogDescription>
            ) : (
              <DialogDescription className="sr-only">{title}</DialogDescription>
            )}
          </DialogHeader>
          {children}
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}

export function PrimaryButton({ loading, children, className, ...props }: React.ComponentProps<typeof Button> & { loading?: boolean }) {
  return (
    <Button
      {...props}
      disabled={loading || props.disabled}
      className={cn(
        "h-[44px] rounded-[10px] bg-bd-royal px-[24px] text-[14px] font-medium text-white hover:bg-bd-royal/90 xl:h-[50px] xl:rounded-[15px] xl:text-[16px]",
        className,
      )}
    >
      {loading && <Loader2 className="size-4 animate-spin" />}
      {children}
    </Button>
  );
}

export function GhostButton({ children, className, ...props }: React.ComponentProps<typeof Button>) {
  return (
    <Button
      variant="outline"
      {...props}
      className={cn(
        "h-[44px] rounded-[10px] border-bd-card-border px-[20px] text-[14px] font-medium text-bd-primary hover:bg-bd-page hover:text-bd-royal xl:h-[50px] xl:rounded-[15px] xl:text-[16px]",
        className,
      )}
    >
      {children}
    </Button>
  );
}

/** Two-column key/value list used by detail dialogs. */
export function DetailRows({ rows }: { rows: [string, React.ReactNode][] }) {
  return (
    <dl className="divide-y divide-bd-border rounded-[15px] border border-bd-border px-[16px]">
      {rows.map(([k, v]) => (
        <div key={k} className="flex items-center justify-between gap-4 py-[11px] text-[13px] xl:text-[15px]">
          <dt className="text-bd-muted">{k}</dt>
          <dd className="text-right font-medium text-bd-text">{v}</dd>
        </div>
      ))}
    </dl>
  );
}

/** Shake animation for invalid submits + a simulated "loading" submit. */
export function useFormFx() {
  const controls = useAnimationControls();
  const [loading, setLoading] = useState(false);
  const shake = () => controls.start({ x: [0, -8, 8, -6, 6, -3, 3, 0], transition: { duration: 0.45 } });
  const run = (fn: () => void, ms = 750) => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      fn();
    }, ms);
  };
  return { controls, shake, loading, run };
}

export const parseMoney = (s: string) => Number(String(s).replace(/[^0-9.]/g, "")) || 0;

/** Compact shadcn Select for section headers (period / year-range pickers). */
export function MiniSelect({
  value,
  onValueChange,
  options,
  label,
  className,
}: {
  value: string;
  onValueChange: (v: string) => void;
  options: { value: string; label: string }[];
  label: string;
  className?: string;
}) {
  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger
        size="sm"
        aria-label={label}
        className={cn(
          "-my-[6px] h-[30px] gap-[6px] rounded-[10px] border-bd-card-border bg-bd-surface px-[10px] text-[12px] font-medium text-bd-primary shadow-none data-[size=sm]:h-[30px] xl:text-[14px] [&_svg]:text-bd-muted [&_svg]:opacity-100",
          className,
        )}
      >
        <SelectValue />
      </SelectTrigger>
      <SelectContent align="end" className="rounded-[12px] border-bd-card-border">
        {options.map((o) => (
          <SelectItem key={o.value} value={o.value} className="rounded-[8px] text-[13px] text-bd-primary focus:bg-bd-page focus:text-bd-royal">
            {o.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
