/**
 * Accounts page icons — hand-built approximations of the Figma glyphs
 * (figma.com asset export is blocked in the build sandbox). All use currentColor.
 */
import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;
const base = (p: P) => ({ width: 30, height: 30, viewBox: "0 0 30 30", fill: "currentColor", ...p });

/** "money-tag" — money bag with $ */
export const MoneyBagIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M10.2 3.2c-.5-.8.1-1.7 1-1.7h7.6c.9 0 1.5.9 1 1.7l-2 3.3h-5.6l-2-3.3Z" />
    <rect x="10.8" y="7.6" width="8.4" height="2" rx="1" />
    <path d="M11.2 10.8h7.6c3.9 2.6 6.7 6.6 6.7 10.4 0 4.3-3 7.3-7.3 7.3h-6.4c-4.3 0-7.3-3-7.3-7.3 0-3.8 2.8-7.8 6.7-10.4Z" />
    <path
      fill="#fff"
      d="M15.8 13.3v1c1.1.2 1.9.8 2.3 1.6l-1.5.8c-.3-.5-.8-.8-1.6-.8-.8 0-1.2.4-1.2.8 0 1.5 4.6.6 4.6 3.9 0 1.4-1 2.4-2.6 2.6v1h-1.6v-1c-1.2-.2-2.2-.8-2.7-1.7l1.5-.9c.4.6 1 1 1.9 1 .8 0 1.3-.3 1.3-.9 0-1.6-4.6-.6-4.6-3.8 0-1.3 1-2.3 2.6-2.5v-1h1.6Z"
    />
  </svg>
);

/** "Income" — open hand holding a coin */
export const HandCoinIcon = (p: P) => (
  <svg {...base(p)}>
    <circle cx="17" cy="8" r="6.5" />
    <path
      fill="#fff"
      d="M17.6 4.2v.7c.8.1 1.4.6 1.7 1.2l-1.1.6c-.2-.4-.6-.6-1.2-.6s-.9.3-.9.6c0 1.1 3.4.4 3.4 2.9 0 1-.7 1.8-1.9 1.9v.7h-1.2v-.7c-.9-.1-1.6-.6-2-1.3l1.1-.6c.3.5.7.7 1.4.7.6 0 1-.2 1-.6 0-1.2-3.4-.4-3.4-2.8 0-1 .7-1.7 1.9-1.9v-.7h1.2Z"
    />
    <path d="M1.5 18.5h3.8v9H1.5z" />
    <path d="M6.8 18.6c2.4-1.5 5-1.9 7.6-.8l3.6 1.4c1 .4 1 1.9-.1 2.2l-4.4.6v.6l5.6-.2 5.6-3.6c1-.6 2.2.3 1.9 1.4-.1.4-.4.7-.7.9l-7.4 5.6c-.6.4-1.3.6-2 .6H6.8V18.6Z" />
  </svg>
);

/** "001-medical" — bill/receipt with a coin */
export const ReceiptCoinIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M5 3.5A2 2 0 0 1 7 1.5h13a2 2 0 0 1 2 2v9.2a7.6 7.6 0 0 0-6.7 12.8H6.3L5 26.6V3.5Z" />
    <path fill="#fff" d="M9.3 5.2h1.5v1.6h1.6v1.5h-1.6v1.6H9.3V8.3H7.7V6.8h1.6V5.2Zm5.5 1.6h4.4v1.5h-4.4V6.8ZM7.7 12h4.7v1.5H7.7V12Zm0 3.6h4.7v1.5H7.7v-1.5Zm8.8-3.6 3.8 0" />
    <circle cx="21.8" cy="21" r="6.3" />
    <path
      fill="#fff"
      d="M22.4 17.2v.7c.8.1 1.4.6 1.7 1.2l-1.1.6c-.2-.4-.6-.6-1.2-.6s-.9.3-.9.6c0 1.1 3.4.4 3.4 2.9 0 1-.7 1.8-1.9 1.9v.7h-1.2v-.7c-.9-.1-1.6-.6-2-1.3l1.1-.6c.3.5.7.7 1.4.7.6 0 1-.2 1-.6 0-1.2-3.4-.4-3.4-2.8 0-1 .7-1.7 1.9-1.9v-.7h1.2Z"
    />
  </svg>
);

/** "003-saving" — piggy bank with coin */
export const PiggyBankIcon = (p: P) => (
  <svg {...base(p)}>
    <circle cx="9.5" cy="6.3" r="5.3" />
    <path
      fill="#fff"
      d="M10 3.2v.6c.7.1 1.2.5 1.4 1l-.9.5c-.2-.3-.5-.5-1-.5s-.7.2-.7.5c0 .9 2.8.3 2.8 2.4 0 .8-.6 1.5-1.6 1.6v.6h-1v-.6c-.7-.1-1.3-.5-1.6-1.1l.9-.5c.2.4.6.6 1.1.6s.8-.2.8-.5c0-1-2.8-.3-2.8-2.3 0-.8.6-1.4 1.6-1.5v-.6h1Z"
    />
    <path d="M24.4 9.3c.5-.1 1 .3 1 .8v2.4a8 8 0 0 1 1.8 3.1h1.3c.6 0 1 .4 1 1v3.6c0 .6-.4 1-1 1h-1.7a9 9 0 0 1-3 3v2.6c0 .6-.4 1-1 1h-2.6c-.5 0-1-.4-1-1v-1.4h-5.4v1.4c0 .6-.4 1-1 1H9.7c-.6 0-1-.4-1-1v-3.1a8.4 8.4 0 0 1-3.2-6.2H4.2A2.9 2.9 0 0 1 1.3 14.6c0-.5.4-.9.9-.9s.9.4.9.9c0 .6.5 1.1 1.1 1.1h1.5A9 9 0 0 1 14.3 9h5.2c1.3-.6 3.2-1.1 4.9.3Z" />
    <circle cx="21.6" cy="15.2" r="1.1" fill="#fff" />
  </svg>
);

/** "renew" — circular arrows around a $ */
export const RenewIcon = (p: P) => (
  <svg {...base(p)} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M4.5 12.5A10.8 10.8 0 0 1 24.8 9" />
    <path d="m25.6 4.2-.6 5-4.9-.9" />
    <path d="M25.5 17.5A10.8 10.8 0 0 1 5.2 21" />
    <path d="m4.4 25.8.6-5 4.9.9" />
    <path d="M17.6 11.4c-.5-.9-1.4-1.3-2.6-1.3-1.5 0-2.5.8-2.5 1.9 0 2.7 5.2 1.4 5.2 4.1 0 1.2-1.1 2-2.7 2-1.3 0-2.3-.5-2.8-1.4M15 8.6v1.5m0 8v1.5" />
  </svg>
);

/** "settings 2" — crossed wrench + screwdriver */
export const ToolsIcon = (p: P) => (
  <svg {...base(p)} fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round">
    <path d="M12.2 8.4a6 6 0 0 0-7.6-7l3.3 3.3-.6 2.7-2.7.6-3.3-3.3a6 6 0 0 0 7 7.6L21.7 25.6a2.6 2.6 0 0 0 3.7-3.7L12.2 8.4Z" />
    <path d="M17.2 12.6 25 4.8l-.7-2.6-1.6-.5-2.6.8-7.8 7.8" />
    <path d="m11.6 18.2-6.3 6.3a2.3 2.3 0 0 1-3.3-3.3l6.3-6.3" />
  </svg>
);

/** "user2" — outlined user */
export const UserOutlineIcon = (p: P) => (
  <svg {...base(p)} fill="none" stroke="currentColor" strokeWidth={2}>
    <circle cx="15" cy="9" r="6.5" />
    <path d="M3 28.5a12 12 0 0 1 24 0" strokeLinecap="round" />
  </svg>
);

/** "apple 2" — outlined Apple logo */
export const AppleLogoIcon = (p: P) => (
  <svg {...base(p)} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinejoin="round">
    <path d="M20.3 15.8c0-3 2.4-4.4 2.6-4.5-1.4-2.1-3.6-2.4-4.4-2.4-1.9-.2-3.6 1.1-4.6 1.1-.9 0-2.4-1.1-3.9-1-2 0-3.9 1.2-5 3-2.1 3.7-.5 9.2 1.5 12.2 1 1.5 2.2 3.1 3.8 3 1.5-.1 2.1-1 3.9-1 1.8 0 2.3 1 3.9 1 1.6 0 2.7-1.5 3.6-3 1.1-1.7 1.6-3.3 1.6-3.4-.1 0-3-1.2-3-5Z" />
    <path d="M17.4 6.6c.8-1 1.4-2.4 1.2-3.8-1.2.1-2.6.8-3.5 1.8-.8.9-1.4 2.3-1.2 3.7 1.3.1 2.7-.7 3.5-1.7Z" />
  </svg>
);

/** "playstation" — outlined PlayStation logo */
export const PlaystationIcon = (p: P) => (
  <svg {...base(p)} fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinejoin="round">
    <path d="M11.5 3.5v21.3l4.4 1.4V8.3c0-.8.4-1.4 1-1.2.8.2.9 1 .9 1.8v7.1c2.7 1.3 4.9 0 4.9-3.6 0-3.7-1.3-5.4-5-6.7-1.5-.5-4.2-1.4-6.2-2.2Z" />
    <path d="M17.4 22.5l7.4-2.7c.8-.3.9-.8.2-1-.7-.2-1.9-.2-2.8.1l-4.8 1.7m-5.9 1.3-6.2 2.2c-.9.3-1 .8-.3 1 .9.3 2.4.3 3.4-.1l3.1-1.1m0-4.1-4.3 1.5c-2.9 1-3.3 2.6-.8 3.4" />
  </svg>
);
