"use client";

import Link from "next/link";
import { BankCard } from "@/components/shared/bank-card";
import { Panel } from "@/components/shared/section";
import { money, useApp } from "@/lib/store";

/** First card from the store, styled like the Figma "My Card" tile. */
export function MyCard() {
  const card = useApp((s) => s.cards[0]);
  if (!card) {
    return (
      <Panel className="flex h-[197px] flex-col items-center justify-center gap-2 text-center lg:h-[170px] xl:h-[235px]">
        <p className="text-[14px] text-bd-muted">No cards yet</p>
        <Link href="/credit-cards" className="text-[14px] font-semibold text-bd-royal hover:underline">
          Add a card
        </Link>
      </Panel>
    );
  }
  return (
    <Link href="/credit-cards" aria-label={`Card ending ${card.number.slice(-4)} — manage cards`} className="block rounded-[15px] outline-none focus-visible:ring-[3px] focus-visible:ring-bd-royal/30 xl:rounded-[25px]">
      <BankCard
        card={{ balance: money(card.balance), holder: card.holder, validThru: card.validThru, number: card.number, variant: "blue" }}
        className="h-[197px] bg-[linear-gradient(115deg,#2D60FF_2.6%,#539BFF_101.2%)] lg:h-[170px] xl:h-[235px]"
      />
    </Link>
  );
}
