"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { format, subDays, subHours } from "date-fns";
import { Download } from "lucide-react";
import { toast } from "sonner";
import { Panel } from "@/components/shared/section";
import { listContainer, listItem } from "@/components/shared/motion";
import { downloadFile, receiptHtml } from "@/lib/download";
import { money } from "@/lib/store";
import { cn } from "@/lib/utils";
import { BdDialog, DetailRows, GhostButton, PrimaryButton } from "./dialog-kit";
import { AppleLogoIcon, PlaystationIcon, UserOutlineIcon } from "./icons";

interface Invoice {
  id: string;
  name: string;
  email: string;
  ago: string;
  /** offset used to compute the issue date */
  hoursAgo: number;
  amount: number;
  item: string;
  status: "Paid" | "Sent";
  icon: typeof AppleLogoIcon;
  bg: string;
  fg: string;
}

const INVOICES: Invoice[] = [
  { id: "INV-2041", name: "Apple Store", email: "billing@apple.com", ago: "5h ago", hoursAgo: 5, amount: 450, item: "UI design consultation", status: "Sent", icon: AppleLogoIcon, bg: "bg-bd-tint-teal", fg: "text-[#16DBCC]" },
  { id: "INV-2038", name: "Michael", email: "michael@mail.com", ago: "2 days ago", hoursAgo: 48, amount: 160, item: "Landing page review", status: "Paid", icon: UserOutlineIcon, bg: "bg-bd-tint-yellow", fg: "text-[#FFBB38]" },
  { id: "INV-2033", name: "Playstation", email: "accounts@playstation.com", ago: "5 days ago", hoursAgo: 120, amount: 1085, item: "Store banner set (12)", status: "Paid", icon: PlaystationIcon, bg: "bg-bd-tint-blue", fg: "text-[#396AFF]" },
  { id: "INV-2027", name: "William", email: "william@mail.com", ago: "10 days ago", hoursAgo: 240, amount: 90, item: "Logo refresh", status: "Sent", icon: UserOutlineIcon, bg: "bg-bd-tint-pink", fg: "text-[#FF82AC]" },
];

const issued = (inv: Invoice) => (inv.hoursAgo < 24 ? subHours(new Date(), inv.hoursAgo) : subDays(new Date(), inv.hoursAgo / 24));

export function InvoicesSent() {
  const [sel, setSel] = useState<Invoice | null>(null);

  const download = (inv: Invoice) => {
    downloadFile(
      `invoice-${inv.id}.html`,
      receiptHtml(`Invoice ${inv.id}`, [
        ["Billed to", inv.name],
        ["Email", inv.email],
        ["Issued", format(issued(inv), "d MMM yyyy")],
        ["Item", inv.item],
        ["Status", inv.status],
        ["Total", money(inv.amount)],
      ]),
      "text/html;charset=utf-8",
    );
    toast.success(`Invoice ${inv.id} downloaded`);
  };

  return (
    <Panel className="h-full px-[20px] py-[20px] lg:pb-[19px] xl:px-[25px] xl:pt-[30px] xl:pb-[31px]">
      <motion.ul
        variants={listContainer}
        initial="hidden"
        animate="show"
        className="flex h-full flex-col gap-[15px] lg:justify-between lg:gap-[17px] xl:gap-[21px]"
      >
        {INVOICES.map((inv) => (
          <motion.li key={inv.id} variants={listItem} whileHover={{ x: 4 }}>
            <button
              type="button"
              onClick={() => setSel(inv)}
              aria-label={`Invoice to ${inv.name}, ${money(inv.amount)} — view`}
              className="flex w-full cursor-pointer items-center gap-[12px] rounded-[12px] text-left outline-none focus-visible:ring-[3px] focus-visible:ring-bd-royal/30 xl:gap-[20px]"
            >
              <span
                className={cn(
                  "flex size-[45px] shrink-0 items-center justify-center rounded-[15px] xl:size-[60px] xl:rounded-[20px]",
                  inv.bg,
                  inv.fg,
                )}
              >
                <inv.icon className="size-[20px] lg:size-[18px] xl:size-[25px]" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[14px] leading-[17px] font-medium text-bd-text lg:text-[13px] lg:leading-[16px] xl:text-[16px] xl:leading-[19px] xl:text-bd-nav">
                  {inv.name}
                </p>
                <p className="mt-[4px] text-[12px] leading-[15px] text-bd-muted xl:mt-[7px] xl:text-[15px] xl:leading-[18px]">{inv.ago}</p>
              </div>
              <span className="shrink-0 text-[12px] text-bd-muted lg:text-[13px] xl:text-[16px]">${inv.amount}</span>
            </button>
          </motion.li>
        ))}
      </motion.ul>

      <BdDialog open={!!sel} onOpenChange={(o) => !o && setSel(null)} title={sel ? `Invoice ${sel.id}` : "Invoice"} description={sel ? `Sent to ${sel.name}` : undefined}>
        {sel && (
          <>
            <div className="mb-[16px] flex items-end justify-between">
              <p className="text-[28px] font-semibold text-bd-primary">{money(sel.amount)}</p>
              <span
                className={cn(
                  "rounded-full px-[12px] py-[4px] text-[12px] font-medium",
                  sel.status === "Paid" ? "bg-bd-tint-teal text-[#16DBAA]" : "bg-bd-tint-yellow text-[#FFBB38]",
                )}
              >
                {sel.status}
              </span>
            </div>
            <DetailRows
              rows={[
                ["Billed to", sel.name],
                ["Email", sel.email],
                ["Issued", format(issued(sel), "d MMM yyyy")],
                ["Item", sel.item],
              ]}
            />
            <div className="mt-[20px] flex flex-col-reverse gap-[10px] sm:flex-row sm:justify-end">
              <GhostButton onClick={() => setSel(null)}>Close</GhostButton>
              <PrimaryButton onClick={() => download(sel)}>
                <Download className="size-4" /> Download invoice
              </PrimaryButton>
            </div>
          </>
        )}
      </BdDialog>
    </Panel>
  );
}
