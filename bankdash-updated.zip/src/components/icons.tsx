/**
 * BankDash icon set — hand-built SVGs approximating the Figma icons
 * (figma.com asset export was blocked in the build sandbox).
 * All icons use `currentColor` so they can be recoloured for active/inactive states.
 */
import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;
const base = (p: P) => ({ width: 25, height: 25, viewBox: "0 0 25 25", fill: "currentColor", ...p });

export const LogoIcon = (p: P) => (
  <svg width={36} height={36} viewBox="0 0 36 36" fill="none" {...p}>
    <rect x="9" y="5" width="25" height="18" rx="3" stroke="#1814F3" strokeWidth="2.6" fill="var(--color-bd-surface)" />
    <rect x="2" y="11" width="25" height="18" rx="3" stroke="#1814F3" strokeWidth="2.6" fill="var(--color-bd-surface)" />
    <rect x="2" y="16" width="25" height="3.5" fill="#1814F3" />
    <rect x="6" y="22.5" width="9" height="2.6" rx="1.3" fill="#FA00FF" />
  </svg>
);

export const HomeIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M24.4 11.3 13.4 1.1a1.3 1.3 0 0 0-1.8 0L.6 11.3c-.6.6-.2 1.6.6 1.6h2.4v10.4c0 .7.6 1.2 1.2 1.2h5.5v-7h4.4v7h5.5c.7 0 1.2-.5 1.2-1.2V12.9h2.4c.9 0 1.2-1 .6-1.6Z" />
  </svg>
);

export const TransferIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M7 1h12.5A1.5 1.5 0 0 1 21 2.5V14h-3V4H8v4H5V3a2 2 0 0 1 2-2Z" />
    <rect x="9.5" y="5.5" width="7" height="1.8" rx=".9" />
    <rect x="9.5" y="9" width="7" height="1.8" rx=".9" />
    <path d="M1 12.5h12a1.5 1.5 0 0 1 1.5 1.5v9.5A1.5 1.5 0 0 1 13 25H1a1 1 0 0 1-1-1V13.5a1 1 0 0 1 1-1Zm6 2.3a.8.8 0 0 0-.8.8v.5a2 2 0 0 0 .3 3.9h1a.6.6 0 1 1 0 1.2H5.6a.8.8 0 0 0 0 1.6h.6v.5a.8.8 0 0 0 1.6 0v-.5a2 2 0 0 0-.3-3.9h-1a.6.6 0 1 1 0-1.2h1.9a.8.8 0 0 0 0-1.6h-.6v-.5a.8.8 0 0 0-.8-.8Z" />
    <path d="m19 17 5 3.5-5 3.5v-2.2h-3.5v-2.6H19V17Z" />
  </svg>
);

export const UserIcon = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12.5" cy="6.5" r="6" />
    <path d="M2.5 25a10 10 0 0 1 20 0h-20Z" />
  </svg>
);

export const InvestmentIcon = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12.5" cy="5" r="5" />
    <path fill="#fff" d="M12.9 2.2v.5c.6.1 1 .4 1.3.8l-.8.6a1 1 0 0 0-.9-.4c-.4 0-.6.2-.6.4 0 .7 2.4.3 2.4 2 0 .8-.6 1.3-1.4 1.4v.5h-.8v-.5a2 2 0 0 1-1.4-.8l.8-.6c.2.3.6.5 1 .5s.6-.2.6-.4c0-.8-2.4-.3-2.4-2 0-.7.5-1.2 1.3-1.3v-.5h.9Z" />
    <rect x="0" y="13" width="4" height="12" rx="1" />
    <rect x="5.5" y="15" width="4" height="10" rx="1" />
    <rect x="11" y="12" width="4" height="13" rx="1" />
    <rect x="16.5" y="15" width="4" height="10" rx="1" />
    <rect x="22" y="17" width="3" height="8" rx="1" />
  </svg>
);

export const CreditCardIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M2.5 3.5h18A2.5 2.5 0 0 1 23 6v1H0V6a2.5 2.5 0 0 1 2.5-2.5ZM0 9.5h23V12a7 7 0 0 0-8.6 9.5H2.5A2.5 2.5 0 0 1 0 19V9.5Zm3 6.5v2h6v-2H3Z" />
    <circle cx="20" cy="18" r="5" />
    <path fill="#fff" d="M20.4 15.2v.5c.6.1 1 .4 1.3.8l-.8.6a1 1 0 0 0-.9-.4c-.4 0-.6.2-.6.4 0 .7 2.4.3 2.4 2 0 .8-.6 1.3-1.4 1.4v.5h-.8V20.5a2 2 0 0 1-1.4-.8l.8-.6c.2.3.6.5 1 .5s.6-.2.6-.4c0-.8-2.4-.3-2.4-2 0-.7.5-1.2 1.3-1.3v-.5h.9Z" />
  </svg>
);

export const LoanIcon = (p: P) => (
  <svg {...base(p)}>
    <circle cx="13.5" cy="6.5" r="6.2" />
    <path fill="#fff" d="M14 2.8v.7c.8.1 1.4.5 1.8 1.1l-1 .8c-.3-.4-.7-.6-1.2-.6s-.8.2-.8.6c0 1 3.2.4 3.2 2.7 0 1-.8 1.7-2 1.9v.7h-1.1v-.7a2.6 2.6 0 0 1-1.9-1.1l1.1-.8c.3.4.8.7 1.3.7s.9-.2.9-.6c0-1-3.2-.4-3.2-2.6 0-1 .7-1.6 1.8-1.8v-.7H14Z" />
    <path d="M0 15.5h3.5V25H0v-9.5Zm5 .3c1.4-.9 3.3-1.3 5-.8l4.5 1.3c.9.3 1.3 1.2 1 2-.2.8-1 1.2-1.8 1l-3.4-.6-.2.8 3.6.8c1.2.2 2.3-.1 3.2-.8l3.6-2.8c.7-.5 1.7-.4 2.2.3.5.6.4 1.5-.2 2l-5.3 5c-1 .9-2.3 1.3-3.6 1.2L5 23.5v-7.7Z" />
  </svg>
);

export const ServiceIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M19 .3a5.5 5.5 0 0 0-5.3 7.2L.9 20.3a2.4 2.4 0 0 0 3.4 3.4l12.8-12.8A5.5 5.5 0 0 0 24.6 6l-3.2 3.2-3.4-.9-.9-3.4L20.3.7A5.6 5.6 0 0 0 19 .3Z" />
    <path d="m2 1.5 3-1.2 3.4 3.4v2.2l4 4-2 2-4-4H4.2L.8 4.5 2 1.5Zm12.5 13.2 2-2 7.2 7.2a2.4 2.4 0 0 1 0 3.3l-.7.7a2.4 2.4 0 0 1-3.3 0l-7.2-7.2 2-2Z" />
  </svg>
);

export const PrivilegeIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M12.5 0a8.6 8.6 0 0 0-5 15.6c.6.4 1 1.1 1 1.9v.8h8v-.8c0-.8.4-1.5 1-1.9A8.6 8.6 0 0 0 12.5 0Zm.5 3.4v.8c.9.1 1.6.6 2 1.2l-1.1.8c-.3-.4-.7-.7-1.3-.7s-.9.3-.9.6c0 1.1 3.4.5 3.4 2.9 0 1.1-.9 1.9-2.1 2v.8h-1.2V11a2.8 2.8 0 0 1-2-1.2l1.1-.8c.3.5.8.8 1.4.8.5 0 1-.3 1-.7 0-1.1-3.4-.5-3.4-2.8 0-1 .8-1.8 1.9-1.9v-.9H13Z" />
    <rect x="8.5" y="19.5" width="8" height="2" rx="1" />
    <path d="M10 23h5a2.5 2.5 0 0 1-5 0Z" />
    <path d="M0 9.5h2.5v1.8H0zM22.5 9.5H25v1.8h-2.5zM2.6 2.2l1.8 1.8-1.3 1.3-1.8-1.8zM22.4 2.2l1.3 1.3-1.8 1.8-1.3-1.3z" />
  </svg>
);

export const SettingIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M24.2 10.2 21.6 9.8a9.6 9.6 0 0 0-.9-2.2l1.6-2.1a.9.9 0 0 0-.1-1.2l-1.5-1.5a.9.9 0 0 0-1.2-.1l-2.1 1.6a9.6 9.6 0 0 0-2.2-.9L14.8.8A.9.9 0 0 0 13.9 0h-2.2a.9.9 0 0 0-.9.8l-.4 2.6a9.6 9.6 0 0 0-2.2.9L6.1 2.7a.9.9 0 0 0-1.2.1L3.4 4.3a.9.9 0 0 0-.1 1.2l1.6 2.1a9.6 9.6 0 0 0-.9 2.2l-2.6.4a.9.9 0 0 0-.8.9v2.2c0 .4.3.8.8.9l2.6.4c.2.8.5 1.5.9 2.2l-1.6 2.1a.9.9 0 0 0 .1 1.2l1.5 1.5c.3.3.8.4 1.2.1l2.1-1.6c.7.4 1.4.7 2.2.9l.4 2.6c.1.5.5.8.9.8h2.2c.4 0 .8-.3.9-.8l.4-2.6c.8-.2 1.5-.5 2.2-.9l2.1 1.6c.4.3.9.2 1.2-.1l1.5-1.5c.3-.3.4-.8.1-1.2l-1.6-2.1c.4-.7.7-1.4.9-2.2l2.6-.4c.5-.1.8-.5.8-.9v-2.2a.9.9 0 0 0-.8-.9ZM12.5 17a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9Z" />
  </svg>
);

export const SearchIcon = (p: P) => (
  <svg width={20} height={20} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth={1.8} {...p}>
    <circle cx="8.5" cy="8.5" r="7" />
    <path d="m13.8 13.8 5 5" strokeLinecap="round" />
  </svg>
);

export const GearOutlineIcon = (p: P) => (
  <svg width={25} height={25} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinejoin="round" {...p}>
    <path d="M10.3 2.6c.4-1.6 2.9-1.6 3.4 0a1.7 1.7 0 0 0 2.6 1.1c1.4-.9 3.2.9 2.3 2.3a1.7 1.7 0 0 0 1.1 2.6c1.6.4 1.6 2.9 0 3.4a1.7 1.7 0 0 0-1.1 2.6c.9 1.4-.9 3.2-2.3 2.3a1.7 1.7 0 0 0-2.6 1.1c-.4 1.6-2.9 1.6-3.4 0a1.7 1.7 0 0 0-2.6-1.1c-1.4.9-3.2-.9-2.3-2.3a1.7 1.7 0 0 0-1.1-2.6c-1.6-.4-1.6-2.9 0-3.4a1.7 1.7 0 0 0 1.1-2.6C4.5 4.6 6.3 2.8 7.7 3.7a1.7 1.7 0 0 0 2.6-1.1Z" transform="translate(0 1.5) scale(.95)" />
    <circle cx="12" cy="12" r="3.2" />
  </svg>
);

export const BellIcon = (p: P) => (
  <svg width={25} height={25} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="M6 9a6 6 0 1 1 12 0c0 6.5 2.5 8 2.5 8h-17S6 15.5 6 9Z" />
    <path d="M10 20.5a2.2 2.2 0 0 0 4 0" />
    <circle cx="17.5" cy="4.5" r="2.5" fill="currentColor" stroke="none" />
  </svg>
);

export const SendIcon = (p: P) => (
  <svg width={26} height={23} viewBox="0 0 26 23" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinejoin="round" {...p}>
    <path d="M25 1 1 9.5l9 3.5L25 1Zm0 0-8 21-7-9" />
    <path d="M10 13v7l3.5-3.5" />
  </svg>
);

export const ChevronRightIcon = (p: P) => (
  <svg width={9} height={15} viewBox="0 0 9 15" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="m1 1 6.5 6.5L1 14" />
  </svg>
);

export const MenuIcon = (p: P) => (
  <svg width={18} height={15} viewBox="0 0 18 15" fill="currentColor" {...p}>
    <rect width="18" height="2" rx="1" />
    <rect y="6.5" width="18" height="2" rx="1" />
    <rect y="13" width="18" height="2" rx="1" />
  </svg>
);

export const PaypalIcon = (p: P) => (
  <svg width={20} height={23} viewBox="0 0 20 23" fill="none" stroke="currentColor" strokeWidth={2} strokeLinejoin="round" {...p}>
    <path d="M4.5 21H1.2L4.6 1h7.6c3.4 0 5.6 2 5 5.2-.6 3.4-3.3 5.3-6.6 5.3H7.4L6 19" />
    <path d="M6.3 19.5 7 15h3.3c3 0 5.6-1.7 6.2-4.7" />
  </svg>
);

export const CoinIcon = (p: P) => (
  <svg width={25} height={25} viewBox="0 0 25 25" fill="none" stroke="currentColor" strokeWidth={1.6} {...p}>
    <circle cx="12.5" cy="12.5" r="11" />
    <circle cx="12.5" cy="12.5" r="7.5" />
    <path d="M14.4 10a2 2 0 0 0-1.9-1c-1.1 0-1.9.6-1.9 1.4 0 2 3.8 1 3.8 3.1 0 .8-.8 1.5-1.9 1.5a2.2 2.2 0 0 1-2.1-1.1M12.5 7.5v1.4M12.5 15v1.5" strokeLinecap="round" />
  </svg>
);

export const CardStackIcon = (p: P) => (
  <svg width={28} height={28} viewBox="0 0 28 28" fill="currentColor" {...p}>
    <path d="M7 5h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-1V9a2 2 0 0 0-2-2H5a2 2 0 0 1 2-2Z" opacity=".7" />
    <path d="M5 9h15a2 2 0 0 1 2 2v1H3v-1a2 2 0 0 1 2-2Zm-2 5h19v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7Zm3 4v1.6h5V18H6Z" />
  </svg>
);

/** Card EMV chip — white (on gradient card) or dark (on white card) */
export const ChipIcon = ({ dark = false, ...p }: P & { dark?: boolean }) => {
  const c = dark ? "#343C6A" : "#fff";
  const g = dark ? "#fff" : "#4C49ED";
  return (
    <svg width={35} height={35} viewBox="0 0 35 35" {...p}>
      <rect x="1" y="3" width="33" height="29" rx="7" fill={c} />
      <path d="M1 13h8.5M1 22h8.5M25.5 13H34M25.5 22H34M17.5 3v7M17.5 25v7" stroke={g} strokeWidth="1.4" fill="none" />
      <rect x="9.5" y="10" width="16" height="15" rx="4" stroke={g} strokeWidth="1.4" fill="none" />
    </svg>
  );
};

/** Mastercard-style overlapping circles on card footers */
export const CardBrandIcon = ({ dark = false, ...p }: P & { dark?: boolean }) => (
  <svg width={44} height={30} viewBox="0 0 44 30" {...p}>
    <circle cx="15" cy="15" r="15" fill={dark ? "#9199AF" : "#fff"} fillOpacity={dark ? 0.5 : 0.5} />
    <circle cx="29" cy="15" r="15" fill={dark ? "#9199AF" : "#fff"} fillOpacity={dark ? 0.5 : 0.5} />
  </svg>
);
