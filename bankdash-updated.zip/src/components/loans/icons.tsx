/** Loans page glyphs — hand-built approximations of the Figma icons (asset export is blocked). */
import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;
const base = (p: P) => ({ width: 24, height: 24, viewBox: "0 0 24 24", fill: "currentColor", ...p });

export const BriefcaseIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M8.6 2.5h6.8c.8 0 1.4.6 1.4 1.4v2.2h4.4c1.3 0 2.3 1 2.3 2.3v3.4H.5V8.4c0-1.3 1-2.3 2.3-2.3h4.4V3.9c0-.8.6-1.4 1.4-1.4Zm.6 3.6h5.6V4.4H9.2v1.7Z" />
    <path d="M.5 12.9h9.6v1.7h3.8v-1.7h9.6v6.3c0 1.3-1 2.3-2.3 2.3H2.8c-1.3 0-2.3-1-2.3-2.3v-6.3Z" />
  </svg>
);

export const GraphIcon = (p: P) => (
  <svg {...base(p)}>
    <rect x="2" y="15" width="4.6" height="8" rx="1" />
    <rect x="9.7" y="11" width="4.6" height="12" rx="1" />
    <rect x="17.4" y="7.5" width="4.6" height="15.5" rx="1" />
    <path d="M2.6 11.6 15.2 4.3l-1.5-1.9L21 1l-1.4 7.2-1.6-1.8L4 14.4l-1.4-2.8Z" />
  </svg>
);
