"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check } from "lucide-react";
import { Panel } from "@/components/shared/section";
import { listContainer, listItem } from "@/components/shared/motion";
import { Badge } from "@/components/ui/badge";
import { money } from "@/lib/store";
import { cn } from "@/lib/utils";
import { RepayDialog, type Loan } from "./repay-dialog";

const SEED: Loan[] = [
  { id: "l1", money: 100000, left: 40500, months: 8, rate: 12, installment: 2000 },
  { id: "l2", money: 500000, left: 250000, months: 36, rate: 10, installment: 8000 },
  { id: "l3", money: 900000, left: 40500, months: 12, rate: 12, installment: 5000 },
  { id: "l4", money: 50000, left: 40500, months: 25, rate: 5, installment: 2000 },
  { id: "l5", money: 50000, left: 40500, months: 5, rate: 16, installment: 10000 },
  { id: "l6", money: 80000, left: 25500, months: 14, rate: 8, installment: 2000 },
  { id: "l7", money: 12000, left: 5500, months: 9, rate: 13, installment: 500 },
  { id: "l8", money: 160000, left: 100800, months: 3, rate: 12, installment: 900 },
];

/**
 * Column grid from Figma x offsets.
 * Mobile shows Loan Money / Left to repay / Repay only; tablet + desktop show all 7 columns.
 */
const cols =
  "grid items-center grid-cols-[minmax(0,106fr)_minmax(0,109fr)_70px] lg:grid-cols-[minmax(0,58fr)_minmax(0,115fr)_minmax(0,117fr)_minmax(0,104fr)_minmax(0,104fr)_minmax(0,125fr)_80px] xl:grid-cols-[minmax(0,100fr)_minmax(0,168fr)_minmax(0,174fr)_minmax(0,171fr)_minmax(0,147fr)_minmax(0,172fr)_118px]";
const wide = "hidden lg:block";

export function LoansTable() {
  const [loans, setLoans] = useState<Loan[]>(SEED);
  const [active, setActive] = useState(0);
  const [repayId, setRepayId] = useState<string | null>(null);
  const repayIdx = loans.findIndex((l) => l.id === repayId);
  const repayLoan = repayIdx >= 0 ? loans[repayIdx] : null;

  const totals = loans.reduce(
    (t, l) => ({ money: t.money + l.money, left: t.left + l.left, installment: t.installment + (l.left > 0 ? l.installment : 0) }),
    { money: 0, left: 0, installment: 0 },
  );

  return (
    <Panel hover={false} className="px-[20px] pt-[17px] pb-[18px] lg:pt-[22px] lg:pb-[22px] xl:px-[30px] xl:pt-[22px] xl:pb-[21px]">
      <div role="table" aria-label="Active Loans Overview" className="text-[12px] leading-[15px] text-bd-text xl:text-[16px] xl:leading-[19px]">
        {/* Header */}
        <div role="row" className={cn(cols, "border-b border-bd-border pb-[7px] font-medium text-bd-muted xl:pb-[11px]")}>
          <span role="columnheader" className={wide}>SL No</span>
          <span role="columnheader">Loan Money</span>
          <span role="columnheader">Left to repay</span>
          <span role="columnheader" className={wide}>Duration</span>
          <span role="columnheader" className={wide}>Interest rate</span>
          <span role="columnheader" className={wide}>Installment</span>
          <span role="columnheader">Repay</span>
        </div>

        {/* Rows */}
        <motion.div variants={listContainer} initial="hidden" animate="show">
          {loans.map((l, i) => {
            const isActive = active === i;
            const paid = l.left <= 0;
            return (
              <motion.div
                key={l.id}
                role="row"
                variants={listItem}
                className={cn(
                  cols,
                  "border-b border-bd-border py-[10px] last:border-bd-border transition-colors hover:bg-bd-page lg:py-[10px] xl:pt-[15px] xl:pb-[14px]",
                )}
              >
                <span role="cell" className={wide}>{String(i + 1).padStart(2, "0")}.</span>
                <span role="cell">{money(l.money)}</span>
                <span role="cell">
                  <AnimatePresence mode="popLayout" initial={false}>
                    <motion.span key={l.left} initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }} className={cn("inline-block", paid && "text-bd-muted")}>
                      {money(l.left)}
                    </motion.span>
                  </AnimatePresence>
                </span>
                <span role="cell" className={wide}>{l.months} Months</span>
                <span role="cell" className={wide}>{l.rate}%</span>
                <span role="cell" className={cn(wide, "lg:pl-[2px] xl:pl-0")}>{money(l.installment)} / month</span>
                <span role="cell">
                  {paid ? (
                    <Badge className="flex h-[25px] w-[70px] gap-1 rounded-[50px] border-transparent bg-bd-tint-teal text-[12px] font-medium text-[#16DBAA] lg:h-[30px] lg:w-[80px] xl:h-[35px] xl:w-[100px] xl:text-[15px]">
                      <Check className="size-3 xl:size-4" /> Paid
                    </Badge>
                  ) : (
                    <motion.button
                      type="button"
                      onClick={() => {
                        setActive(i);
                        setRepayId(l.id);
                      }}
                      whileHover={{ scale: 1.04 }}
                      whileTap={{ scale: 0.96 }}
                      aria-label={`Repay loan ${String(i + 1).padStart(2, "0")}`}
                      aria-haspopup="dialog"
                      className={cn(
                        "flex h-[25px] w-[70px] cursor-pointer items-center justify-center rounded-[50px] border border-bd-royal text-[12px] font-medium text-bd-royal transition-colors lg:h-[30px] lg:w-[80px] xl:h-[35px] xl:w-[100px] xl:text-[15px]",
                        isActive
                          ? "lg:border-bd-royal lg:text-bd-royal"
                          : "lg:border-bd-text lg:text-bd-text lg:hover:border-bd-royal lg:hover:text-bd-royal",
                      )}
                    >
                      Repay
                    </motion.button>
                  )}
                </span>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Totals */}
        <div
          role="row"
          className={cn(
            cols,
            "items-start gap-y-[5px] pt-[5px] font-medium text-bd-pink lg:pt-[10px] xl:pt-[12px]",
          )}
        >
          <span role="cell" className="col-span-3 lg:col-span-1">Total</span>
          <span role="cell">{money(totals.money)}</span>
          <span role="cell">{money(totals.left)}</span>
          <span className={wide} />
          <span className={wide} />
          <span role="cell" className={cn(wide, "lg:pl-[2px] xl:pl-0")}>{money(totals.installment)} / month</span>
        </div>
      </div>

      <RepayDialog
        loan={repayLoan}
        index={repayIdx}
        onOpenChange={(o) => !o && setRepayId(null)}
        onRepaid={(id, amt) => {
          setLoans((xs) => xs.map((x) => (x.id === id ? { ...x, left: Math.max(0, x.left - amt) } : x)));
          setRepayId(null);
        }}
      />
    </Panel>
  );
}
