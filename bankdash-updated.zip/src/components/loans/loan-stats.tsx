"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Panel } from "@/components/shared/section";
import { CountUp, FadeUp } from "@/components/shared/motion";
import { ServiceIcon, UserIcon } from "@/components/icons";
import { cn } from "@/lib/utils";
import { BriefcaseIcon, GraphIcon } from "./icons";
import { ApplyLoanDialog, type LoanType } from "./apply-loan-dialog";

const STATS = [
  { type: "personal", label: "Personal Loans", value: 50000, icon: UserIcon, bg: "bg-bd-tint-blue", fg: "text-[#396AFF]" },
  { type: "corporate", label: "Corporate Loans", value: 100000, icon: BriefcaseIcon, bg: "bg-bd-tint-yellow", fg: "text-[#FFBB38]" },
  { type: "business", label: "Business Loans", value: 500000, icon: GraphIcon, bg: "bg-bd-tint-pink", fg: "text-[#FF82AC]" },
  { type: "custom", label: "Custom Loans", value: null, icon: ServiceIcon, bg: "bg-bd-tint-teal", fg: "text-[#16DBCC]" },
] as const;

export function LoanStats() {
  const [applying, setApplying] = useState<LoanType | null>(null);
  return (
    <>
      <div className="no-scrollbar -mx-[25px] flex snap-x scroll-px-[25px] gap-[15px] overflow-x-auto px-[25px] lg:mx-0 lg:grid lg:grid-cols-4 lg:gap-[25px] lg:overflow-visible lg:px-0 xl:gap-[30px]">
        {STATS.map((s) => (
          <FadeUp key={s.label} className="w-[230px] shrink-0 snap-start lg:w-auto">
            <button
              type="button"
              onClick={() => setApplying(s.type)}
              aria-label={`${s.label} — apply for loan`}
              className="block w-full cursor-pointer rounded-[15px] text-left outline-none focus-visible:ring-[3px] focus-visible:ring-bd-royal/30 lg:rounded-[20px] xl:rounded-[25px]"
            >
              <Panel className="flex h-[85px] items-center justify-center px-[8px] lg:h-[90px] xl:h-[120px]">
                <div className="flex items-center gap-[12px] lg:gap-[10px] xl:gap-[12px] min-[87.5rem]:gap-[15px]">
                  <motion.span
                    whileHover={{ rotate: -12, scale: 1.08 }}
                    transition={{ type: "spring", stiffness: 300, damping: 15 }}
                    className={cn("flex size-[45px] shrink-0 items-center justify-center rounded-full xl:size-[60px] min-[87.5rem]:size-[70px]", s.bg, s.fg)}
                  >
                    <s.icon className="size-[20px] lg:size-[18px] xl:size-[26px] min-[87.5rem]:size-[30px]" />
                  </motion.span>
                  <div className="min-w-0">
                    <p className="text-[12px] leading-[15px] whitespace-nowrap text-bd-muted lg:text-[11px] lg:leading-[13px] xl:text-[14px] xl:leading-[19px] min-[87.5rem]:text-[16px]">
                      {s.label}
                    </p>
                    {s.value === null ? (
                      <p className="mt-[4px] text-[16px] leading-[19px] font-semibold whitespace-nowrap text-bd-text lg:mt-[5px] lg:text-[13px] lg:leading-[16px] xl:mt-[8px] xl:text-[16px] xl:leading-[22px] min-[87.5rem]:text-[18px]">
                        Choose Money
                      </p>
                    ) : (
                      <p className="mt-[4px] text-[16px] leading-[19px] font-semibold text-bd-text lg:mt-[5px] xl:mt-[8px] xl:text-[18px] xl:leading-[24px] min-[87.5rem]:text-[20px]">
                        <CountUp value={s.value} prefix="$" />
                      </p>
                    )}
                  </div>
                </div>
              </Panel>
            </button>
          </FadeUp>
        ))}
      </div>
      <ApplyLoanDialog type={applying} onOpenChange={(o) => !o && setApplying(null)} />
    </>
  );
}
