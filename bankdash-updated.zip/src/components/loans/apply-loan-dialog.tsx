"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { format, parse } from "date-fns";
import { toast } from "sonner";
import { CheckboxField, DatePicker, Field, SelectField, TextInput } from "@/components/shared/form-controls";
import { BdDialog, GhostButton, PrimaryButton, useFormFx } from "@/components/accounts/dialog-kit";
import { money, useApp } from "@/lib/store";

export const LOAN_TYPES = [
  { value: "personal", label: "Personal Loan", max: 50000 },
  { value: "corporate", label: "Corporate Loan", max: 100000 },
  { value: "business", label: "Business Loan", max: 500000 },
  { value: "custom", label: "Custom Loan", max: 1000000 },
] as const;
export type LoanType = (typeof LOAN_TYPES)[number]["value"];

const DURATIONS = [6, 12, 24, 36, 48, 60].map((m) => ({ value: String(m), label: `${m} months` }));
const startOfToday = () => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
};

export function ApplyLoanDialog({ type, onOpenChange }: { type: LoanType | null; onOpenChange: (v: boolean) => void }) {
  return (
    <BdDialog open={!!type} onOpenChange={onOpenChange} title="Apply for loan" description="Tell us what you need — we'll get back within 24 hours.">
      {type && <ApplyForm key={type} initialType={type} onDone={() => onOpenChange(false)} />}
    </BdDialog>
  );
}

function ApplyForm({ initialType, onDone }: { initialType: LoanType; onDone: () => void }) {
  const notify = useApp((s) => s.notify);
  const [loanType, setLoanType] = useState<string>(initialType);
  const [amount, setAmount] = useState("");
  const [duration, setDuration] = useState("");
  const [start, setStart] = useState("");
  const [terms, setTerms] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { controls, shake, loading, run } = useFormFx();
  /** Clear a field's error as soon as the user edits it. */
  const edit =
    <T,>(key: string, set: (v: T) => void) =>
    (v: T) => {
      set(v);
      setErrors((e) => (e[key] ? { ...e, [key]: "" } : e));
    };

  const meta = LOAN_TYPES.find((t) => t.value === loanType);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const n = Number(amount);
    const errs: Record<string, string> = {};
    if (!meta) errs.type = "Choose a loan type";
    if (!amount.trim() || !Number.isFinite(n) || n <= 0) errs.amount = "Enter the amount you need";
    else if (n < 1000) errs.amount = "Minimum loan amount is $1,000";
    else if (meta && n > meta.max) errs.amount = `${meta.label}s go up to ${money(meta.max)}`;
    if (!duration) errs.duration = "Choose a duration";
    if (!start) errs.start = "Pick a start date";
    if (!terms) errs.terms = "You must accept the terms to continue";
    setErrors(errs);
    if (Object.keys(errs).length || !meta) return void shake();

    run(() => {
      notify({
        title: "Loan application submitted",
        body: `${meta.label} of ${money(n)} for ${duration} months, starting ${format(parse(start, "yyyy-MM-dd", new Date()), "d MMM yyyy")}`,
        kind: "loan",
        href: "/loans",
      });
      toast.success(`${meta.label} application submitted`);
      onDone();
    });
  };

  return (
    <motion.form animate={controls} onSubmit={submit} noValidate className="flex flex-col gap-[16px]">
      <Field label="Loan type" htmlFor="loan-type" error={errors.type}>
        <SelectField id="loan-type" value={loanType} onValueChange={edit("type", setLoanType)} options={LOAN_TYPES.map(({ value, label }) => ({ value, label }))} invalid={!!errors.type} />
      </Field>
      <Field label={`Amount (USD)${meta ? ` · up to ${money(meta.max)}` : ""}`} htmlFor="loan-amount" error={errors.amount}>
        <TextInput
          id="loan-amount"
          inputMode="decimal"
          placeholder="e.g. 25000"
          value={amount}
          invalid={!!errors.amount}
          onChange={(e) => edit("amount", setAmount)(e.target.value.replace(/[^0-9.]/g, ""))}
        />
      </Field>
      <div className="grid gap-[16px] sm:grid-cols-2">
        <Field label="Duration" htmlFor="loan-duration" error={errors.duration}>
          <SelectField id="loan-duration" value={duration} onValueChange={edit("duration", setDuration)} options={DURATIONS} placeholder="Select" invalid={!!errors.duration} />
        </Field>
        <Field label="Start date" htmlFor="loan-start" error={errors.start}>
          <DatePicker id="loan-start" value={start} onChange={edit("start", setStart)} fromYear={new Date().getFullYear()} disabled={(d) => d < startOfToday()} invalid={!!errors.start} />
        </Field>
      </div>
      <Field error={errors.terms}>
        <CheckboxField checked={terms} onCheckedChange={edit("terms", setTerms)}>
          I agree to the loan terms &amp; conditions
        </CheckboxField>
      </Field>
      <div className="flex flex-col-reverse gap-[10px] sm:flex-row sm:justify-end">
        <GhostButton type="button" onClick={onDone}>
          Cancel
        </GhostButton>
        <PrimaryButton type="submit" loading={loading}>
          {loading ? "Submitting…" : "Submit application"}
        </PrimaryButton>
      </div>
    </motion.form>
  );
}
