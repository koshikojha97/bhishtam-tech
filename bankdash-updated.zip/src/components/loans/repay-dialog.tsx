"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { format, parse } from "date-fns";
import { toast } from "sonner";
import { DatePicker, Field, SelectField, TextInput } from "@/components/shared/form-controls";
import { BdDialog, DetailRows, GhostButton, PrimaryButton, useFormFx } from "@/components/accounts/dialog-kit";
import { money, useApp } from "@/lib/store";

export interface Loan {
  id: string;
  money: number;
  left: number;
  months: number;
  rate: number;
  installment: number;
}

const today = () => format(new Date(), "yyyy-MM-dd");
const startOfToday = () => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
};

export function RepayDialog({
  loan,
  index,
  onOpenChange,
  onRepaid,
}: {
  loan: Loan | null;
  index: number;
  onOpenChange: (v: boolean) => void;
  onRepaid: (id: string, amount: number) => void;
}) {
  return (
    <BdDialog open={!!loan} onOpenChange={onOpenChange} title="Repay loan" description={loan ? `Loan ${String(index + 1).padStart(2, "0")} · ${money(loan.money)} at ${loan.rate}%` : undefined}>
      {loan && <RepayForm key={loan.id} loan={loan} onDone={(amt) => onRepaid(loan.id, amt)} onCancel={() => onOpenChange(false)} />}
    </BdDialog>
  );
}

function RepayForm({ loan, onDone, onCancel }: { loan: Loan; onDone: (amount: number) => void; onCancel: () => void }) {
  const cards = useApp((s) => s.cards);
  const updateCard = useApp((s) => s.updateCard);
  const addTransaction = useApp((s) => s.addTransaction);
  const notify = useApp((s) => s.notify);

  const [amount, setAmount] = useState(String(Math.min(loan.installment, loan.left)));
  const [cardId, setCardId] = useState(cards.find((c) => !c.blocked)?.id ?? "");
  const [date, setDate] = useState(today());
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { controls, shake, loading, run } = useFormFx();
  /** Clear a field's error as soon as the user edits it. */
  const edit =
    <T,>(key: string, set: (v: T) => void) =>
    (v: T) => {
      set(v);
      setErrors((e) => (e[key] ? { ...e, [key]: "" } : e));
    };

  const options = cards.map((c) => ({
    value: c.id,
    label: `${c.bank} •••• ${c.number.slice(-4)} — ${money(c.balance)}${c.blocked ? " (blocked)" : ""}`,
  }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const n = Number(amount);
    const card = cards.find((c) => c.id === cardId);
    const errs: Record<string, string> = {};
    if (!amount.trim() || !Number.isFinite(n) || n <= 0) errs.amount = "Enter an amount greater than $0";
    else if (n > loan.left) errs.amount = `Amount can't exceed what's left (${money(loan.left)})`;
    if (!card) errs.card = "Choose a card to pay from";
    else if (card.blocked) errs.card = "This card is blocked — choose another";
    else if (!errs.amount && n > card.balance) errs.card = `Insufficient balance (${money(card.balance)} available)`;
    if (!date) errs.date = "Pick a payment date";
    setErrors(errs);
    if (Object.keys(errs).length || !card) return void shake();

    run(() => {
      updateCard(card.id, { balance: card.balance - n });
      addTransaction({ description: "Loan repayment", type: "Transfer", card: `${card.number.slice(-4)} ****`, amount: -n });
      const paidOff = n >= loan.left;
      notify({
        title: paidOff ? "Loan paid in full" : "Loan repayment sent",
        body: `${money(n)} paid from card ending ${card.number.slice(-4)}${paidOff ? " — this loan is now closed" : ` on ${format(parse(date, "yyyy-MM-dd", new Date()), "d MMM yyyy")}`}`,
        kind: "loan",
        href: "/loans",
      });
      toast.success(paidOff ? "Loan paid in full" : `Repayment of ${money(n)} scheduled`);
      onDone(n);
    });
  };

  return (
    <motion.form animate={controls} onSubmit={submit} noValidate className="flex flex-col gap-[16px]">
      <DetailRows
        rows={[
          ["Left to repay", money(loan.left)],
          ["Installment", `${money(loan.installment)} / month`],
        ]}
      />
      <Field label="Amount (USD)" htmlFor="repay-amount" error={errors.amount}>
        <TextInput
          id="repay-amount"
          inputMode="decimal"
          value={amount}
          invalid={!!errors.amount}
          onChange={(e) => edit("amount", setAmount)(e.target.value.replace(/[^0-9.]/g, ""))}
        />
      </Field>
      <Field label="Pay from card" htmlFor="repay-card" error={errors.card}>
        <SelectField id="repay-card" value={cardId} onValueChange={edit("card", setCardId)} options={options} placeholder="Select card" invalid={!!errors.card} />
      </Field>
      <Field label="Payment date" htmlFor="repay-date" error={errors.date}>
        <DatePicker id="repay-date" value={date} onChange={edit("date", setDate)} fromYear={new Date().getFullYear()} disabled={(d) => d < startOfToday()} invalid={!!errors.date} />
      </Field>
      <div className="flex flex-col-reverse gap-[10px] sm:flex-row sm:justify-end">
        <GhostButton type="button" onClick={onCancel}>
          Cancel
        </GhostButton>
        <PrimaryButton type="submit" loading={loading}>
          {loading ? "Processing…" : "Confirm repayment"}
        </PrimaryButton>
      </div>
    </motion.form>
  );
}
