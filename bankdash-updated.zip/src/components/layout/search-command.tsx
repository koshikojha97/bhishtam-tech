"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeftRight, CreditCard, FileText, Plus, Send, Settings, ShieldCheck } from "lucide-react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from "@/components/ui/command";
import { SearchIcon } from "@/components/icons";
import { useApp, money } from "@/lib/store";
import { NAV_ITEMS } from "./nav";
import { cn } from "@/lib/utils";

const ACTIONS = [
  { label: "Send money (Quick Transfer)", icon: Send, href: "/#quick-transfer" },
  { label: "Add a new card", icon: Plus, href: "/credit-cards#add-card" },
  { label: "Edit profile", icon: Settings, href: "/settings" },
  { label: "Change password", icon: ShieldCheck, href: "/settings?tab=security" },
];

/** Header search field that opens a ⌘K / Ctrl+K command palette over pages, actions, cards and transactions. */
export function SearchCommand({ className, shortcuts = false }: { className?: string; /** register Ctrl/⌘+K and "/" — enable on exactly one instance */ shortcuts?: boolean }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const transactions = useApp((s) => s.transactions);
  const cards = useApp((s) => s.cards);

  useEffect(() => {
    if (!shortcuts) return;
    const onKey = (e: KeyboardEvent) => {
      if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((o) => !o);
      }
      if (e.key === "/" && !(e.target as HTMLElement)?.closest("input,textarea,[contenteditable=true]")) {
        e.preventDefault();
        setOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [shortcuts]);

  const go = (href: string) => {
    setOpen(false);
    router.push(href);
  };

  return (
    <>
      <button
        type="button"
        title="Search (Ctrl+K)"
        aria-keyshortcuts="Control+K Meta+K"
        onClick={() => setOpen(true)}
        className={cn(
          "group flex items-center gap-[15px] rounded-[40px] bg-bd-page pr-[16px] pl-[20px] text-left transition-shadow hover:shadow-[0_0_0_2px_#2d60ff22] focus-visible:shadow-[0_0_0_2px_#2d60ff55] focus-visible:outline-none xl:pl-[25px]",
          className,
        )}
      >
        <SearchIcon className="size-[16px] shrink-0 text-bd-muted transition-transform group-hover:scale-110 xl:size-[20px]" />
        <span className="flex-1 truncate text-[13px] text-bd-placeholder xl:text-[15px]">Search for something</span>
      </button>

      <CommandDialog open={open} onOpenChange={setOpen} title="Search BankDash" description="Search pages, cards and transactions" className="rounded-[20px] sm:max-w-[560px]">
        <CommandInput placeholder="Search pages, cards, transactions…" />
        <CommandList className="max-h-[420px]">
          <CommandEmpty>No results found.</CommandEmpty>
          <CommandGroup heading="Pages">
            {NAV_ITEMS.map((n) => (
              <CommandItem key={n.href} value={`page ${n.label} ${n.title}`} onSelect={() => go(n.href)}>
                <n.icon className="size-[16px] text-bd-muted" />
                {n.label}
              </CommandItem>
            ))}
          </CommandGroup>
          <CommandSeparator />
          <CommandGroup heading="Quick actions">
            {ACTIONS.map((a) => (
              <CommandItem key={a.label} value={`action ${a.label}`} onSelect={() => go(a.href)}>
                <a.icon className="size-[16px] text-bd-muted" />
                {a.label}
              </CommandItem>
            ))}
          </CommandGroup>
          <CommandSeparator />
          <CommandGroup heading="Cards">
            {cards.map((c) => (
              <CommandItem key={c.id} value={`card ${c.bank} ${c.nameOnCard} ${c.number} ${c.holder}`} onSelect={() => go("/credit-cards")}>
                <CreditCard className="size-[16px] text-bd-muted" />
                <span className="truncate">
                  {c.bank} · {c.number}
                </span>
                <CommandShortcut>{c.blocked ? "Blocked" : money(c.balance)}</CommandShortcut>
              </CommandItem>
            ))}
          </CommandGroup>
          <CommandSeparator />
          <CommandGroup heading="Transactions">
            {transactions.slice(0, 20).map((t) => (
              <CommandItem key={t.id} value={`tx ${t.description} ${t.type} ${t.txId} ${t.amount}`} onSelect={() => go("/transactions")}>
                {t.amount < 0 ? <ArrowLeftRight className="size-[16px] text-bd-red" /> : <FileText className="size-[16px] text-bd-green" />}
                <span className="truncate">{t.description}</span>
                <CommandShortcut className={t.amount < 0 ? "text-bd-red" : "text-bd-green"}>{money(t.amount, true)}</CommandShortcut>
              </CommandItem>
            ))}
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </>
  );
}
