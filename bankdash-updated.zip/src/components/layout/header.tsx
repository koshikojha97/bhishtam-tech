"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { LogOut } from "lucide-react";
import { GearOutlineIcon, MenuIcon } from "@/components/icons";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Logo } from "@/components/shared/logo";
import { SidebarNav } from "./sidebar";
import { getActiveNav } from "./nav";
import { NotificationsButton } from "./notifications";
import { SearchCommand } from "./search-command";
import { ThemeToggle } from "./theme-toggle";
import { UserMenu, UserAvatar, useLogout } from "./user-menu";
import { useApp } from "@/lib/store";

export function Header() {
  const pathname = usePathname();
  const active = getActiveNav(pathname);
  const [open, setOpen] = useState(false);
  const user = useApp((s) => s.user);
  const { ask: askLogout, dialog: logoutDialog } = useLogout();

  return (
    <header className="sticky top-0 z-20 border-b border-bd-border bg-bd-surface">
      {/* Mobile header (< 1024px) */}
      <div className="px-[25px] pt-[25px] pb-[20px] lg:hidden">
        <div className="flex items-center justify-between">
          <button aria-label="Open menu" onClick={() => setOpen(true)} className="p-1 text-bd-primary">
            <MenuIcon />
          </button>
          <AnimatePresence mode="wait">
            <motion.h1
              key={active.title}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              className="text-[20px] font-semibold text-bd-primary"
            >
              {active.title}
            </motion.h1>
          </AnimatePresence>
          <div className="flex items-center gap-[10px]">
            <ThemeToggle className="size-[35px] xl:size-[35px]" iconClassName="size-[18px] xl:size-[18px]" />
            <NotificationsButton className="size-[35px] [&_svg]:size-[18px]" />
            <UserMenu avatarClassName="size-[35px] xl:size-[35px]" />
          </div>
        </div>
        <SearchCommand className="mt-[20px] h-[40px] w-full" />
      </div>

      {/* Tablet / desktop header */}
      <div className="hidden h-[85px] pr-[30px] pl-[25px] lg:block xl:h-[100px] xl:pr-[40px] xl:pl-[40px]">
        <div className="flex h-full w-full items-center justify-between">
          <AnimatePresence mode="wait">
            <motion.h1
              key={active.title}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.25 }}
              className="text-[25px] font-semibold text-bd-primary xl:text-[28px]"
            >
              {active.title}
            </motion.h1>
          </AnimatePresence>
          <div className="flex items-center">
            <SearchCommand shortcuts className="h-[40px] w-[255px] xl:h-[50px]" />
            <div className="ml-[20px] flex items-center gap-[20px] xl:ml-[30px] xl:gap-[30px]">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link
                    href="/settings"
                    aria-label="Settings"
                    className="flex size-[40px] items-center justify-center rounded-full bg-bd-page transition-colors hover:bg-bd-input xl:size-[50px]"
                  >
                    <motion.span whileHover={{ rotate: 60 }} whileTap={{ scale: 0.9 }} className="flex">
                      <GearOutlineIcon className="size-[20px] text-bd-muted xl:size-[25px]" />
                    </motion.span>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>Settings</TooltipContent>
              </Tooltip>
              <ThemeToggle />
              <NotificationsButton />
            </div>
            <div className="ml-[25px] xl:ml-[35px]">
              <UserMenu />
            </div>
          </div>
        </div>
      </div>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="left" className="flex w-[260px] flex-col border-r-bd-border p-0">
          <SheetTitle className="sr-only">Navigation</SheetTitle>
          <div className="flex h-[85px] items-center pl-[27px]">
            <Logo />
          </div>
          <div className="flex-1 overflow-y-auto">
            <SidebarNav layoutId="nav-active-mobile" onNavigate={() => setOpen(false)} />
          </div>
          <div className="flex items-center gap-[10px] border-t border-bd-border p-[16px]">
            <UserAvatar className="size-[40px] xl:size-[40px]" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[14px] font-semibold text-bd-primary">{user.name}</p>
              <p className="truncate text-[12px] text-bd-muted">{user.email}</p>
            </div>
            <button
              type="button"
              aria-label="Log out"
              onClick={() => {
                setOpen(false);
                askLogout();
              }}
              className="flex size-[34px] items-center justify-center rounded-full text-bd-red hover:bg-bd-tint-red-soft"
            >
              <LogOut className="size-[18px]" />
            </button>
          </div>
        </SheetContent>
      </Sheet>
      {logoutDialog}
    </header>
  );
}
