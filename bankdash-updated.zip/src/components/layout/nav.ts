import {
  CreditCardIcon,
  HomeIcon,
  InvestmentIcon,
  LoanIcon,
  PrivilegeIcon,
  ServiceIcon,
  SettingIcon,
  TransferIcon,
  UserIcon,
} from "@/components/icons";

export const NAV_ITEMS = [
  { href: "/", label: "Dashboard", title: "Overview", icon: HomeIcon },
  { href: "/transactions", label: "Transactions", title: "Transactions", icon: TransferIcon },
  { href: "/accounts", label: "Accounts", title: "Accounts", icon: UserIcon },
  { href: "/investments", label: "Investments", title: "Investments", icon: InvestmentIcon },
  { href: "/credit-cards", label: "Credit Cards", title: "Credit Cards", icon: CreditCardIcon },
  { href: "/loans", label: "Loans", title: "Loans", icon: LoanIcon },
  { href: "/services", label: "Services", title: "Services", icon: ServiceIcon },
  { href: "/privileges", label: "My Privileges", title: "My Privileges", icon: PrivilegeIcon },
  { href: "/settings", label: "Setting", title: "Setting", icon: SettingIcon },
] as const;

export function getActiveNav(pathname: string) {
  return (
    NAV_ITEMS.find((i) => (i.href === "/" ? pathname === "/" : pathname.startsWith(i.href))) ??
    NAV_ITEMS[0]
  );
}
