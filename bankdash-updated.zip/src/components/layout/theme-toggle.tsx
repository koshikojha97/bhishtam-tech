"use client";

import { useSyncExternalStore } from "react";
import { useTheme } from "next-themes";
import { AnimatePresence, motion } from "framer-motion";
import { Monitor, Moon, Sun } from "lucide-react";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

export type ThemeChoice = "light" | "dark" | "system";

/** The resolved theme is only known on the client; render a neutral state until mounted. */
const useMounted = () =>
  useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );

/** Round header button that flips between light and dark. */
export function ThemeToggle({ className, iconClassName }: { className?: string; iconClassName?: string }) {
  const { resolvedTheme, setTheme } = useTheme();
  const mounted = useMounted();
  const isDark = mounted && resolvedTheme === "dark";
  const label = isDark ? "Switch to light mode" : "Switch to dark mode";

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          type="button"
          aria-label={label}
          onClick={() => setTheme(isDark ? "light" : "dark")}
          className={cn(
            "flex size-[40px] items-center justify-center overflow-hidden rounded-full bg-bd-page text-bd-muted transition-colors hover:bg-bd-input xl:size-[50px]",
            className,
          )}
        >
          <AnimatePresence mode="wait" initial={false}>
            <motion.span
              key={isDark ? "moon" : "sun"}
              initial={{ y: 14, opacity: 0, rotate: -45 }}
              animate={{ y: 0, opacity: 1, rotate: 0 }}
              exit={{ y: -14, opacity: 0, rotate: 45 }}
              transition={{ duration: 0.2 }}
              className="flex"
            >
              {isDark ? (
                <Moon className={cn("size-[20px] xl:size-[24px]", iconClassName)} />
              ) : (
                <Sun className={cn("size-[20px] text-bd-orange xl:size-[24px]", iconClassName)} />
              )}
            </motion.span>
          </AnimatePresence>
        </button>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  );
}

const CHOICES: { value: ThemeChoice; label: string; icon: typeof Sun }[] = [
  { value: "light", label: "Light", icon: Sun },
  { value: "dark", label: "Dark", icon: Moon },
  { value: "system", label: "System", icon: Monitor },
];

/** Segmented Light / Dark / System picker (Settings → Preferences). Applies immediately. */
export function ThemePicker() {
  const { theme, setTheme } = useTheme();
  const mounted = useMounted();
  const current = mounted ? (theme as ThemeChoice) : undefined;

  return (
    <div role="radiogroup" aria-label="Theme" className="inline-flex gap-[6px] rounded-[12px] bg-bd-page p-[5px] xl:rounded-[15px]">
      {CHOICES.map(({ value, label, icon: Icon }) => {
        const active = current === value;
        return (
          <button
            key={value}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => setTheme(value)}
            className={cn(
              "relative flex h-[36px] items-center gap-[8px] rounded-[9px] px-[16px] text-[13px] font-medium transition-colors xl:h-[42px] xl:rounded-[11px] xl:px-[20px] xl:text-[15px]",
              active ? "text-bd-blue" : "text-bd-muted hover:text-bd-primary",
            )}
          >
            {active && (
              <motion.span
                layoutId="theme-picker-active"
                className="absolute inset-0 rounded-[inherit] bg-bd-surface shadow-bd"
                transition={{ type: "spring", stiffness: 420, damping: 34 }}
              />
            )}
            <Icon className="relative size-[16px] xl:size-[18px]" />
            <span className="relative">{label}</span>
          </button>
        );
      })}
    </div>
  );
}
