import Link from "next/link";
import { LogoIcon } from "@/components/icons";
import { cn } from "@/lib/utils";

export function Logo({ className, collapsed = false }: { className?: string; collapsed?: boolean }) {
  return (
    <Link href="/" aria-label="BankDash" className={cn("group flex items-center gap-[9px] xl:gap-[9px]", className)}>
      <LogoIcon className="size-[36px] shrink-0 transition-transform duration-300 group-hover:-rotate-6 group-hover:scale-105" />
      <span
        className={cn(
          "font-mont text-[25px] leading-none font-black tracking-[-0.01em] whitespace-nowrap text-bd-primary transition-opacity duration-300",
          collapsed && "opacity-0",
        )}
      >
        BankDash.
      </span>
    </Link>
  );
}
