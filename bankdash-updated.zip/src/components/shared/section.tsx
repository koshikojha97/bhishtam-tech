"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { FadeUp } from "./motion";

/** Section heading (22px semibold #343C6A) with optional right-side action, e.g. "See All". */
export function Section({
  title,
  action,
  actionHref = "#",
  className,
  children,
  id,
}: {
  title: string;
  action?: string;
  actionHref?: string;
  className?: string;
  children: React.ReactNode;
  id?: string;
}) {
  return (
    <FadeUp id={id} className={cn("flex min-w-0 scroll-mt-[120px] flex-col", className)}>
      <div className="mb-[15px] flex items-center justify-between lg:mb-[18px] xl:mb-[20px]">
        <h2 className="leading-normal text-[16px] font-semibold text-bd-primary lg:text-[18px] xl:text-[22px]">{title}</h2>
        {action && (
          <Link
            href={actionHref}
            className="text-[14px] font-semibold text-bd-primary transition-colors hover:text-bd-blue lg:text-[15px] xl:text-[17px]"
          >
            {action}
          </Link>
        )}
      </div>
      {children}
    </FadeUp>
  );
}

/** White rounded panel (radius 25 desktop / 15 mobile) with a soft hover lift. */
export function Panel({ className, children, hover = true }: { className?: string; children: React.ReactNode; hover?: boolean }) {
  return (
    <motion.div
      whileHover={hover ? { y: -3, boxShadow: "0 12px 30px -12px rgba(52,60,106,0.18)" } : undefined}
      transition={{ type: "spring", stiffness: 300, damping: 24 }}
      className={cn("rounded-[15px] bg-bd-surface lg:rounded-[20px] xl:rounded-[25px]", className)}
    >
      {children}
    </motion.div>
  );
}
