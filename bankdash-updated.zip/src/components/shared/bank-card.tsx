"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { CardBrandIcon, ChipIcon } from "@/components/icons";

export type BankCardVariant = "blue" | "white" | "dark" | "lightBlue";

export interface BankCardData {
  balance: string;
  holder: string;
  validThru: string;
  number: string;
  variant?: BankCardVariant;
}

const styles: Record<BankCardVariant, { bg: string; label: string; value: string; footer: string; dark: boolean }> = {
  blue: {
    bg: "bg-[linear-gradient(115deg,#4C49ED_2.6%,#0A06F4_101.2%)] text-white",
    label: "text-white/70",
    value: "text-white",
    footer: "bg-gradient-to-b from-white/15 to-white/0",
    dark: false,
  },
  dark: {
    bg: "bg-[linear-gradient(107deg,#5B5A6F_2.6%,#000000_101.2%)] text-white",
    label: "text-white/70",
    value: "text-white",
    footer: "bg-gradient-to-b from-white/15 to-white/0",
    dark: false,
  },
  lightBlue: {
    bg: "bg-[linear-gradient(107deg,#2D60FF_2.6%,#539BFF_101.2%)] text-white",
    label: "text-white/70",
    value: "text-white",
    footer: "bg-gradient-to-b from-white/15 to-white/0",
    dark: false,
  },
  white: {
    bg: "bg-bd-surface border border-bd-card-border",
    label: "text-bd-muted",
    value: "text-bd-primary",
    footer: "border-t border-bd-card-border",
    dark: true,
  },
};

/**
 * Credit/debit card visual from Figma "My Cards".
 * Desktop 350×235 · tablet 231×170 · mobile 265×170 — the parent sets the width.
 */
export function BankCard({ card, className }: { card: BankCardData; className?: string }) {
  const s = styles[card.variant ?? "blue"];
  return (
    <motion.div
      whileHover={{ y: -6, rotateX: 4, rotateY: -4 }}
      transition={{ type: "spring", stiffness: 260, damping: 20 }}
      style={{ transformPerspective: 900 }}
      className={cn(
        "group relative flex h-[170px] w-full flex-col overflow-hidden rounded-[15px] font-lato xl:h-[235px] xl:rounded-[25px]",
        s.bg,
        className,
      )}
    >
      {/* shine sweep on hover */}
      <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 transition-opacity group-hover:animate-shimmer group-hover:opacity-100" />

      <div className="flex flex-1 flex-col px-[20px] pt-[17px] xl:px-[26px] xl:pt-[24px]">
        <div className="flex items-start justify-between">
          <div>
            <p className={cn("text-[11px] leading-none xl:text-[12px]", s.label)}>Balance</p>
            <p className={cn("mt-[3px] text-[16px] leading-tight font-bold xl:mt-[2px] xl:text-[20px]", s.value)}>
              {card.balance}
            </p>
          </div>
          <ChipIcon dark={s.dark} className="size-[29px] xl:size-[35px]" />
        </div>
        <div className="mt-[22px] flex gap-[50px] lg:gap-[30px] xl:mt-[33px] xl:gap-[60px]">
          <div className="min-w-[95px] lg:min-w-0 xl:min-w-[97px]">
            <p className={cn("text-[10px] leading-none xl:text-[12px]", s.label)}>CARD HOLDER</p>
            <p className={cn("mt-[4px] text-[13px] leading-tight font-bold xl:text-[15px]", s.value)}>{card.holder}</p>
          </div>
          <div>
            <p className={cn("text-[10px] leading-none xl:text-[12px]", s.label)}>VALID THRU</p>
            <p className={cn("mt-[4px] text-[13px] leading-tight font-bold xl:text-[15px]", s.value)}>{card.validThru}</p>
          </div>
        </div>
      </div>

      <div
        className={cn(
          "flex h-[51px] items-center justify-between px-[20px] xl:h-[70px] xl:px-[26px]",
          s.footer,
        )}
      >
        <p className={cn("text-[15px] font-bold tracking-[0.01em] xl:text-[22px]", s.value)}>{card.number}</p>
        <CardBrandIcon dark={s.dark} className="h-[18px] w-[27px] xl:h-[30px] xl:w-[44px]" />
      </div>
    </motion.div>
  );
}
