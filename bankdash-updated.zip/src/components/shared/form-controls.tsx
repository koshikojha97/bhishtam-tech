"use client";

/**
 * BankDash-styled wrappers around shadcn/ui primitives.
 * Use these instead of native <select>, <input type="date">, custom checkboxes etc.
 * Field box: 40px (mobile/tablet) / 50px (desktop), #DFEAF2 border, radius 10 → 15, #718EBF text.
 */
import { useId, useState } from "react";
import { format, parse, isValid } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { motion } from "framer-motion";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

export const fieldBox =
  "h-[40px] w-full rounded-[10px] border border-bd-card-border bg-bd-surface px-[15px] text-[12px] text-bd-muted shadow-none transition-[border-color,box-shadow] hover:border-bd-placeholder focus-visible:border-bd-royal focus-visible:ring-[3px] focus-visible:ring-bd-royal/15 data-[placeholder]:text-bd-muted lg:rounded-[15px] xl:h-[50px] xl:px-[20px] xl:text-[15px]";
export const fieldLabel = "text-[13px] font-normal leading-[1.21] text-bd-text xl:text-[16px]";

export function Field({ label, htmlFor, error, className, children }: { label?: string; htmlFor?: string; error?: string; className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("flex min-w-0 flex-col gap-[9px] lg:gap-[7px] xl:gap-[11px]", className)}>
      {label && (
        <Label htmlFor={htmlFor} className={fieldLabel}>
          {label}
        </Label>
      )}
      {children}
      {error && (
        <motion.p initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} role="alert" className="text-[12px] text-bd-red xl:text-[13px]">
          {error}
        </motion.p>
      )}
    </div>
  );
}

/** shadcn <Input> in BankDash field style. */
export function TextInput({ className, invalid, ...props }: React.ComponentProps<typeof Input> & { invalid?: boolean }) {
  return (
    <Input
      aria-invalid={invalid || undefined}
      className={cn(fieldBox, "text-bd-primary placeholder:text-bd-muted md:text-[12px] xl:md:text-[15px]", invalid && "border-bd-red", className)}
      {...props}
    />
  );
}

export interface Option {
  value: string;
  label: string;
}

/** shadcn <Select> in BankDash field style. */
export function SelectField({
  value,
  onValueChange,
  options,
  placeholder = "Select",
  className,
  id,
  invalid,
}: {
  value: string;
  onValueChange: (v: string) => void;
  options: Option[];
  placeholder?: string;
  className?: string;
  id?: string;
  invalid?: boolean;
}) {
  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger
        id={id}
        aria-invalid={invalid || undefined}
        className={cn(fieldBox, "justify-between data-[size=default]:h-[40px] xl:data-[size=default]:h-[50px] [&_svg]:text-bd-muted [&_svg]:opacity-100", invalid && "border-bd-red", className)}
      >
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent className="rounded-[12px] border-bd-card-border">
        {options.map((o) => (
          <SelectItem key={o.value} value={o.value} className="rounded-[8px] text-[13px] text-bd-primary focus:bg-bd-page focus:text-bd-royal xl:text-[15px]">
            {o.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

/** shadcn Popover + Calendar date picker. `value` is "yyyy-MM-dd" (or "" for none). */
export function DatePicker({
  value,
  onChange,
  placeholder = "Select date",
  displayFormat = "d MMMM yyyy",
  fromYear = 1940,
  toYear = new Date().getFullYear() + 10,
  disabled,
  className,
  id,
  invalid,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  displayFormat?: string;
  fromYear?: number;
  toYear?: number;
  disabled?: (d: Date) => boolean;
  className?: string;
  id?: string;
  invalid?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const parsed = value ? parse(value, "yyyy-MM-dd", new Date()) : undefined;
  const date = parsed && isValid(parsed) ? parsed : undefined;
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          id={id}
          type="button"
          data-invalid={invalid || undefined}
          className={cn(fieldBox, "flex cursor-pointer items-center justify-between text-left outline-none", invalid && "border-bd-red", className)}
        >
          <span className={cn("truncate", !date && "text-bd-muted")}>{date ? format(date, displayFormat) : placeholder}</span>
          <motion.span animate={{ rotate: open ? 180 : 0 }} className="flex">
            <CalendarIcon className="size-[16px] text-bd-muted xl:size-[18px]" />
          </motion.span>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-auto rounded-[15px] border-bd-card-border p-0" align="start">
        <Calendar
          mode="single"
          selected={date}
          defaultMonth={date}
          captionLayout="dropdown"
          startMonth={new Date(fromYear, 0)}
          endMonth={new Date(toYear, 11)}
          disabled={disabled}
          onSelect={(d) => {
            if (d) onChange(format(d, "yyyy-MM-dd"));
            setOpen(false);
          }}
          className="[&_[data-selected-single=true]]:bg-bd-royal [&_[data-selected-single=true]]:text-white"
        />
      </PopoverContent>
    </Popover>
  );
}

/** Month/Year picker for card expiry ("MM/YY") using two shadcn Selects. */
export function ExpiryPicker({ value, onChange, invalid }: { value: string; onChange: (v: string) => void; invalid?: boolean }) {
  const [mm = "", yy = ""] = value.split("/");
  const now = new Date().getFullYear();
  const months = Array.from({ length: 12 }, (_, i) => {
    const v = String(i + 1).padStart(2, "0");
    return { value: v, label: `${v} — ${format(new Date(2000, i, 1), "MMM")}` };
  });
  const years = Array.from({ length: 12 }, (_, i) => {
    const y = String(now + i);
    return { value: y.slice(2), label: y };
  });
  return (
    <div className="grid grid-cols-2 gap-[10px]">
      <SelectField value={mm} onValueChange={(v) => onChange(`${v}/${yy}`)} options={months} placeholder="Month" invalid={invalid} />
      <SelectField value={yy} onValueChange={(v) => onChange(`${mm}/${v}`)} options={years} placeholder="Year" invalid={invalid} />
    </div>
  );
}

/** shadcn Checkbox with label, BankDash colours. */
export function CheckboxField({ checked, onCheckedChange, children, className }: { checked: boolean; onCheckedChange: (v: boolean) => void; children: React.ReactNode; className?: string }) {
  const id = useId();
  return (
    <div className={cn("flex items-center gap-[10px]", className)}>
      <Checkbox
        id={id}
        checked={checked}
        onCheckedChange={(v) => onCheckedChange(v === true)}
        className="size-[20px] rounded-[6px] border-bd-card-border data-[state=checked]:border-bd-royal data-[state=checked]:bg-bd-royal"
      />
      <Label htmlFor={id} className="cursor-pointer text-[13px] font-normal text-bd-text xl:text-[15px]">
        {children}
      </Label>
    </div>
  );
}
