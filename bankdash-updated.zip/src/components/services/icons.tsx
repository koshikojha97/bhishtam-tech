/**
 * Services page icons — hand-built SVGs approximating the Figma glyphs
 * (figma.com asset export is blocked in the build sandbox). All use `currentColor`.
 */
import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;

/** "life-insurance filled 1" — shield with a heart and a plus cut-out. */
export const LifeInsuranceIcon = (p: P) => (
  <svg width={30} height={30} viewBox="0 0 30 30" fill="currentColor" {...p}>
    <path
      fillRule="evenodd"
      d="M15 .5 3 5v9.3c0 7.3 5 13.2 12 15.2 7-2 12-7.9 12-15.2V5L15 .5Zm0 3L24.4 7v7.3c0 5.9-3.9 10.7-9.4 12.5-5.5-1.8-9.4-6.6-9.4-12.5V7L15 3.5Z"
    />
    <path
      fillRule="evenodd"
      d="M15 22.6s-7.2-4.3-7.2-9.2c0-2.3 1.7-4 3.8-4 1.4 0 2.6.7 3.4 1.8.8-1.1 2-1.8 3.4-1.8 2.1 0 3.8 1.7 3.8 4 0 4.9-7.2 9.2-7.2 9.2Zm-1-10v2.1h-2.1v2h2.1v2.1h2v-2.1h2.1v-2H16v-2.1h-2Z"
    />
  </svg>
);

/** "bag 1" — shopping bag. */
export const BagIcon = (p: P) => (
  <svg width={30} height={30} viewBox="0 0 30 30" fill="currentColor" {...p}>
    <path d="M10.3 8.2V7a4.7 4.7 0 0 1 9.4 0v1.2h-1.8V7a2.9 2.9 0 0 0-5.8 0v1.2h-1.8Z" />
    <path d="M5.6 9.6h18.8l1.2 18.1a1.6 1.6 0 0 1-1.6 1.8H6a1.6 1.6 0 0 1-1.6-1.8L5.6 9.6Zm5.6 2.6a.9.9 0 0 0-.9.9v.6a.9.9 0 1 0 1.8 0v-.6a.9.9 0 0 0-.9-.9Zm7.6 0a.9.9 0 0 0-.9.9v.6a.9.9 0 1 0 1.8 0v-.6a.9.9 0 0 0-.9-.9Z" />
  </svg>
);

/** "shield 1" — solid shield with a check mark. */
export const ShieldCheckIcon = (p: P) => (
  <svg width={30} height={30} viewBox="0 0 30 30" fill="currentColor" {...p}>
    <path
      fillRule="evenodd"
      d="M15 .5 2.5 5v9c0 7.5 5.3 13.6 12.5 15.5 7.2-1.9 12.5-8 12.5-15.5V5L15 .5Zm-1.6 19.2-5-5 1.9-1.9 3.1 3.1 6.3-6.3 1.9 1.9-8.2 8.2Z"
    />
  </svg>
);

/** "briefcase 1" */
export const BriefcaseIcon = (p: P) => (
  <svg width={25} height={25} viewBox="0 0 25 25" fill="currentColor" {...p}>
    <path d="M9 4.2V3.1c0-.9.7-1.6 1.6-1.6h3.8c.9 0 1.6.7 1.6 1.6v1.1h-1.7v-1h-3.6v1H9Z" />
    <path d="M2.1 5.7h20.8c1.2 0 2.1.9 2.1 2.1v4.6H14.1v-.9a.9.9 0 0 0-.9-.9h-1.4a.9.9 0 0 0-.9.9v.9H0V7.8c0-1.2.9-2.1 2.1-2.1Z" />
    <path d="M0 14.1h10.9v1a.9.9 0 0 0 .9.9h1.4a.9.9 0 0 0 .9-.9v-1H25v7.3c0 1.2-.9 2.1-2.1 2.1H2.1A2.1 2.1 0 0 1 0 21.4v-7.3Z" />
  </svg>
);

/** Savings — rising bars with an up arrow (Figma "Group"). */
export const SavingsIcon = (p: P) => (
  <svg width={23} height={25} viewBox="0 0 23 25" fill="currentColor" {...p}>
    <rect x="0" y="16" width="5" height="9" rx="1" />
    <rect x="6.5" y="12" width="5" height="13" rx="1" />
    <rect x="13" y="8" width="5" height="17" rx="1" />
    <path d="M19 25h-.5V7h-2.3L19.8.6 23 7h-2.3v17a1 1 0 0 1-1 1H19Z" />
  </svg>
);
