"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { BagIcon, LifeInsuranceIcon, ShieldCheckIcon } from "./icons";
import { SERVICE_INFO } from "./service-data";
import { ServiceDialog } from "./service-dialog";

/** Desktop says "Buy. Think. Grow." — tablet & mobile frames drop the final period; kept verbatim. */
const ITEMS = [
  { id: "life-insurance", title: "Life Insurance", sub: "Unlimited protection", icon: LifeInsuranceIcon, bg: "bg-bd-tint-blue", fg: "text-[#396AFF]" },
  { id: "shopping", title: "Shopping", sub: "Buy. Think. Grow", subXl: "Buy. Think. Grow.", icon: BagIcon, bg: "bg-bd-tint-yellow", fg: "text-[#FFBB38]" },
  { id: "safety", title: "Safety", sub: "We are your allies", icon: ShieldCheckIcon, bg: "bg-bd-tint-teal", fg: "text-[#16DBCC]" },
];

export function ServiceHighlights() {
  const [active, setActive] = useState<string>(ITEMS[0].id);
  const [open, setOpen] = useState(false);
  return (
    <>
    <motion.div
      initial="hidden"
      animate="show"
      variants={{ hidden: {}, show: { transition: { staggerChildren: 0.08 } } }}
      className="no-scrollbar -mx-[25px] flex snap-x scroll-px-[25px] gap-[15px] overflow-x-auto px-[25px] pb-[2px] lg:mx-0 lg:grid lg:grid-cols-3 lg:gap-[25px] lg:overflow-visible lg:px-0 lg:pb-0 xl:gap-[30px]"
    >
      {ITEMS.map((it) => (
        <motion.button
          type="button"
          key={it.title}
          onClick={() => {
            setActive(it.id);
            setOpen(true);
          }}
          aria-label={`${it.title} — view details`}
          variants={{ hidden: { opacity: 0, y: 16 }, show: { opacity: 1, y: 0, transition: { duration: 0.45 } } }}
          whileHover={{ y: -4, boxShadow: "0 14px 30px -14px rgba(52,60,106,0.22)" }}
          className="group flex h-[85px] w-[230px] shrink-0 snap-start cursor-pointer items-center justify-center text-left outline-none focus-visible:ring-[3px] focus-visible:ring-bd-royal/25 gap-[12px] rounded-[15px] bg-bd-surface lg:h-[90px] lg:w-auto lg:rounded-[20px] xl:h-[120px] xl:gap-[22px] xl:rounded-[25px]"
        >
          <span
            className={cn(
              "flex size-[45px] shrink-0 items-center justify-center rounded-full transition-transform duration-300 group-hover:rotate-[-8deg] group-hover:scale-110 lg:size-[50px] xl:size-[70px]",
              it.bg,
              it.fg,
            )}
          >
            <it.icon className="size-[20px] xl:size-[30px]" />
          </span>
          <span className="min-w-0 whitespace-nowrap">
            <span className="block text-[16px] leading-[19px] font-semibold text-bd-text xl:text-[20px] xl:leading-[24px]">{it.title}</span>
            <span className="mt-[4px] block text-[12px] leading-[15px] text-bd-muted xl:mt-[8px] xl:text-[16px] xl:leading-[19px]">
              {it.subXl ? (
                <>
                  <span className="xl:hidden">{it.sub}</span>
                  <span className="hidden xl:inline">{it.subXl}</span>
                </>
              ) : (
                it.sub
              )}
            </span>
          </span>
        </motion.button>
      ))}
    </motion.div>
    <ServiceDialog key={active} service={SERVICE_INFO[active]} open={open} onOpenChange={setOpen} />
    </>
  );
}
