"use client";

import { useState, type ComponentType, type SVGProps } from "react";
import { motion } from "framer-motion";
import { LoanIcon, UserIcon } from "@/components/icons";
import { listContainer, listItem } from "@/components/shared/motion";
import { cn } from "@/lib/utils";
import { BriefcaseIcon, SavingsIcon, ShieldCheckIcon } from "./icons";
import { SERVICE_INFO } from "./service-data";
import { ServiceDialog } from "./service-dialog";

type Service = {
  id: string;
  title: string;
  icon: ComponentType<SVGProps<SVGSVGElement>>;
  bg: string;
  fg: string;
};

const SERVICES: Service[] = [
  { id: "business-loans", title: "Business loans", icon: LoanIcon, bg: "bg-bd-tint-pink", fg: "text-[#FF82AC]" },
  { id: "checking-accounts", title: "Checking accounts", icon: BriefcaseIcon, bg: "bg-bd-tint-yellow", fg: "text-[#FFBB38]" },
  { id: "savings-accounts", title: "Savings accounts", icon: SavingsIcon, bg: "bg-bd-tint-pink", fg: "text-[#FF82AC]" },
  { id: "cards", title: "Debit and credit cards", icon: UserIcon, bg: "bg-bd-tint-blue", fg: "text-[#396AFF]" },
  { id: "life-insurance", title: "Life Insurance", icon: ShieldCheckIcon, bg: "bg-bd-tint-teal", fg: "text-[#16DBCC]" },
  { id: "business-loans", title: "Business loans", icon: LoanIcon, bg: "bg-bd-tint-pink", fg: "text-[#FF82AC]" },
];

function Cell({ title, sub, className }: { title: string; sub: string; className?: string }) {
  return (
    <div className={cn("min-w-0 whitespace-nowrap", className)}>
      <p className="truncate text-[14px] leading-[17px] font-medium text-bd-text lg:text-[13px] lg:leading-[16px] xl:text-[16px] xl:leading-[19px]">
        {title}
      </p>
      <p className="mt-[4px] truncate text-[12px] leading-[15px] text-bd-muted lg:mt-[4px] xl:mt-[7px] xl:text-[15px] xl:leading-[18px]">{sub}</p>
    </div>
  );
}

export function ServicesList() {
  // Figma highlights "Savings accounts" (blue outline) — treat it as the selected row.
  const [selected, setSelected] = useState(2);
  const [open, setOpen] = useState(false);
  const show = (i: number) => {
    setSelected(i);
    setOpen(true);
  };

  return (
    <>
    <motion.ul variants={listContainer} initial="hidden" animate="show" className="flex flex-col gap-[10px] xl:gap-[20px]">
      {SERVICES.map((s, i) => {
        const active = i === selected;
        return (
          <motion.li
            key={i}
            variants={listItem}
            whileHover={{ y: -2, boxShadow: "0 10px 24px -14px rgba(52,60,106,0.25)" }}
            onClick={() => show(i)}
            className={cn(
              "grid h-[69px] cursor-pointer items-center rounded-[10px] bg-bd-surface pr-[14px] pl-[12px] lg:rounded-[15px] lg:pr-[20px] xl:h-[90px] xl:rounded-[20px] xl:pr-[30px] xl:pl-[15px]",
              "grid-cols-[45px_minmax(0,1fr)_auto]",
              "lg:grid-cols-[45px_minmax(0,172fr)_minmax(0,126fr)_minmax(0,126fr)_minmax(0,122fr)_120px]",
              "xl:grid-cols-[60px_minmax(0,263fr)_minmax(0,198fr)_minmax(0,198fr)_minmax(0,196fr)_150px]",
            )}
          >
            <span className={cn("flex size-[45px] items-center justify-center rounded-[12px] lg:rounded-[15px] xl:size-[60px] xl:rounded-[20px]", s.bg, s.fg)}>
              <s.icon className="size-[20px] xl:size-[25px]" />
            </span>
            <Cell title={s.title} sub="It is a long established" className="pl-[12px] xl:pl-[20px]" />
            <Cell title="Lorem Ipsum" sub="Many publishing" className="hidden lg:block" />
            <Cell title="Lorem Ipsum" sub="Many publishing" className="hidden lg:block" />
            <Cell title="Lorem Ipsum" sub="Many publishing" className="hidden lg:block" />
            <motion.button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                show(i);
              }}
              whileTap={{ scale: 0.95 }}
              aria-pressed={active}
              className={cn(
                "text-[12px] font-medium whitespace-nowrap transition-colors lg:h-[30px] lg:w-[120px] lg:rounded-[50px] lg:border xl:h-[35px] xl:w-[150px] xl:text-[15px]",
                "text-bd-royal lg:hover:border-bd-royal lg:hover:text-bd-royal",
                active ? "lg:border-bd-royal lg:text-bd-royal" : "lg:border-bd-muted lg:text-bd-muted",
              )}
            >
              View Details
            </motion.button>
          </motion.li>
        );
      })}
    </motion.ul>
    <ServiceDialog key={selected} service={SERVICE_INFO[SERVICES[selected].id]} open={open} onOpenChange={setOpen} />
    </>
  );
}
