export interface ServiceInfo {
  id: string;
  title: string;
  tagline: string;
  description: string;
  features: string[];
  plans: string[];
  amountLabel: string;
  min: number;
  max: number;
}

export const SERVICE_INFO: Record<string, ServiceInfo> = {
  "business-loans": {
    id: "business-loans",
    title: "Business loans",
    tagline: "Capital to grow your business",
    description: "Flexible term loans and credit lines for working capital, equipment and expansion, with decisions in as little as 48 hours.",
    features: ["Borrow from $5,000 to $500,000", "Fixed rates from 6.5% APR", "Terms from 12 to 84 months", "No early repayment fees"],
    plans: ["Term loan", "Line of credit", "Equipment financing"],
    amountLabel: "Loan amount (USD)",
    min: 5000,
    max: 500000,
  },
  "checking-accounts": {
    id: "checking-accounts",
    title: "Checking accounts",
    tagline: "Everyday banking, no hidden fees",
    description: "A checking account with free transfers, a debit card and real-time notifications for every payment.",
    features: ["No monthly maintenance fee", "Free domestic transfers", "Early direct deposit", "55,000+ fee-free ATMs"],
    plans: ["Essential", "Plus", "Premier"],
    amountLabel: "Opening deposit (USD)",
    min: 25,
    max: 100000,
  },
  "savings-accounts": {
    id: "savings-accounts",
    title: "Savings accounts",
    tagline: "Make your money work for you",
    description: "High-yield savings with automatic round-ups and goals, so your balance grows a little every day.",
    features: ["4.10% APY on all balances", "Automatic savings goals", "FDIC insured up to $250,000", "Withdraw any time"],
    plans: ["High-yield savings", "Goal saver", "Fixed deposit (12 months)"],
    amountLabel: "Initial deposit (USD)",
    min: 100,
    max: 250000,
  },
  cards: {
    id: "cards",
    title: "Debit and credit cards",
    tagline: "Cards that reward every purchase",
    description: "Contactless debit and credit cards with cashback, travel perks and instant freeze from the app.",
    features: ["Up to 5% cashback", "No foreign transaction fees", "Virtual cards for online shopping", "Apple Pay & Google Pay ready"],
    plans: ["Classic", "Gold", "Platinum", "Business"],
    amountLabel: "Requested credit limit (USD)",
    min: 500,
    max: 50000,
  },
  "life-insurance": {
    id: "life-insurance",
    title: "Life Insurance",
    tagline: "Unlimited protection",
    description: "Term and whole-life cover that protects the people who matter most, with flexible premiums and quick claims.",
    features: ["Cover from $50,000 to $2M", "Online application in 10 minutes", "Critical illness add-on", "24/7 claims support"],
    plans: ["Term life (20 years)", "Term life (30 years)", "Whole life"],
    amountLabel: "Coverage amount (USD)",
    min: 50000,
    max: 2000000,
  },
  shopping: {
    id: "shopping",
    title: "Shopping",
    tagline: "Buy. Think. Grow.",
    description: "Buy now, pay later at thousands of partner stores, with 0% interest instalments and purchase protection.",
    features: ["0% interest over 3 to 12 months", "Purchase protection up to $10,000", "Exclusive partner discounts", "Extended warranty on electronics"],
    plans: ["Pay in 3", "Pay in 6", "Pay in 12"],
    amountLabel: "Spending limit (USD)",
    min: 100,
    max: 10000,
  },
  safety: {
    id: "safety",
    title: "Safety",
    tagline: "We are your allies",
    description: "Fraud monitoring, identity protection and account alerts that keep your money safe around the clock.",
    features: ["24/7 fraud monitoring", "Identity theft insurance", "Dark-web scan for your details", "Instant card freeze"],
    plans: ["Basic", "Family", "Premium"],
    amountLabel: "Identity insurance cover (USD)",
    min: 1000,
    max: 1000000,
  },
};
