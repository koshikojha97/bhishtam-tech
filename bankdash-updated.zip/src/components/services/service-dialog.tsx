"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";
import { ArrowLeft, CheckCircle2 } from "lucide-react";
import { CheckboxField, Field, SelectField, TextInput } from "@/components/shared/form-controls";
import { Label } from "@/components/ui/label";
import { BdDialog, Shake, Spinner, outlineBtn, primaryBtn, wait } from "@/components/credit-cards/dialog-kit";
import { money, useApp } from "@/lib/store";
import type { ServiceInfo } from "./service-data";

const labelCls = "text-[13px] font-normal text-bd-text xl:text-[15px]";
type Errors = { plan?: string; amount?: string; terms?: string };

function ApplyForm({ service, onBack, onDone }: { service: ServiceInfo; onBack: () => void; onDone: () => void }) {
  const notify = useApp((s) => s.notify);
  const [plan, setPlan] = useState("");
  const [amount, setAmount] = useState("");
  const [terms, setTerms] = useState(false);
  const [errors, setErrors] = useState<Errors>({});
  const [loading, setLoading] = useState(false);
  const [shake, setShake] = useState(0);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const n = Number(amount.replace(/[^\d.]/g, ""));
    const errs: Errors = {};
    if (!plan) errs.plan = "Choose a plan.";
    if (!amount.trim() || !Number.isFinite(n) || n <= 0) errs.amount = "Enter an amount.";
    else if (n < service.min || n > service.max) errs.amount = `Amount must be between ${money(service.min)} and ${money(service.max)}.`;
    if (!terms) errs.terms = "Please accept the terms to continue.";
    setErrors(errs);
    if (Object.keys(errs).length) {
      setShake((k) => k + 1);
      return;
    }
    setLoading(true);
    await wait(800);
    setLoading(false);
    const body = `${service.title} — ${plan}, ${money(n)}. We'll get back to you within 2 business days.`;
    notify({ title: "Application submitted", body, kind: "info", href: "/services" });
    toast.success("Application submitted", { description: body });
    onDone();
  };

  return (
    <Shake shakeKey={shake}>
      <form onSubmit={submit} noValidate className="grid gap-[16px]">
        <Field error={errors.plan}>
          <Label htmlFor="svc-plan" className={labelCls}>
            Plan
          </Label>
          <SelectField
            id="svc-plan"
            value={plan}
            onValueChange={(v) => (setPlan(v), setErrors((x) => ({ ...x, plan: undefined })))}
            options={service.plans.map((p) => ({ value: p, label: p }))}
            placeholder="Select a plan"
            invalid={!!errors.plan}
            className="text-bd-primary"
          />
        </Field>
        <Field error={errors.amount}>
          <Label htmlFor="svc-amount" className={labelCls}>
            {service.amountLabel}
          </Label>
          <TextInput
            id="svc-amount"
            inputMode="decimal"
            placeholder={`${money(service.min)} – ${money(service.max)}`}
            value={amount}
            onChange={(e) => {
              const d = e.target.value.replace(/[^\d]/g, "").slice(0, 9);
              setAmount(d ? Number(d).toLocaleString("en-US") : "");
              setErrors((x) => ({ ...x, amount: undefined }));
            }}
            invalid={!!errors.amount}
          />
        </Field>
        <Field error={errors.terms}>
          <CheckboxField checked={terms} onCheckedChange={(v) => (setTerms(v), setErrors((x) => ({ ...x, terms: undefined })))}>
            I agree to the terms and conditions
          </CheckboxField>
        </Field>
        <div className="mt-[4px] flex justify-between gap-[10px]">
          <button type="button" className={outlineBtn} onClick={onBack}>
            <ArrowLeft className="size-[16px]" /> Back
          </button>
          <button type="submit" className={primaryBtn} disabled={loading}>
            {loading && <Spinner />}
            {loading ? "Submitting" : "Submit application"}
          </button>
        </div>
      </form>
    </Shake>
  );
}

/** Details → Apply flow for a bank service. Remounts per service via `key`. */
export function ServiceDialog({ service, open, onOpenChange }: { service: ServiceInfo | null; open: boolean; onOpenChange: (v: boolean) => void }) {
  const [step, setStep] = useState<"details" | "apply">("details");
  if (!service) return null;
  const close = (v: boolean) => {
    onOpenChange(v);
    if (!v) setTimeout(() => setStep("details"), 200);
  };
  return (
    <BdDialog open={open} onOpenChange={close} title={step === "apply" ? `Apply — ${service.title}` : service.title} description={step === "apply" ? "Tell us a little about what you need." : service.tagline}>
      <AnimatePresence mode="wait" initial={false}>
        {step === "details" ? (
          <motion.div key="details" initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.2 }}>
            <p className="text-[14px] leading-[22px] text-bd-text xl:text-[15px]">{service.description}</p>
            <ul className="mt-[16px] grid gap-[10px]">
              {service.features.map((f) => (
                <li key={f} className="flex items-center gap-[10px] text-[13px] text-bd-primary xl:text-[15px]">
                  <CheckCircle2 className="size-[18px] shrink-0 text-bd-teal" />
                  {f}
                </li>
              ))}
            </ul>
            <div className="mt-[22px] flex justify-end gap-[10px]">
              <button type="button" className={outlineBtn} onClick={() => close(false)}>
                Close
              </button>
              <button type="button" className={primaryBtn} onClick={() => setStep("apply")}>
                Apply
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.div key="apply" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 16 }} transition={{ duration: 0.2 }}>
            <ApplyForm service={service} onBack={() => setStep("details")} onDone={() => close(false)} />
          </motion.div>
        )}
      </AnimatePresence>
    </BdDialog>
  );
}
