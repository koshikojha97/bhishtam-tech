"use client";

import { useState } from "react";
import { CartesianGrid, Line, LineChart, XAxis, YAxis } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { Panel } from "@/components/shared/section";
import { FadeUp } from "@/components/shared/motion";
import { MiniSelect } from "@/components/accounts/dialog-kit";

const YEARS = ["2016", "2017", "2018", "2019", "2020", "2021"];
const Y_TICKS = [0, 10000, 20000, 30000, 40000];
const money = (v: number) => `$${v.toLocaleString("en-US")}`;
const tick = { fill: "var(--color-bd-muted)", fontSize: 13 };

const panelCls =
  "h-[225px] px-[19px] pt-[17px] pb-[17px] lg:h-[226px] lg:pr-[19px] lg:pl-[13px] lg:pt-[18px] xl:h-[282px] xl:pt-[26px] xl:pr-[30px] xl:pl-[29px] xl:pb-[29px]";
const chartCls = "aspect-auto h-full w-full";

/* ------------------------------ Yearly Total Investment ------------------------------ */

/** 2016–2021 values read off the Figma polyline (point centres vs the $0–$40k gridlines); earlier years are demo data. */
const yearlyAll = [
  { year: "2012", amount: 4000 },
  { year: "2013", amount: 9500 },
  { year: "2014", amount: 7000 },
  { year: "2015", amount: 14500 },
  { year: "2016", amount: 6000 },
  { year: "2017", amount: 23500 },
  { year: "2018", amount: 16000 },
  { year: "2019", amount: 36000 },
  { year: "2020", amount: 21000 },
  { year: "2021", amount: 28500 },
];
const RANGES = [
  { value: "6", label: "2016–2021" },
  { value: "3", label: "2019–2021" },
  { value: "10", label: "2012–2021" },
];
const yearlyConfig = { amount: { label: "Investment", color: "#FCAA0B" } } satisfies ChartConfig;

/** Renders its own section heading so the year-range selector sits in the header's right slot. */
export function YearlyInvestmentChart() {
  const [range, setRange] = useState("6");
  const yearly = yearlyAll.slice(-Number(range));
  return (
    <FadeUp className="flex min-w-0 flex-col">
      <div className="mb-[15px] flex items-center justify-between gap-3 lg:mb-[18px] xl:mb-[20px]">
        <h2 className="leading-normal text-[16px] font-semibold text-bd-primary lg:text-[18px] xl:text-[22px]">Yearly Total Investment</h2>
        <MiniSelect value={range} onValueChange={setRange} options={RANGES} label="Year range" />
      </div>
      <Panel className={panelCls}>
        <ChartContainer config={yearlyConfig} className={chartCls}>
          <LineChart key={range} data={yearly} margin={{ left: 0, right: 0, top: 8, bottom: 0 }}>
            <CartesianGrid vertical={false} stroke="var(--color-bd-card-border)" strokeDasharray="4 4" />
            <XAxis
              dataKey="year"
              tickLine={false}
              axisLine={false}
              tickMargin={10}
              tick={tick}
              padding={{ left: 16, right: 18 }}
              interval={yearly.length > 6 ? "preserveStartEnd" : 0}
            />
            <YAxis
              ticks={Y_TICKS}
              domain={[0, 40000]}
              tickFormatter={money}
              tickLine={false}
              axisLine={false}
              tickMargin={8}
              width={66}
              tick={tick}
            />
            <ChartTooltip cursor={{ stroke: "var(--color-bd-card-border)" }} content={<ChartTooltipContent formatter={(v) => <span className="font-medium text-bd-text">{money(Number(v))}</span>} />} />
            <Line
              type="linear"
              dataKey="amount"
              stroke="var(--color-amount)"
              strokeWidth={3}
              dot={{ r: 4, fill: "var(--color-bd-surface)", stroke: "#FCAA0B", strokeWidth: 2.5 }}
              activeDot={{ r: 6, fill: "#FCAA0B", stroke: "var(--color-bd-surface)", strokeWidth: 3 }}
              animationDuration={1400}
            />
          </LineChart>
        </ChartContainer>
      </Panel>
    </FadeUp>
  );
}

/* ---------------------------------- Monthly Revenue ---------------------------------- */

/** x = year index (fractional) so the smooth curve follows the Figma wave between year ticks. */
const revenue = [
  { x: -0.25, revenue: 10500 },
  { x: 0.02, revenue: 13200 },
  { x: 0.2, revenue: 13800 },
  { x: 0.6, revenue: 19800 },
  { x: 0.95, revenue: 13500 },
  { x: 1.25, revenue: 11500 },
  { x: 1.65, revenue: 25500 },
  { x: 2.05, revenue: 29500 },
  { x: 2.45, revenue: 32000 },
  { x: 2.95, revenue: 20500 },
  { x: 3.5, revenue: 28000 },
  { x: 4.0, revenue: 24000 },
  { x: 4.25, revenue: 22000 },
  { x: 4.75, revenue: 14500 },
  { x: 5.3, revenue: 34500 },
];
const revenueConfig = { revenue: { label: "Revenue", color: "#16DBCC" } } satisfies ChartConfig;

export function MonthlyRevenueChart() {
  return (
    <Panel className={panelCls}>
      <ChartContainer config={revenueConfig} className={chartCls}>
        <LineChart data={revenue} margin={{ left: 0, right: 0, top: 8, bottom: 0 }}>
          <CartesianGrid vertical={false} stroke="var(--color-bd-card-border)" strokeDasharray="4 4" />
          <XAxis
            dataKey="x"
            type="number"
            domain={[-0.25, 5.3]}
            ticks={[0, 1, 2, 3, 4, 5]}
            tickFormatter={(v: number) => YEARS[v] ?? ""}
            tickLine={false}
            axisLine={false}
            tickMargin={10}
            tick={tick}
            allowDataOverflow
          />
          <YAxis
            ticks={Y_TICKS}
            domain={[0, 40000]}
            tickFormatter={money}
            tickLine={false}
            axisLine={false}
            tickMargin={8}
            width={66}
            tick={tick}
          />
          <ChartTooltip
            cursor={{ stroke: "var(--color-bd-card-border)" }}
            content={
              <ChartTooltipContent
                labelFormatter={(_, p) => YEARS[Math.max(0, Math.round(Number(p?.[0]?.payload?.x ?? 0)))] ?? ""}
                formatter={(v) => <span className="font-medium text-bd-text">{money(Number(v))}</span>}
              />
            }
          />
          <Line
            type="monotone"
            dataKey="revenue"
            stroke="var(--color-revenue)"
            strokeWidth={3}
            dot={false}
            activeDot={{ r: 6, fill: "#16DBCC", stroke: "var(--color-bd-surface)", strokeWidth: 3 }}
            animationDuration={1600}
          />
        </LineChart>
      </ChartContainer>
    </Panel>
  );
}
