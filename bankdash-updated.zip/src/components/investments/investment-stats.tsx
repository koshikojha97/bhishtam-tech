"use client";

import { motion } from "framer-motion";
import { Panel } from "@/components/shared/section";
import { CountUp, FadeUp } from "@/components/shared/motion";
import { cn } from "@/lib/utils";
import { MoneyBagIcon, PieChartIcon, RepeatIcon } from "./icons";

const STATS = [
  { label: "Total Invested Amount", value: 150000, prefix: "$", suffix: "", decimals: 0, icon: MoneyBagIcon, bg: "bg-bd-tint-teal", fg: "text-[#16DBCC]" },
  { label: "Number of Investments", value: 1250, prefix: "", suffix: "", decimals: 0, icon: PieChartIcon, bg: "bg-bd-tint-pink", fg: "text-[#FF82AC]" },
  { label: "Rate of Return", value: 5.8, prefix: "+", suffix: "%", decimals: 2, icon: RepeatIcon, bg: "bg-bd-tint-blue", fg: "text-[#396AFF]" },
];

export function InvestmentStats() {
  return (
    <div className="grid gap-[15px] lg:grid-cols-3 lg:gap-[25px] xl:gap-[30px]">
      {STATS.map((s) => (
        <FadeUp key={s.label}>
          <Panel className="flex h-[85px] items-center pl-[50px] lg:h-[90px] lg:justify-center lg:px-[10px] xl:h-[120px]">
            <div className="flex items-center gap-[12px] xl:gap-[15px]">
              <motion.span
                whileHover={{ rotate: -12, scale: 1.08 }}
                transition={{ type: "spring", stiffness: 300, damping: 15 }}
                className={cn(
                  "flex size-[45px] shrink-0 items-center justify-center rounded-full lg:size-[50px] xl:size-[70px]",
                  s.bg,
                  s.fg,
                )}
              >
                <s.icon className="size-[20px] xl:size-[30px]" />
              </motion.span>
              <div className="min-w-0">
                <p className="text-[12px] leading-[15px] whitespace-nowrap text-bd-muted xl:text-[16px] xl:leading-[19px]">{s.label}</p>
                <p className="mt-[4px] text-[16px] leading-[19px] font-semibold text-bd-text xl:mt-[8px] xl:text-[20px] xl:leading-[24px]">
                  <CountUp value={s.value} prefix={s.prefix} suffix={s.suffix} decimals={s.decimals} />
                </p>
              </div>
            </div>
          </Panel>
        </FadeUp>
      ))}
    </div>
  );
}
