"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { listContainer, listItem } from "@/components/shared/motion";
import { Field, TextInput } from "@/components/shared/form-controls";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { BdDialog, DetailRows, GhostButton, PrimaryButton, useFormFx } from "@/components/accounts/dialog-kit";
import { money, useApp } from "@/lib/store";
import { cn } from "@/lib/utils";
import { AppleIcon, GoogleIcon, TeslaIcon } from "./icons";
import { MiniLineChart, series } from "./mini-chart";

interface Holding {
  id: string;
  name: string;
  ticker: string;
  category: string;
  value: number;
  ret: number; // %
  price: number; // per share
  icon: typeof AppleIcon;
  bg: string;
  fg: string;
}

const SEED: Holding[] = [
  { id: "aapl", name: "Apple Store", ticker: "AAPL", category: "E-commerce, Marketplace", value: 54000, ret: 16, price: 180, icon: AppleIcon, bg: "bg-bd-tint-pink", fg: "text-[#FF82AC]" },
  { id: "ssnlf", name: "Samsung Mobile", ticker: "SSNLF", category: "E-commerce, Marketplace", value: 25300, ret: -4, price: 55, icon: GoogleIcon, bg: "bg-bd-tint-blue", fg: "text-[#396AFF]" },
  { id: "tsla", name: "Tesla Motors", ticker: "TSLA", category: "Electric Vehicles", value: 8200, ret: 25, price: 205, icon: TeslaIcon, bg: "bg-bd-tint-yellow", fg: "text-[#FFBB38]" },
];

const title = "truncate text-[14px] leading-[17px] font-medium text-bd-text lg:text-[13px] lg:leading-[15px] xl:text-[16px] xl:leading-[19px]";
const sub = "truncate text-[12px] leading-[15px] text-bd-muted lg:text-[11px] lg:leading-[13px] xl:text-[13px] xl:leading-[18px] min-[87.5rem]:text-[15px]";
const pct = (n: number) => `${n > 0 ? "+" : ""}${n}%`;

export function MyInvestments() {
  const [items, setItems] = useState<Holding[]>(SEED);
  const [selId, setSelId] = useState<string | null>(null);
  const sel = items.find((i) => i.id === selId) ?? null;

  return (
    <>
      <motion.ul variants={listContainer} initial="hidden" animate="show" className="flex flex-col gap-[10px] xl:gap-[15px]">
        {items.map((it) => (
          <motion.li
            key={it.id}
            variants={listItem}
            whileHover={{ y: -2, boxShadow: "0 10px 24px -12px rgba(52,60,106,0.2)" }}
            transition={{ type: "spring", stiffness: 300, damping: 24 }}
            className="rounded-[15px] xl:rounded-[20px]"
          >
            <button
              type="button"
              onClick={() => setSelId(it.id)}
              aria-label={`${it.name} — view investment`}
              className="grid h-[69px] w-full cursor-pointer grid-cols-[45px_minmax(0,1fr)_auto] items-center gap-x-[12px] rounded-[15px] bg-bd-surface pr-[15px] pl-[12px] text-left outline-none focus-visible:ring-[3px] focus-visible:ring-bd-royal/30 lg:grid-cols-[45px_minmax(0,146fr)_minmax(0,104fr)_minmax(0,68fr)] lg:pr-[12px] xl:h-[90px] xl:grid-cols-[60px_minmax(0,223fr)_minmax(0,151fr)_minmax(0,111fr)] xl:gap-x-[20px] xl:rounded-[20px] xl:px-[15px]"
            >
              <span className={cn("flex size-[45px] items-center justify-center rounded-[12px] xl:size-[60px] xl:rounded-[20px]", it.bg, it.fg)}>
                <it.icon className="size-[20px] xl:size-[26px]" />
              </span>
              <div className="min-w-0">
                <p className={title}>{it.name}</p>
                <p className={cn(sub, "mt-[4px] lg:mt-[4px] xl:mt-[7px]")}>{it.category}</p>
              </div>
              <div className="hidden min-w-0 lg:block">
                <p className={title}>{money(it.value)}</p>
                <p className={cn(sub, "mt-[4px] xl:mt-[7px]")}>Envestment Value</p>
              </div>
              <div className="min-w-0 text-right lg:text-left">
                <p className={cn(title, "text-[12px] leading-[15px] lg:text-[13px] lg:leading-[15px] xl:text-[16px] xl:leading-[19px]", it.ret >= 0 ? "text-[#16DBAA]" : "text-bd-pink")}>
                  {pct(it.ret)}
                </p>
                <p className={cn(sub, "mt-[4px] hidden lg:block xl:mt-[7px]")}>Return Value</p>
              </div>
            </button>
          </motion.li>
        ))}
      </motion.ul>

      <BdDialog open={!!sel} onOpenChange={(o) => !o && setSelId(null)} title={sel?.name ?? "Investment"} description={sel ? `${sel.ticker} · ${sel.category}` : undefined}>
        {sel && (
          <InvestmentDetail
            key={sel.id}
            item={sel}
            onTrade={(delta) => setItems((xs) => xs.map((x) => (x.id === sel.id ? { ...x, value: x.value + delta } : x)))}
            onClose={() => setSelId(null)}
          />
        )}
      </BdDialog>
    </>
  );
}

function InvestmentDetail({ item, onTrade, onClose }: { item: Holding; onTrade: (delta: number) => void; onClose: () => void }) {
  const notify = useApp((s) => s.notify);
  const [side, setSide] = useState<"buy" | "sell">("buy");
  const [amount, setAmount] = useState("");
  const [error, setError] = useState("");
  const { controls, shake, loading, run } = useFormFx();
  const shares = item.value / item.price;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const n = Number(amount);
    let err = "";
    if (!amount.trim() || !Number.isFinite(n) || n <= 0) err = "Enter an amount greater than $0";
    else if (n > 1_000_000) err = "Maximum single order is $1,000,000";
    else if (side === "sell" && n > item.value) err = `You can sell at most ${money(item.value)}`;
    setError(err);
    if (err) return void shake();
    run(() => {
      const delta = side === "buy" ? n : -n;
      onTrade(delta);
      const verb = side === "buy" ? "Bought" : "Sold";
      notify({ title: `${verb} ${item.ticker}`, body: `${verb} ${money(n)} of ${item.name}`, kind: "transaction", href: "/investments" });
      toast.success(`${verb} ${money(n)} of ${item.name}`);
      setAmount("");
    });
  };

  return (
    <div className="flex flex-col gap-[16px]">
      <MiniLineChart data={series(item.value, item.ret, item.id.length)} up={item.ret >= 0} label="Value" />
      <DetailRows
        rows={[
          ["Holding", `${shares.toFixed(2)} shares @ ${money(item.price)}`],
          ["Investment value", money(item.value)],
          ["Return", <span key="r" className={item.ret >= 0 ? "text-[#16DBAA]" : "text-bd-pink"}>{pct(item.ret)}</span>],
        ]}
      />
      <motion.form animate={controls} onSubmit={submit} noValidate className="flex flex-col gap-[14px]">
        <RadioGroup value={side} onValueChange={(v) => setSide(v as "buy" | "sell")} className="grid grid-cols-2 gap-[10px]" aria-label="Order side">
          {(["buy", "sell"] as const).map((v) => (
            <Label
              key={v}
              htmlFor={`side-${v}`}
              className={cn(
                "flex h-[44px] cursor-pointer items-center gap-[10px] rounded-[10px] border px-[14px] text-[14px] font-medium transition-colors xl:rounded-[15px]",
                side === v ? "border-bd-royal bg-bd-tint-royal text-bd-royal" : "border-bd-card-border text-bd-primary",
              )}
            >
              <RadioGroupItem id={`side-${v}`} value={v} className="border-bd-card-border data-[state=checked]:border-bd-royal [&_svg]:fill-bd-royal" />
              {v === "buy" ? "Buy more" : "Sell"}
            </Label>
          ))}
        </RadioGroup>
        <Field label="Amount (USD)" htmlFor="trade-amount" error={error}>
          <TextInput
            id="trade-amount"
            inputMode="decimal"
            placeholder="e.g. 500"
            value={amount}
            invalid={!!error}
            onChange={(e) => {
              setAmount(e.target.value.replace(/[^0-9.]/g, ""));
              if (error) setError("");
            }}
          />
        </Field>
        <div className="flex flex-col-reverse gap-[10px] sm:flex-row sm:justify-end">
          <GhostButton type="button" onClick={onClose}>
            Close
          </GhostButton>
          <PrimaryButton type="submit" loading={loading}>
            {loading ? "Processing…" : side === "buy" ? "Buy more" : "Sell"}
          </PrimaryButton>
        </div>
      </motion.form>
    </div>
  );
}
