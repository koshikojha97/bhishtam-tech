"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Panel } from "@/components/shared/section";
import { listContainer, listItem } from "@/components/shared/motion";
import { BdDialog, DetailRows, PrimaryButton } from "@/components/accounts/dialog-kit";
import { money } from "@/lib/store";
import { cn } from "@/lib/utils";
import { MiniLineChart, series } from "./mini-chart";

interface Stock {
  name: string;
  ticker: string;
  price: number;
  ret: number;
  sector: string;
  cap: string;
  volume: string;
}

const STOCKS: Stock[] = [
  { name: "Trivago", ticker: "TRVG", price: 520, ret: 5, sector: "Travel", cap: "$1.2B", volume: "842K" },
  { name: "Canon", ticker: "CAJ", price: 480, ret: 10, sector: "Imaging", cap: "$24.6B", volume: "1.1M" },
  { name: "Uber Food", ticker: "UBER", price: 350, ret: -3, sector: "Delivery", cap: "$88.1B", volume: "14.3M" },
  { name: "Nokia", ticker: "NOK", price: 940, ret: 2, sector: "Telecom", cap: "$21.7B", volume: "9.6M" },
  { name: "Tiktok", ticker: "TTOK", price: 670, ret: -12, sector: "Social media", cap: "$220B", volume: "3.4M" },
];

/** Column widths from the Figma x offsets (mobile / tablet / desktop). */
const cols =
  "grid grid-cols-[minmax(0,53fr)_minmax(0,93fr)_minmax(0,83fr)_minmax(0,56fr)] lg:grid-cols-[minmax(0,53fr)_minmax(0,79fr)_minmax(0,75fr)_minmax(0,52fr)] xl:grid-cols-[minmax(0,82fr)_minmax(0,131fr)_minmax(0,104fr)_minmax(0,68fr)]";
const pct = (n: number) => `${n > 0 ? "+" : ""}${n}%`;

export function TrendingStock() {
  const [sel, setSel] = useState<Stock | null>(null);
  return (
    <Panel className="h-full px-[20px] pt-[17px] pb-[17px] lg:px-[18px] xl:px-[30px] xl:pt-[27px] xl:pb-[25px]">
      <div role="table" aria-label="Trending Stock" className="text-[12px] leading-[15px] xl:text-[16px] xl:leading-[19px]">
        <div role="row" className={cn(cols, "border-b border-bd-border pb-[7px] font-medium text-bd-muted xl:pb-[8px]")}>
          {["SL No", "Name", "Price", "Return"].map((h) => (
            <span key={h} role="columnheader">{h}</span>
          ))}
        </div>
        <motion.div
          variants={listContainer}
          initial="hidden"
          animate="show"
          className="mt-[10px] flex flex-col gap-[18px] lg:gap-[21px] xl:mt-[14px] xl:gap-[28px]"
        >
          {STOCKS.map((s, i) => (
            <motion.div
              key={s.name}
              role="row"
              tabIndex={0}
              aria-label={`${s.name} — view stock`}
              onClick={() => setSel(s)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  setSel(s);
                }
              }}
              variants={listItem}
              whileHover={{ x: 4 }}
              className={cn(cols, "cursor-pointer rounded-[6px] text-bd-text outline-none transition-colors hover:text-bd-royal focus-visible:ring-[3px] focus-visible:ring-bd-royal/30")}
            >
              <span role="cell">{String(i + 1).padStart(2, "0")}.</span>
              <span role="cell" className="truncate">{s.name}</span>
              <span role="cell">${s.price}</span>
              <span role="cell" className={cn("font-medium", s.ret >= 0 ? "text-[#16DBAA]" : "text-bd-pink")}>
                {pct(s.ret)}
              </span>
            </motion.div>
          ))}
        </motion.div>
      </div>

      <BdDialog open={!!sel} onOpenChange={(o) => !o && setSel(null)} title={sel?.name ?? "Stock"} description={sel ? `${sel.ticker} · ${sel.sector}` : undefined}>
        {sel && (
          <div className="flex flex-col gap-[16px]">
            <div className="flex items-end gap-3">
              <p className="text-[28px] font-semibold text-bd-primary">{money(sel.price)}</p>
              <p className={cn("pb-[6px] text-[15px] font-medium", sel.ret >= 0 ? "text-[#16DBAA]" : "text-bd-pink")}>{pct(sel.ret)} this year</p>
            </div>
            <MiniLineChart data={series(sel.price, sel.ret, sel.name.length)} up={sel.ret >= 0} label="Price" />
            <DetailRows
              rows={[
                ["Market cap", sel.cap],
                ["Volume (24h)", sel.volume],
                ["Sector", sel.sector],
              ]}
            />
            <div className="flex justify-end">
              <PrimaryButton onClick={() => setSel(null)}>Done</PrimaryButton>
            </div>
          </div>
        )}
      </BdDialog>
    </Panel>
  );
}
