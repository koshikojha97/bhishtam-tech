/** Investments page glyphs — hand-built approximations of the Figma icons (asset export is blocked). */
import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;
const base = (p: P) => ({ width: 24, height: 24, viewBox: "0 0 24 24", fill: "currentColor", ...p });

export const MoneyBagIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M7.6 1.6c1.3.7 2.8 1 4.4 1s3.1-.3 4.4-1l-2 4.2H9.6L7.6 1.6Z" />
    <path d="M9.6 6.9h4.8c3.9 2.4 6.6 6.3 6.6 10.1 0 3.9-3 5.8-9 5.8s-9-1.9-9-5.8c0-3.8 2.7-7.7 6.6-10.1Z" />
    <path
      fill="#fff"
      d="M12.6 10.2v.9c1 .1 1.8.6 2.3 1.4l-1.3 1c-.4-.5-.9-.8-1.5-.8-.6 0-1 .3-1 .7 0 1.3 4 .5 4 3.4 0 1.3-1 2.2-2.5 2.4v.9h-1.3v-.9a3.3 3.3 0 0 1-2.4-1.4l1.3-1c.4.6 1 .9 1.7.9.6 0 1.1-.3 1.1-.8 0-1.3-4-.5-4-3.3 0-1.2.9-2 2.3-2.2v-1.2h1.3Z"
    />
  </svg>
);

export const PieChartIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M10.8 2.6A9.6 9.6 0 1 0 21.4 13.2H10.8V2.6Z" />
    <path d="M13 .6v10.4h10.4A10.4 10.4 0 0 0 13 .6Z" />
    <text x="6.2" y="15.6" fontSize="6.5" fontWeight="700" fill="#fff" fontFamily="Inter, sans-serif">%</text>
    <text x="16" y="8.6" fontSize="6" fontWeight="700" fill="#fff" fontFamily="Inter, sans-serif">$</text>
  </svg>
);

export const RepeatIcon = (p: P) => (
  <svg {...base(p)} fill="none" stroke="currentColor" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round">
    <path d="M3.5 11.5V9.8A3.3 3.3 0 0 1 6.8 6.5h13" />
    <path d="m16.5 3 3.5 3.5-3.5 3.5" />
    <path d="M20.5 12.5v1.7a3.3 3.3 0 0 1-3.3 3.3h-13" />
    <path d="m7.5 21-3.5-3.5L7.5 14" />
  </svg>
);

export const AppleIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11Z" />
  </svg>
);

export const GoogleIcon = (p: P) => (
  <svg {...base(p)} fill="none" stroke="currentColor" strokeWidth={3.4}>
    <path d="M17.8 6.2A8.2 8.2 0 1 0 20.2 12" strokeLinecap="round" />
    <path d="M12.4 12h8" />
  </svg>
);

export const TeslaIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 22.5 14.2 7c1.7.1 3.3.5 4.6 1.2 0 0 .8-.7 1.1-1.8-1.6-.8-3.4-1.3-5.5-1.5L12 8 9.6 4.9c-2.1.2-3.9.7-5.5 1.5.3 1.1 1.1 1.8 1.1 1.8C6.5 7.5 8.1 7.1 9.8 7L12 22.5Z" />
    <path d="M12 3.3c3.2 0 6.2.6 8.6 1.7l.5-1C18.5 2.6 15.4 2 12 2s-6.5.6-9.1 2l.5 1C5.8 3.9 8.8 3.3 12 3.3Z" />
  </svg>
);
