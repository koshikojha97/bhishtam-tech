"use client";

import { Line, LineChart, XAxis, YAxis } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** Deterministic 12-month price path ending at `end`, overall change `retPct`. */
export function series(end: number, retPct: number, seed = 1) {
  const start = end / (1 + retPct / 100);
  return MONTHS.map((m, i) => {
    const t = i / 11;
    const wobble = i === 0 || i === 11 ? 0 : Math.sin((i + seed) * 1.7) * 0.04 * end;
    return { month: m, value: Math.round(start + (end - start) * t + wobble) };
  });
}

export function MiniLineChart({ data, up, label = "Value" }: { data: { month: string; value: number }[]; up: boolean; label?: string }) {
  const color = up ? "#16DBAA" : "#FE5C73";
  const config = { value: { label, color } } satisfies ChartConfig;
  return (
    <ChartContainer config={config} className="aspect-auto h-[140px] w-full">
      <LineChart data={data} margin={{ left: 4, right: 4, top: 8, bottom: 0 }}>
        <XAxis dataKey="month" tickLine={false} axisLine={false} tick={{ fill: "var(--color-bd-muted)", fontSize: 11 }} interval="preserveStartEnd" />
        <YAxis hide domain={["dataMin - 5%", "dataMax + 5%"]} />
        <ChartTooltip
          cursor={{ stroke: "var(--color-bd-card-border)" }}
          content={<ChartTooltipContent formatter={(v) => <span className="font-medium text-bd-text">${Number(v).toLocaleString("en-US")}</span>} />}
        />
        <Line type="monotone" dataKey="value" stroke="var(--color-value)" strokeWidth={2.5} dot={false} activeDot={{ r: 5, fill: color, stroke: "var(--color-bd-surface)", strokeWidth: 2 }} animationDuration={900} />
      </LineChart>
    </ChartContainer>
  );
}
