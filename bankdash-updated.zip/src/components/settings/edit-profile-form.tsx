"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { useApp, type User } from "@/lib/store";
import { DatePicker, SelectField, type Option } from "@/components/shared/form-controls";
import { ControlField, SaveButton, TextField } from "./fields";
import { PencilIcon } from "./icons";

const COUNTRIES: Option[] = [
  "USA",
  "India",
  "UK",
  "Canada",
  "Australia",
  "Germany",
  "France",
  "Spain",
  "Italy",
  "Netherlands",
  "Japan",
  "Singapore",
  "UAE",
  "Brazil",
  "South Africa",
].map((c) => ({ value: c, label: c }));

type Errors = Partial<Record<"name" | "username" | "email" | "password" | "postalCode", string>>;

const isEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim());

/** Read an image file and downscale it (≤256px, JPEG) to a small data URL for localStorage. */
function fileToAvatar(file: File, max = 256): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error);
    reader.onload = () => {
      const img = new window.Image();
      img.onerror = () => reject(new Error("Invalid image"));
      img.onload = () => {
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("Canvas unavailable"));
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", 0.85));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

function ProfilePhoto({ src, name, onPick }: { src: string; name: string; onPick: (dataUrl: string) => void }) {
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="relative mx-auto size-[170px] shrink-0 lg:mx-0 lg:mt-[4px] lg:size-[110px] xl:mt-[3px] xl:size-[130px]">
      <motion.div
        key={src}
        initial={{ scale: 0.92, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 22 }}
        className="size-full overflow-hidden rounded-full"
      >
        <Image src={src} alt={name} width={170} height={170} className="size-full object-cover" unoptimized={src.startsWith("data:")} priority />
      </motion.div>
      <motion.button
        type="button"
        aria-label="Change profile photo"
        onClick={() => inputRef.current?.click()}
        whileHover={{ scale: 1.12 }}
        whileTap={{ scale: 0.92 }}
        className="absolute right-[-4.6px] bottom-[20px] flex size-[38.6px] cursor-pointer items-center justify-center rounded-full bg-bd-royal text-white lg:right-[-3px] lg:bottom-[13px] lg:size-[25px] xl:right-[-2px] xl:bottom-[16px] xl:size-[30px]"
      >
        <PencilIcon className="size-[18.5px] lg:size-[12px] xl:size-[15px]" />
      </motion.button>
      {/* hidden file picker (not a visible form control) */}
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        aria-label="Profile photo file"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          e.target.value = "";
          if (!f) return;
          if (!f.type.startsWith("image/")) return toast.error("Please choose an image file");
          try {
            onPick(await fileToAvatar(f));
            toast.info("Photo ready — click Save to apply it");
          } catch {
            toast.error("Couldn't read that image");
          }
        }}
      />
    </div>
  );
}

export function EditProfileForm() {
  const user = useApp((s) => s.user);
  const updateUser = useApp((s) => s.updateUser);
  const updateSecurity = useApp((s) => s.updateSecurity);
  const notify = useApp((s) => s.notify);

  const [p, setP] = useState<User>(user);
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<Errors>({});

  // Pick up the persisted profile once the store rehydrates (and after saves).
  useEffect(() => setP(user), [user]);

  const set =
    <K extends keyof User>(k: K) =>
    (v: User[K]) => {
      setP((s) => ({ ...s, [k]: v }));
      if (k in errors) setErrors((e) => ({ ...e, [k]: undefined }));
    };

  const validate = () => {
    const n: Errors = {};
    if (p.name.trim().length < 2) n.name = "Enter your name";
    if (p.username.trim().length < 2) n.username = "Enter a user name";
    if (!isEmail(p.email)) n.email = "Enter a valid email address";
    if (password && (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)))
      n.password = "Use 8+ characters with letters and numbers";
    if (p.postalCode && !/^[A-Za-z0-9 -]{3,10}$/.test(p.postalCode.trim())) n.postalCode = "Enter a valid postal code";
    setErrors(n);
    return Object.keys(n).length === 0;
  };

  const save = () => {
    updateUser({ ...p, name: p.name.trim(), username: p.username.trim(), email: p.email.trim() });
    if (password) {
      updateSecurity({ passwordUpdatedAt: new Date().toISOString() });
      setPassword("");
    }
    notify({ title: "Profile updated", body: "Your personal details were saved", kind: "info", href: "/settings" });
    toast.success("Profile saved");
  };

  return (
    <form
      onSubmit={(e) => e.preventDefault()}
      noValidate
      className="mt-[25px] flex flex-col gap-[22px] lg:mt-[41px] lg:grid lg:grid-cols-[110px_minmax(0,1fr)] lg:gap-x-[45px] lg:gap-y-0 xl:mt-[52px] xl:grid-cols-[130px_minmax(0,1fr)] xl:gap-x-[55px]"
    >
      <ProfilePhoto src={p.avatar} name={p.name} onPick={set("avatar")} />
      <div className="flex min-w-0 flex-col">
        <div className="grid gap-y-[16px] lg:grid-cols-2 lg:gap-x-[26px] lg:gap-y-[14px] xl:gap-x-[29px] xl:gap-y-[22px]">
          <TextField label="Your Name" value={p.name} onChange={set("name")} autoComplete="name" error={errors.name} />
          <TextField label="User Name" value={p.username} onChange={set("username")} autoComplete="username" error={errors.username} />
          <TextField label="Email" type="email" value={p.email} onChange={set("email")} autoComplete="email" error={errors.email} />
          <TextField
            label="Password"
            type="password"
            value={password}
            onChange={(v) => {
              setPassword(v);
              setErrors((e) => ({ ...e, password: undefined }));
            }}
            placeholder="**********"
            autoComplete="new-password"
            error={errors.password}
          />
          <ControlField label="Date of Birth" htmlFor="profile-dob">
            <DatePicker id="profile-dob" value={p.dob} onChange={set("dob")} toYear={new Date().getFullYear()} disabled={(d) => d > new Date()} />
          </ControlField>
          <TextField label="Present Address" value={p.presentAddress} onChange={set("presentAddress")} />
          <TextField label="Permanent Address" value={p.permanentAddress} onChange={set("permanentAddress")} />
          <TextField label="City" value={p.city} onChange={set("city")} />
          <TextField label="Postal Code" value={p.postalCode} onChange={set("postalCode")} autoComplete="postal-code" error={errors.postalCode} />
          <ControlField label="Country" htmlFor="profile-country">
            <SelectField id="profile-country" value={p.country} onValueChange={set("country")} options={p.country && !COUNTRIES.some((c) => c.value === p.country) ? [{ value: p.country, label: p.country }, ...COUNTRIES] : COUNTRIES}
              placeholder="Select country" />
          </ControlField>
        </div>
        <div className="mt-[20px] lg:mt-[25px] xl:mt-[30px]">
          <SaveButton onValidate={validate} onSave={save} />
        </div>
      </div>
    </form>
  );
}
