"use client";

import { useState } from "react";
import { toast } from "sonner";
import { useApp, timeAgo } from "@/lib/store";
import { SaveButton, SubHeading, TextField, ToggleRow } from "./fields";

type Errors = Partial<Record<"current" | "next" | "confirm", string>>;

export function SecurityForm() {
  const twoFactor = useApp((s) => s.security.twoFactor);
  const passwordUpdatedAt = useApp((s) => s.security.passwordUpdatedAt);
  const updateSecurity = useApp((s) => s.updateSecurity);
  const notify = useApp((s) => s.notify);

  const [pwd, setPwd] = useState({ current: "", next: "", confirm: "" });
  const [errors, setErrors] = useState<Errors>({});
  const set = (k: keyof typeof pwd) => (v: string) => {
    setPwd((s) => ({ ...s, [k]: v }));
    setErrors((e) => ({ ...e, [k]: undefined }));
  };

  const toggle2fa = (v: boolean) => {
    updateSecurity({ twoFactor: v });
    notify({
      title: v ? "Two-factor enabled" : "Two-factor disabled",
      body: v ? "Sign-ins now require a verification code" : "Your account is less protected without 2FA",
      kind: "security",
      href: "/settings?tab=security",
    });
    if (v) toast.success("Two-factor authentication enabled");
    else toast.warning("Two-factor authentication disabled");
  };

  const validate = () => {
    const n: Errors = {};
    if (!pwd.current) n.current = "Enter your current password";
    if (pwd.next.length < 8 || !/[A-Za-z]/.test(pwd.next) || !/\d/.test(pwd.next)) n.next = "Use 8+ characters with letters and numbers";
    else if (pwd.next === pwd.current) n.next = "New password must differ from the current one";
    if (!pwd.confirm || pwd.confirm !== pwd.next) n.confirm = "Passwords do not match";
    setErrors(n);
    return Object.keys(n).length === 0;
  };

  return (
    <form onSubmit={(e) => e.preventDefault()} noValidate className="mt-[21px] flex flex-col lg:mt-[31px] xl:mt-[37px]">
      <SubHeading>Two-factor Authentication</SubHeading>
      <div className="mt-[12px] lg:mt-[16px] xl:mt-[19px]">
        <ToggleRow label="Enable or disable two factor authentication" checked={twoFactor} onCheckedChange={toggle2fa} />
      </div>

      <SubHeading className="mt-[19px] lg:mt-[22px] xl:mt-[27px]">Change Password</SubHeading>
      {passwordUpdatedAt && (
        <p className="mt-[6px] text-[12px] text-bd-muted xl:text-[14px]" suppressHydrationWarning>
          Last changed {timeAgo(passwordUpdatedAt)}
        </p>
      )}
      <div className="mt-[14px] flex flex-col gap-[16px] lg:mt-[13px] lg:w-[calc(50%-12.5px)] lg:gap-[14px] xl:mt-[16px] xl:w-[calc(50%-15px)] xl:gap-[22px]">
        <TextField label="Current Password" type="password" value={pwd.current} onChange={set("current")} placeholder="**********" autoComplete="current-password" error={errors.current} />
        <TextField label="New Password" type="password" value={pwd.next} onChange={set("next")} placeholder="**********" autoComplete="new-password" error={errors.next} />
        <TextField label="Confirm New Password" type="password" value={pwd.confirm} onChange={set("confirm")} placeholder="**********" autoComplete="new-password" error={errors.confirm} />
      </div>

      <div className="mt-[20px] lg:mt-[25px] xl:mt-[30px]">
        <SaveButton
          onValidate={validate}
          onSave={() => {
            updateSecurity({ passwordUpdatedAt: new Date().toISOString() });
            notify({ title: "Password changed", body: "Your account password was updated", kind: "security", href: "/settings?tab=security" });
            toast.success("Password updated");
            setPwd({ current: "", next: "", confirm: "" });
          }}
        />
      </div>
    </form>
  );
}
