"use client";

import { useEffect, useId, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { Eye, EyeOff } from "lucide-react";
import { Label } from "@/components/ui/label";
import { TextInput } from "@/components/shared/form-controls";
import { CheckIcon } from "./icons";

/* ---------- shared class strings (mobile → lg tablet → xl desktop) ---------- */

const labelCls = "text-[13px] leading-[1.21] text-bd-text xl:text-[16px]";

/** Section sub-heading (Notification / Two-factor Authentication / Change Password). */
export function SubHeading({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <h3 className={cn("text-[14px] leading-[1.21] font-medium text-bd-primary xl:text-[17px]", className)}>{children}</h3>
  );
}

/** Label + controlled shadcn Input (password fields get a show/hide toggle). */
export function TextField({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  autoComplete,
  className,
  error,
  name,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: React.HTMLInputTypeAttribute;
  placeholder?: string;
  autoComplete?: string;
  className?: string;
  error?: string;
  name?: string;
}) {
  const id = useId();
  const [reveal, setReveal] = useState(false);
  const isPwd = type === "password";
  return (
    <motion.div
      animate={error ? { x: [0, -6, 6, -4, 4, 0] } : { x: 0 }}
      transition={{ duration: 0.35 }}
      className={cn("flex min-w-0 flex-col gap-[9px] lg:gap-[7px] xl:gap-[11px]", className)}
    >
      <Label htmlFor={id} className={cn(labelCls, "font-normal")}>
        {label}
      </Label>
      <div className="relative">
        <TextInput
          id={id}
          name={name}
          type={isPwd && reveal ? "text" : type}
          value={value}
          placeholder={placeholder}
          autoComplete={autoComplete}
          invalid={!!error}
          onChange={(e) => onChange(e.target.value)}
          className={cn("text-bd-muted", isPwd && "pr-[44px] xl:pr-[52px]")}
        />
        {isPwd && (
          <button
            type="button"
            onClick={() => setReveal((r) => !r)}
            aria-label={reveal ? `Hide ${label}` : `Show ${label}`}
            className="absolute inset-y-0 right-0 flex w-[44px] cursor-pointer items-center justify-center text-bd-muted transition-colors hover:text-bd-royal xl:w-[52px]"
          >
            {reveal ? <EyeOff className="size-[16px] xl:size-[18px]" /> : <Eye className="size-[16px] xl:size-[18px]" />}
          </button>
        )}
      </div>
      <AnimatePresence initial={false}>
        {error && (
          <motion.p
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            role="alert"
            className="text-[12px] text-bd-red xl:text-[13px]"
          >
            {error}
          </motion.p>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

/** Label wrapper for shadcn-based controls (DatePicker, SelectField). */
export function ControlField({ label, htmlFor, children }: { label: string; htmlFor: string; children: React.ReactNode }) {
  return (
    <div className="flex min-w-0 flex-col gap-[9px] lg:gap-[7px] xl:gap-[11px]">
      <Label htmlFor={htmlFor} className={cn(labelCls, "font-normal")}>
        {label}
      </Label>
      {children}
    </div>
  );
}

/** Notification / 2FA row: shadcn Switch restyled to the Figma toggle (teal on / #DFEAF2 off). */
export function ToggleRow({
  label,
  checked,
  onCheckedChange,
}: {
  label: string;
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
}) {
  const id = useId();
  return (
    <div className="flex items-center gap-[12px] lg:gap-[16px] xl:gap-[20px]">
      <Switch
        id={id}
        checked={checked}
        onCheckedChange={onCheckedChange}
        className={cn(
          "h-[24px]! w-[44px]! cursor-pointer border-0 px-[2px] shadow-[0_3px_6px_rgba(0,0,0,0.06)] xl:h-[31px]! xl:w-[56px]! xl:px-[2.5px]",
          "data-[state=checked]:bg-bd-teal! data-[state=unchecked]:bg-bd-card-border!",
          "focus-visible:ring-bd-teal/30",
          "[&>span]:size-[20px]! [&>span]:bg-white! [&>span]:shadow-[0_2px_4px_rgba(0,0,0,0.15)] xl:[&>span]:size-[26px]!",
          "[&>span]:duration-300 [&>span]:ease-[cubic-bezier(0.34,1.56,0.64,1)]",
          "[&>span[data-state=checked]]:translate-x-[20px] xl:[&>span[data-state=checked]]:translate-x-[25px]",
        )}
      />
      <label htmlFor={id} className="cursor-pointer text-[13px] leading-[1.21] text-bd-text select-none xl:text-[16px]">
        {label}
      </label>
    </div>
  );
}

/** Save button with a short "saving → saved ✓" success animation. */
/** `onValidate` runs first; returning false aborts (show inline errors there). */
export function SaveButton({ onSave, onValidate }: { onSave?: () => void; onValidate?: () => boolean }) {
  const [state, setState] = useState<"idle" | "saving" | "saved">("idle");
  const timers = useRef<number[]>([]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const click = () => {
    if (state !== "idle") return;
    if (onValidate && !onValidate()) return;
    setState("saving");
    timers.current.push(
      window.setTimeout(() => {
        onSave?.();
        setState("saved");
      }, 650),
      window.setTimeout(() => setState("idle"), 2300),
    );
  };

  return (
    <div className="flex justify-end">
      <motion.button
        type="submit"
        disabled={state === "saving"}
        aria-busy={state === "saving"}
        onClick={(e) => {
          e.preventDefault();
          click();
        }}
        whileHover={state === "idle" ? { y: -2, boxShadow: "0 10px 22px -8px rgba(24,20,243,0.55)" } : undefined}
        whileTap={{ scale: 0.97 }}
        animate={state === "saved" ? { scale: [1, 1.05, 1] } : { scale: 1 }}
        transition={{ duration: 0.35 }}
        aria-live="polite"
        className={cn(
          "relative flex h-[40px] w-full cursor-pointer items-center justify-center overflow-hidden rounded-[9px] text-[15px] leading-[1.21] font-medium text-white transition-colors lg:w-[130px] xl:h-[50px] xl:w-[190px] xl:rounded-[15px] xl:text-[18px]",
          state === "saved" ? "bg-bd-green" : "bg-bd-royal",
        )}
      >
        <AnimatePresence mode="popLayout" initial={false}>
          {state === "idle" && (
            <motion.span key="idle" initial={{ y: 14, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -14, opacity: 0 }}>
              Save
            </motion.span>
          )}
          {state === "saving" && (
            <motion.span
              key="saving"
              initial={{ y: 14, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -14, opacity: 0 }}
              className="flex items-center"
            >
              <motion.span
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 0.8, ease: "linear" }}
                className="block size-[18px] rounded-full border-2 border-white/40 border-t-white"
              />
            </motion.span>
          )}
          {state === "saved" && (
            <motion.span
              key="saved"
              initial={{ y: 14, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -14, opacity: 0 }}
              className="flex items-center gap-[6px]"
            >
              <CheckIcon className="size-[18px]" />
              Saved
            </motion.span>
          )}
        </AnimatePresence>
      </motion.button>
    </div>
  );
}
