"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useApp, type Preferences } from "@/lib/store";
import { SelectField, type Option } from "@/components/shared/form-controls";
import { ThemePicker } from "@/components/layout/theme-toggle";
import { ControlField, SaveButton, SubHeading, ToggleRow } from "./fields";

const CURRENCIES: Option[] = [
  { value: "USD", label: "USD" },
  { value: "EUR", label: "EUR" },
  { value: "GBP", label: "GBP" },
  { value: "INR", label: "INR" },
  { value: "JPY", label: "JPY" },
  { value: "CAD", label: "CAD" },
  { value: "AUD", label: "AUD" },
  { value: "SGD", label: "SGD" },
  { value: "AED", label: "AED" },
];

const TIME_ZONES: Option[] = [
  "(GMT-12:00) International Date Line West",
  "(GMT-10:00) Hawaii",
  "(GMT-08:00) Pacific Time (US & Canada)",
  "(GMT-07:00) Mountain Time (US & Canada)",
  "(GMT-06:00) Central Time (US & Canada)",
  "(GMT-05:00) Eastern Time (US & Canada)",
  "(GMT-03:00) Brasilia",
  "(GMT+00:00) London, Dublin, Lisbon",
  "(GMT+01:00) Berlin, Paris, Rome, Madrid",
  "(GMT+02:00) Athens, Cairo, Johannesburg",
  "(GMT+03:00) Moscow, Istanbul, Riyadh",
  "(GMT+04:00) Abu Dhabi, Dubai",
  "(GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi",
  "(GMT+08:00) Singapore, Hong Kong, Beijing",
  "(GMT+09:00) Tokyo, Seoul",
  "(GMT+10:00) Sydney, Melbourne",
  "(GMT+12:00) Auckland, Wellington",
].map((z) => ({ value: z, label: z }));

const NOTIFICATIONS = [
  { key: "notifyDigitalCurrency", label: "I send or receive digita currency" },
  { key: "notifyMerchantOrder", label: "I receive merchant order" },
  { key: "notifyRecommendations", label: "There are recommendation for my account" },
] as const;

export function PreferencesForm() {
  const prefs = useApp((s) => s.preferences);
  const updatePreferences = useApp((s) => s.updatePreferences);
  const notify = useApp((s) => s.notify);
  const [p, setP] = useState<Preferences>(prefs);

  // sync with the persisted store after rehydration / save
  useEffect(() => setP(prefs), [prefs]);

  const set = <K extends keyof Preferences>(k: K) => (v: Preferences[K]) => setP((s) => ({ ...s, [k]: v }));

  return (
    <form onSubmit={(e) => e.preventDefault()} className="mt-[22px] flex flex-col lg:mt-[31px] xl:mt-[42px]">
      <div className="grid gap-y-[16px] lg:grid-cols-2 lg:gap-x-[25px] xl:gap-x-[30px]">
        <ControlField label="Currency" htmlFor="pref-currency">
          <SelectField id="pref-currency" value={p.currency} onValueChange={set("currency")} options={CURRENCIES} />
        </ControlField>
        <ControlField label="Time Zone" htmlFor="pref-timezone">
          <SelectField
            id="pref-timezone"
            value={p.timeZone}
            onValueChange={set("timeZone")}
            options={TIME_ZONES.some((z) => z.value === p.timeZone) ? TIME_ZONES : [{ value: p.timeZone, label: p.timeZone }, ...TIME_ZONES]}
          />
        </ControlField>
      </div>

      <SubHeading className="mt-[22px] lg:mt-[21px] xl:mt-[27px]">Theme</SubHeading>
      <div className="mt-[13px] lg:mt-[17px] xl:mt-[19px]">
        <ThemePicker />
      </div>

      <SubHeading className="mt-[22px] lg:mt-[21px] xl:mt-[27px]">Notification</SubHeading>
      <div className="mt-[13px] flex flex-col gap-[18px] lg:mt-[17px] lg:gap-[15px] xl:mt-[19px]">
        {NOTIFICATIONS.map((n) => (
          <ToggleRow key={n.key} label={n.label} checked={p[n.key]} onCheckedChange={set(n.key)} />
        ))}
      </div>

      <div className="mt-[17px] lg:mt-[54px] xl:mt-[72px]">
        <SaveButton
          onSave={() => {
            updatePreferences(p);
            notify({ title: "Preferences updated", body: `Currency ${p.currency} · ${p.timeZone}`, kind: "info", href: "/settings?tab=preferences" });
            toast.success("Preferences saved");
          }}
        />
      </div>
    </form>
  );
}
