import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;

/** Font Awesome "pencil-alt" glyph used in the profile-photo edit badge. */
export const PencilIcon = (p: P) => (
  <svg viewBox="0 0 512 512" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M497.9 142.1l-46.1 46.1c-4.7 4.7-12.3 4.7-17 0l-111-111c-4.7-4.7-4.7-12.3 0-17l46.1-46.1c18.7-18.7 49.1-18.7 67.9 0l60.1 60.1c18.8 18.7 18.8 49.1 0 67.9zM284.2 99.8L21.6 362.4.4 483.9c-2.9 16.4 11.4 30.6 27.8 27.8l121.5-21.3 262.6-262.6c4.7-4.7 4.7-12.3 0-17l-111-111c-4.8-4.7-12.4-4.7-17.1 0zM124.1 339.9c-5.5-5.5-5.5-14.3 0-19.8l154-154c5.5-5.5 14.3-5.5 19.8 0s5.5 14.3 0 19.8l-154 154c-5.5 5.5-14.3 5.5-19.8 0zM88 424h48v36.3l-64.5 11.3-31.1-31.1L51.7 376H88v48z" />
  </svg>
);

/** Thin chevron used on the Date of Birth field (12×6 desktop, 10×5 tablet/mobile). */
export const ChevronDownIcon = (p: P) => (
  <svg viewBox="0 0 12 6" fill="none" aria-hidden="true" {...p}>
    <path d="M1 0.5L6 5.5L11 0.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const CheckIcon = (p: P) => (
  <svg viewBox="0 0 20 20" fill="none" aria-hidden="true" {...p}>
    <path d="M4 10.5l4 4 8-9" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
