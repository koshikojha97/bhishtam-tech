"use client";

import { motion } from "framer-motion";
import { Logo } from "@/components/shared/logo";
import { BankCard } from "@/components/shared/bank-card";

const float = (delay: number, y = 10) => ({
  animate: { y: [0, -y, 0] },
  transition: { duration: 5, repeat: Infinity, ease: "easeInOut" as const, delay },
});

/** Brand panel on the left (≥1024px): gradient, floating BankDash cards, mini stats. */
function BrandPanel() {
  return (
    <div className="relative hidden overflow-hidden bg-[linear-gradient(135deg,#4C49ED_0%,#1814F3_55%,#0A06F4_100%)] lg:flex lg:w-[46%] lg:flex-col lg:justify-between lg:p-[48px] xl:p-[60px]">
      {/* decorative rings */}
      <motion.div
        className="pointer-events-none absolute -top-[180px] -right-[160px] size-[520px] rounded-full border-[60px] border-white/5"
        animate={{ rotate: 360 }}
        transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
      />
      <div className="pointer-events-none absolute -bottom-[220px] -left-[140px] size-[480px] rounded-full bg-white/5" />

      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="relative">
        <span className="inline-flex rounded-[15px] bg-white px-[18px] py-[12px]">
          <Logo />
        </span>
      </motion.div>

      <div className="relative mx-auto h-[330px] w-full max-w-[440px]">
        <motion.div
          initial={{ opacity: 0, x: -40, rotate: -10 }}
          animate={{ opacity: 1, x: 0, rotate: -8 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="absolute top-[10px] left-0 w-[300px] xl:w-[330px]"
        >
          <motion.div {...float(0)}>
            <BankCard card={{ balance: "$5,756", holder: "Eddy Cusuma", validThru: "12/22", number: "3778 **** **** 1234", variant: "white" }} />
          </motion.div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 40, rotate: 10 }}
          animate={{ opacity: 1, x: 0, rotate: 6 }}
          transition={{ duration: 0.8, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          className="absolute right-0 bottom-0 w-[300px] shadow-[0_30px_60px_-20px_rgba(0,0,0,0.45)] xl:w-[330px]"
          style={{ borderRadius: 25 }}
        >
          <motion.div {...float(1.2, 14)}>
            <BankCard card={{ balance: "$12,460", holder: "Eddy Cusuma", validThru: "08/27", number: "4532 **** **** 9876", variant: "dark" }} />
          </motion.div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.6, type: "spring" }}
          className="absolute -top-[30px] right-[10px] z-10 rounded-[15px] bg-white px-[16px] py-[12px] shadow-[0_20px_40px_-15px_rgba(0,0,0,0.35)]"
        >
          <motion.div {...float(0.6, 6)}>
            <p className="text-[12px] text-bd-muted">Monthly Revenue</p>
            <p className="text-[18px] font-semibold text-bd-primary">
              +$5,400 <span className="text-[12px] font-medium text-bd-green">▲ 12%</span>
            </p>
          </motion.div>
        </motion.div>
      </div>

      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="relative text-white">
        <h2 className="text-[28px] leading-[1.25] font-semibold xl:text-[32px]">
          Manage your money,
          <br />
          cards and investments.
        </h2>
        <p className="mt-[12px] max-w-[420px] text-[15px] leading-[1.6] text-white/70 xl:text-[16px]">
          One dashboard for transactions, accounts, credit cards, loans and more — secure and always in sync.
        </p>
      </motion.div>
    </div>
  );
}

export function AuthShell({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-bd-page lg:bg-bd-surface">
      <BrandPanel />
      <div className="flex flex-1 flex-col items-center justify-center px-[25px] py-[40px] lg:px-[48px]">
        <div className="mb-[30px] lg:hidden">
          <Logo />
        </div>
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="w-full max-w-[460px] rounded-[15px] bg-bd-surface p-[25px] lg:rounded-[25px] lg:p-[10px] xl:max-w-[480px]"
        >
          <h1 className="text-[22px] leading-normal font-semibold text-bd-primary xl:text-[28px]">{title}</h1>
          <p className="mt-[8px] text-[13px] leading-[1.5] text-bd-muted xl:text-[16px]">{subtitle}</p>
          <div className="mt-[25px] xl:mt-[35px]">{children}</div>
        </motion.div>
      </div>
    </div>
  );
}
