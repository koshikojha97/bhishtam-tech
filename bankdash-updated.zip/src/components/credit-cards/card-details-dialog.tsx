"use client";

import { useState } from "react";
import { toast } from "sonner";
import { AnimatePresence, motion } from "framer-motion";
import { Ban, LockOpen, Star, Trash2 } from "lucide-react";
import { BankCard } from "@/components/shared/bank-card";
import { money, useApp } from "@/lib/store";
import { cn } from "@/lib/utils";
import { BdDialog, ConfirmDialog, dangerBtn, outlineBtn, primaryBtn } from "./dialog-kit";
import { last4 } from "./card-utils";

export function BlockedOverlay({ show }: { show: boolean }) {
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center rounded-[15px] bg-bd-primary/55 backdrop-blur-[2px] xl:rounded-[25px]"
        >
          <motion.span
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="flex items-center gap-[6px] rounded-full bg-white px-[14px] py-[6px] text-[13px] font-semibold text-bd-red xl:text-[15px]"
          >
            <Ban className="size-[14px] xl:size-[16px]" /> Blocked
          </motion.span>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-[12px] border-b border-bd-border py-[10px] last:border-0">
      <span className="text-[13px] text-bd-muted xl:text-[14px]">{label}</span>
      <span className="text-right text-[13px] font-medium text-bd-primary xl:text-[15px]">{value}</span>
    </div>
  );
}

export function CardDetailsDialog({ cardId, open, onOpenChange }: { cardId: string | null; open: boolean; onOpenChange: (v: boolean) => void }) {
  const card = useApp((s) => s.cards.find((c) => c.id === cardId));
  const cards = useApp((s) => s.cards);
  const updateCard = useApp((s) => s.updateCard);
  const removeCard = useApp((s) => s.removeCard);
  const notify = useApp((s) => s.notify);
  const [confirm, setConfirm] = useState<null | "block" | "remove">(null);

  if (!card) return null;
  const end = last4(card);
  const wallets = [card.wallets.google && "Google Pay", card.wallets.apple && "Apple Pay", card.wallets.appleStore && "Apple Store"].filter(Boolean).join(", ") || "None";

  const toggleBlock = () => {
    const blocked = !card.blocked;
    updateCard(card.id, { blocked });
    const title = blocked ? "Card blocked" : "Card unblocked";
    const body = `${card.bank} card ending ${end} was ${blocked ? "blocked" : "unblocked"}`;
    notify({ title, body, kind: "card", href: "/credit-cards" });
    toast.success(title, { description: body });
  };

  const remove = () => {
    removeCard(card.id);
    onOpenChange(false);
    notify({ title: "Card removed", body: `${card.bank} card ending ${end} was removed`, kind: "card", href: "/credit-cards" });
    toast.success("Card removed", { description: `${card.bank} card ending ${end}` });
  };

  const makePrimary = () => {
    cards.forEach((c) => {
      if (c.type !== (c.id === card.id ? "Primary" : "Secondary")) updateCard(c.id, { type: c.id === card.id ? "Primary" : "Secondary" });
    });
    notify({ title: "Primary card changed", body: `${card.bank} card ending ${end} is now your primary card`, kind: "card", href: "/credit-cards" });
    toast.success("Primary card updated", { description: `${card.bank} card ending ${end}` });
  };

  return (
    <>
      <BdDialog open={open} onOpenChange={onOpenChange} title="Card Details" description={`${card.bank} · ${card.type} card`}>
        <div className="relative mx-auto max-w-[350px]">
          <BankCard card={{ balance: money(card.balance), holder: card.holder, validThru: card.validThru, number: card.number, variant: card.variant }} className="[&_p]:whitespace-nowrap" />
          <BlockedOverlay show={card.blocked} />
        </div>
        <div className="mt-[16px]">
          <Row label="Bank" value={card.bank} />
          <Row label="Card Type" value={card.type} />
          <Row label="Card Number" value={card.number} />
          <Row label="Name on Card" value={card.nameOnCard} />
          <Row label="Card Holder" value={card.holder} />
          <Row label="Valid Thru" value={card.validThru} />
          <Row label="Balance" value={money(card.balance)} />
          <Row label="Wallets" value={wallets} />
          <Row
            label="Status"
            value={<span className={cn("rounded-full px-[10px] py-[3px] text-[12px]", card.blocked ? "bg-bd-tint-red text-bd-red" : "bg-bd-tint-teal text-[#16A99E]")}>{card.blocked ? "Blocked" : "Active"}</span>}
          />
        </div>
        <div className="mt-[18px] grid grid-cols-1 gap-[10px] sm:grid-cols-3 [&>button]:px-[12px]">
          <button type="button" className={primaryBtn} disabled={card.type === "Primary"} onClick={makePrimary}>
            <Star className="size-[16px]" /> {card.type === "Primary" ? "Primary" : "Set as Primary"}
          </button>
          <button type="button" className={outlineBtn} onClick={() => setConfirm("block")}>
            {card.blocked ? <LockOpen className="size-[16px]" /> : <Ban className="size-[16px]" />} {card.blocked ? "Unblock" : "Block"}
          </button>
          <button type="button" className={dangerBtn} onClick={() => setConfirm("remove")}>
            <Trash2 className="size-[16px]" /> Remove
          </button>
        </div>
      </BdDialog>
      <ConfirmDialog
        open={confirm === "block"}
        onOpenChange={(v) => !v && setConfirm(null)}
        title={card.blocked ? "Unblock this card?" : "Block this card?"}
        description={
          card.blocked
            ? `The ${card.bank} card ending ${end} will work again for payments and withdrawals.`
            : `All payments and withdrawals on the ${card.bank} card ending ${end} will be declined until you unblock it.`
        }
        confirmLabel={card.blocked ? "Unblock card" : "Block card"}
        destructive={!card.blocked}
        onConfirm={toggleBlock}
      />
      <ConfirmDialog
        open={confirm === "remove"}
        onOpenChange={(v) => !v && setConfirm(null)}
        title="Remove this card?"
        description={`The ${card.bank} card ending ${end} will be removed from your account. This can't be undone.`}
        confirmLabel="Remove card"
        destructive
        onConfirm={remove}
      />
    </>
  );
}
