"use client";

/**
 * BankDash-styled wrappers around shadcn Dialog / AlertDialog, shared by the
 * Credit Cards, Services and My Privileges pages.
 */
import { useEffect } from "react";
import { motion, useAnimationControls } from "framer-motion";
import { Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

export const primaryBtn =
  "inline-flex h-[40px] items-center whitespace-nowrap justify-center gap-[8px] rounded-[10px] bg-bd-royal px-[22px] text-[14px] font-medium text-white transition-[transform,box-shadow,opacity] hover:-translate-y-[1px] hover:shadow-[0_10px_20px_-8px_rgba(24,20,243,0.55)] disabled:pointer-events-none disabled:opacity-60 xl:h-[45px] xl:rounded-[15px] xl:text-[15px]";
export const outlineBtn =
  "inline-flex h-[40px] items-center whitespace-nowrap justify-center gap-[8px] rounded-[10px] border border-bd-card-border bg-bd-surface px-[22px] text-[14px] font-medium text-bd-primary transition-colors hover:border-bd-royal hover:text-bd-royal disabled:pointer-events-none disabled:opacity-60 xl:h-[45px] xl:rounded-[15px] xl:text-[15px]";
export const dangerBtn =
  "inline-flex h-[40px] items-center whitespace-nowrap justify-center gap-[8px] rounded-[10px] bg-bd-red px-[22px] text-[14px] font-medium text-white transition-opacity hover:opacity-90 disabled:pointer-events-none disabled:opacity-60 xl:h-[45px] xl:rounded-[15px] xl:text-[15px]";

const contentCls = "max-h-[calc(100dvh-2rem)] overflow-y-auto rounded-[20px] border-none bg-bd-surface p-[22px] shadow-[0_30px_60px_-20px_rgba(52,60,106,0.35)] sm:max-w-[480px] xl:rounded-[25px] xl:p-[30px]";
const titleCls = "text-left text-[18px] leading-tight font-semibold text-bd-primary xl:text-[22px]";
const descCls = "text-left text-[13px] leading-[20px] text-bd-muted xl:text-[15px] xl:leading-[22px]";

export function BdDialog({
  open,
  onOpenChange,
  title,
  description,
  className,
  children,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title: React.ReactNode;
  description?: React.ReactNode;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={cn(contentCls, className)}>
        <DialogHeader className="gap-[6px]">
          <DialogTitle className={titleCls}>{title}</DialogTitle>
          {description ? <DialogDescription className={descCls}>{description}</DialogDescription> : <DialogDescription className="sr-only">{String(title)}</DialogDescription>}
        </DialogHeader>
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }} className="min-w-0">
          {children}
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}

export function ConfirmDialog({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel = "Confirm",
  destructive,
  onConfirm,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title: React.ReactNode;
  description: React.ReactNode;
  confirmLabel?: string;
  destructive?: boolean;
  onConfirm: () => void;
}) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className={cn(contentCls, "sm:max-w-[420px]")}>
        <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.25 }} className="grid gap-[20px]">
          <AlertDialogHeader className="gap-[6px] text-left sm:text-left">
            <AlertDialogTitle className={titleCls}>{title}</AlertDialogTitle>
            <AlertDialogDescription className={descCls}>{description}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row justify-end gap-[10px]">
            <AlertDialogCancel className={cn(outlineBtn, "mt-0 shadow-none")}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={onConfirm} className={cn(destructive ? dangerBtn : primaryBtn, destructive ? "hover:bg-bd-red" : "hover:bg-bd-royal")}>
              {confirmLabel}
            </AlertDialogAction>
          </AlertDialogFooter>
        </motion.div>
      </AlertDialogContent>
    </AlertDialog>
  );
}

export function Spinner() {
  return <Loader2 className="size-[16px] animate-spin" />;
}

/** Wrap a form; re-keying `shakeKey` replays a horizontal shake (invalid submit). */
export function Shake({ shakeKey, className, children }: { shakeKey: number; className?: string; children: React.ReactNode }) {
  const controls = useAnimationControls();
  useEffect(() => {
    if (shakeKey) void controls.start({ x: [0, -8, 8, -6, 6, -3, 3, 0], transition: { duration: 0.45 } });
  }, [shakeKey, controls]);
  return (
    <motion.div animate={controls} className={className}>
      {children}
    </motion.div>
  );
}

export const wait = (ms = 700) => new Promise((r) => setTimeout(r, ms));
