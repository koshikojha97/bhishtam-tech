import type { Card, CardVariant } from "@/lib/store";

/** "My Cards" look for the first three slots (Figma: sky gradient, royal blue, white). */
export const SLOT_STYLES: { variant: CardVariant; className?: string }[] = [
  { variant: "blue", className: "bg-[linear-gradient(116deg,#2D60FF_2.6%,#539BFF_101.2%)]" },
  { variant: "blue" },
  { variant: "white" },
];

export function slotStyle(card: Card, i: number) {
  return SLOT_STYLES[i] ?? { variant: card.variant };
}

/** Card List icon tints (Figma: blue, pink, yellow), cycled. */
export const LIST_TINTS = [
  { bg: "bg-[#E7EDFF]", fg: "text-[#396AFF]" },
  { bg: "bg-[#FFE0EB]", fg: "text-[#FF82AC]" },
  { bg: "bg-[#FFF5D9]", fg: "text-[#FFBB38]" },
];

export const last4 = (c: Card) => c.number.replace(/\D/g, "").slice(-4);
export const shortNumber = (c: Card) => `**** **** ${last4(c)}`;
export const cardLabel = (c: Card) => `${c.bank} •••• ${last4(c)} (${c.nameOnCard})`;
export const cardOptions = (cards: Card[]) => cards.map((c) => ({ value: c.id, label: cardLabel(c) }));

export const CARD_TYPES = ["Classic", "Gold", "Platinum", "Business"] as const;
export const TYPE_VARIANT: Record<string, CardVariant> = { Classic: "lightBlue", Gold: "dark", Platinum: "blue", Business: "white" };

/** Luhn checksum on a 16-digit number. */
export function luhn(digits: string) {
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let d = +digits[digits.length - 1 - i];
    if (i % 2 === 1) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
  }
  return sum % 10 === 0;
}

export function formatCardNumber(v: string) {
  return v
    .replace(/\D/g, "")
    .slice(0, 16)
    .replace(/(.{4})/g, "$1 ")
    .trim();
}
