/**
 * Credit Cards page icons — hand-built SVGs approximating the Figma glyphs
 * (figma.com asset export is blocked in the build sandbox). All use `currentColor`.
 */
import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;

/** "001-block-credit-card" — card with a blocked badge. */
export const BlockCardIcon = (p: P) => (
  <svg width={25} height={25} viewBox="0 0 25 25" fill="currentColor" {...p}>
    <path d="M2.4 2h17.2A2.4 2.4 0 0 1 22 4.4V5H0v-.6A2.4 2.4 0 0 1 2.4 2ZM0 7.4h22v3.3a7.3 7.3 0 0 0-10.3 9H2.4A2.4 2.4 0 0 1 0 17.3V7.4Zm2.8 5.3v1.6h6.3v-1.6H2.8Z" />
    <path d="M18.6 11.6a6.2 6.2 0 1 0 0 12.4 6.2 6.2 0 0 0 0-12.4Zm0 1.7c.9 0 1.7.3 2.4.8l-6 6a4.5 4.5 0 0 1 3.6-6.8Zm0 9a4.5 4.5 0 0 1-2.4-.7l6-6a4.5 4.5 0 0 1-3.6 6.7Z" />
  </svg>
);

/** "002-padlock" — outlined padlock with keyhole. */
export const PadlockIcon = (p: P) => (
  <svg width={25} height={25} viewBox="0 0 25 25" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" {...p}>
    <rect x="3.4" y="10.4" width="18.2" height="13.6" rx="2.2" />
    <path d="M7 10.4V7a5.5 5.5 0 0 1 11 0v3.4" />
    <path d="M12.5 15.3v3.5" strokeWidth={2.2} />
  </svg>
);

/** "003-google-glass-logo" — the Google "G" outline. */
export const GoogleIcon = (p: P) => (
  <svg width={25} height={25} viewBox="0 0 25 25" fill="none" stroke="currentColor" strokeWidth={2.1} {...p}>
    <path d="M20.6 5.2A11 11 0 1 0 23.5 12.5H13" strokeLinecap="round" />
  </svg>
);

/** "apple 2 1" — outlined apple logo. */
export const AppleIcon = (p: P) => (
  <svg width={25} height={25} viewBox="0 0 25 25" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" {...p}>
    <path d="M16.6 7.6c-1.4 0-2.6.9-4.1.9s-2.5-.9-4-.9c-2.5 0-4.6 2.2-4.6 5.6 0 4.2 3 9.8 5 9.8 1.4 0 1.8-.9 3.6-.9s2.1.9 3.6.9c1.6 0 3.2-2.8 3.8-4.7-1.8-.8-2.8-2.3-2.8-4.2 0-1.6.9-3 2.2-3.7-.9-1.6-2.6-2.8-4.7-2.8Z" />
    <path d="M12.5 7.3c-.2-2.6 1.6-4.8 4-5.1.3 2.4-1.6 4.9-4 5.1Z" />
  </svg>
);

/** Small dropdown chevron used in the Expiration Date field. */
export const ChevronDownIcon = (p: P) => (
  <svg width={12} height={7} viewBox="0 0 12 7" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="m1 1 5 5 5-5" />
  </svg>
);
