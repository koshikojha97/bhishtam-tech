"use client";

import { useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import { format, parse } from "date-fns";
import { toast } from "sonner";
import { Panel } from "@/components/shared/section";
import { DatePicker, Field, SelectField, TextInput } from "@/components/shared/form-controls";
import { Label } from "@/components/ui/label";
import { useApp } from "@/lib/store";
import { CARD_TYPES, TYPE_VARIANT, formatCardNumber, luhn } from "./card-utils";
import { Shake, Spinner, wait } from "./dialog-kit";

const labelCls = "text-[13px] leading-[16px] font-normal text-bd-text lg:text-[12px] lg:leading-[15px] xl:text-[16px] xl:leading-[19px]";
const TYPE_OPTIONS = CARD_TYPES.map((t) => ({ value: t, label: t }));
const EMPTY = { type: "", name: "", number: "", expiry: "" };
type Errors = Partial<Record<keyof typeof EMPTY, string>>;

function validate(f: typeof EMPTY): Errors {
  const e: Errors = {};
  const digits = f.number.replace(/\D/g, "");
  if (!f.type) e.type = "Choose a card type.";
  if (f.name.trim().length < 2) e.name = "Enter the name printed on the card.";
  if (digits.length !== 16) e.number = "Card number must be 16 digits.";
  else if (!luhn(digits)) e.number = "This card number isn't valid — please check it.";
  if (!f.expiry) e.expiry = "Pick the expiration date.";
  else if (parse(f.expiry, "yyyy-MM-dd", new Date()) < new Date()) e.expiry = "This card has already expired.";
  return e;
}

export function AddCardForm() {
  const user = useApp((s) => s.user);
  const cards = useApp((s) => s.cards);
  const addCard = useApp((s) => s.addCard);
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState<Errors>({});
  const [loading, setLoading] = useState(false);
  const [shake, setShake] = useState(0);

  const set = (k: keyof typeof EMPTY) => (v: string) => {
    setForm((f) => ({ ...f, [k]: v }));
    if (errors[k]) setErrors((e) => ({ ...e, [k]: undefined }));
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const errs = validate(form);
    setErrors(errs);
    if (Object.keys(errs).length) {
      setShake((n) => n + 1);
      return;
    }
    setLoading(true);
    await wait(800);
    const digits = form.number.replace(/\D/g, "");
    const card = addCard({
      holder: user.name,
      nameOnCard: form.name.trim(),
      validThru: format(parse(form.expiry, "yyyy-MM-dd", new Date()), "MM/yy"),
      number: `${digits.slice(0, 4)} **** **** ${digits.slice(-4)}`,
      variant: TYPE_VARIANT[form.type],
      type: cards.length ? "Secondary" : "Primary",
    });
    setLoading(false);
    setForm(EMPTY);
    toast.success("Card added", { description: `${form.type} card ending ${card.number.slice(-4)} is now in My Cards.` });
  };

  return (
    <Panel hover={false} className="h-full px-[20px] pt-[14px] pb-[20px] lg:pt-[19px] lg:pb-[25px] xl:px-[30px] xl:pt-[27px] xl:pb-[38px]">
      <p className="text-[12px] leading-[22px] text-bd-muted xl:max-w-[633px] xl:text-[16px] xl:leading-[28px]">
        Credit Card generally means a plastic card issued by Scheduled Commercial Banks assigned to a Cardholder, with a credit
        limit, that can be used to purchase goods and services on credit or obtain cash advances.
      </p>

      <Shake shakeKey={shake}>
      <form onSubmit={onSubmit} noValidate className="mt-[15px] xl:mt-[29px]">
        <div className="grid gap-y-[16px] lg:grid-cols-2 lg:gap-x-[25px] lg:gap-y-[12px] xl:gap-x-[30px] xl:gap-y-[22px]">
          <Field error={errors.type}>
            <Label htmlFor="card-type" className={labelCls}>Card Type</Label>
            <SelectField id="card-type" value={form.type} onValueChange={set("type")} options={TYPE_OPTIONS} placeholder="Classic" invalid={!!errors.type} className="text-bd-primary" />
          </Field>
          <Field error={errors.name}>
            <Label htmlFor="card-name" className={labelCls}>Name On Card</Label>
            <TextInput id="card-name" placeholder="My Cards" autoComplete="cc-name" value={form.name} onChange={(e) => set("name")(e.target.value)} invalid={!!errors.name} />
          </Field>
          <Field error={errors.number}>
            <Label htmlFor="card-number" className={labelCls}>Card Number</Label>
            <TextInput
              id="card-number"
              inputMode="numeric"
              autoComplete="cc-number"
              placeholder="**** **** **** ****"
              value={form.number}
              onChange={(e) => set("number")(formatCardNumber(e.target.value))}
              invalid={!!errors.number}
            />
          </Field>
          <Field error={errors.expiry}>
            <Label htmlFor="card-expiry" className={labelCls}>Expiration Date</Label>
            <DatePicker
              id="card-expiry"
              value={form.expiry}
              onChange={set("expiry")}
              placeholder="25 January 2025"
              fromYear={new Date().getFullYear()}
              toYear={new Date().getFullYear() + 10}
              disabled={(d) => d < new Date()}
              invalid={!!errors.expiry}
            />
          </Field>
        </div>

        <div className="mt-[20px] flex flex-col gap-[10px] lg:flex-row lg:items-center lg:gap-[16px] xl:mt-[30px]">
          <motion.button
            type="submit"
            disabled={loading}
            whileHover={{ y: -2, boxShadow: "0 10px 20px -8px rgba(24,20,243,0.55)" }}
            whileTap={{ scale: 0.97 }}
            className="flex h-[40px] w-full items-center justify-center gap-[8px] rounded-[9px] bg-bd-royal text-[15px] font-medium text-white disabled:opacity-70 lg:w-[120px] xl:h-[50px] xl:w-[160px] xl:text-[18px]"
          >
            {loading && <Spinner />}
            {loading ? "Adding" : "Add Card"}
          </motion.button>
        </div>
      </form>
      </Shake>
    </Panel>
  );
}
