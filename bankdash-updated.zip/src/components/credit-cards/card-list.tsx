"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CreditCardIcon } from "@/components/icons";
import { listContainer, listItem } from "@/components/shared/motion";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";
import { CardDetailsDialog } from "./card-details-dialog";
import { LIST_TINTS, shortNumber } from "./card-utils";

function Field({ label, value, className }: { label: string; value: string; className?: string }) {
  return (
    <div className={cn("min-w-0 whitespace-nowrap", className)}>
      <p className="text-[14px] leading-[17px] font-medium text-bd-text lg:text-[12px] lg:leading-[15px] xl:text-[16px] xl:leading-[19px]">
        {label}
      </p>
      <p className="mt-[4px] text-[12px] leading-[15px] text-bd-muted lg:mt-[3px] xl:mt-[7px] xl:text-[15px] xl:leading-[18px]">
        {value}
      </p>
    </div>
  );
}

export function CardList() {
  const cards = useApp((s) => s.cards);
  const [openId, setOpenId] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const show = (id: string) => {
    setOpenId(id);
    setOpen(true);
  };

  return (
    <>
      <motion.ul variants={listContainer} initial="hidden" animate="show" className="flex flex-col gap-[10px] lg:gap-[12px] xl:gap-[20px]">
        <AnimatePresence>
          {cards.map((c, i) => {
            const tint = LIST_TINTS[i % LIST_TINTS.length];
            return (
              <motion.li
                key={c.id}
                layout
                variants={listItem}
                exit={{ opacity: 0, x: 24, transition: { duration: 0.2 } }}
                whileHover={{ y: -2, boxShadow: "0 10px 24px -14px rgba(52,60,106,0.25)" }}
                onClick={() => show(c.id)}
                className={cn(
                  "grid h-[69px] cursor-pointer items-center rounded-[10px] bg-bd-surface px-[12px] lg:rounded-[15px] xl:h-[90px] xl:rounded-[20px] xl:px-[15px]",
                  "grid-cols-[45px_minmax(0,109fr)_minmax(0,79fr)_auto]",
                  "lg:grid-cols-[45px_minmax(0,90fr)_minmax(0,71fr)_minmax(0,101fr)_minmax(0,87fr)_auto]",
                  "xl:grid-cols-[60px_minmax(0,137fr)_minmax(0,113fr)_minmax(0,153fr)_minmax(0,133fr)_auto]",
                  c.blocked && "opacity-70",
                )}
              >
                <span className={cn("relative flex size-[45px] items-center justify-center rounded-[12px] lg:rounded-[15px] xl:size-[60px] xl:rounded-[20px]", tint.bg, tint.fg)}>
                  <CreditCardIcon className="size-[20px] xl:size-[26px]" />
                  {c.blocked && <span className="absolute -top-[3px] -right-[3px] size-[10px] rounded-full border-2 border-bd-surface bg-bd-red" aria-label="Blocked" />}
                </span>
                <Field label="Card Type" value={c.type} className="pl-[12px] xl:pl-[15px]" />
                <Field label="Bank" value={c.bank} />
                <Field label="Card Number" value={shortNumber(c)} className="hidden lg:block" />
                <Field label="Namain Card" value={c.nameOnCard} className="hidden lg:block" />
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    show(c.id);
                  }}
                  className="pr-[2px] text-[11px] font-medium whitespace-nowrap text-bd-royal transition-opacity hover:opacity-70 lg:pr-[3px] xl:pr-[20px] xl:text-[15px]"
                >
                  View Details
                </button>
              </motion.li>
            );
          })}
        </AnimatePresence>
      </motion.ul>
      <CardDetailsDialog cardId={openId} open={open} onOpenChange={setOpen} />
    </>
  );
}
