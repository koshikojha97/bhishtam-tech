"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { BankCard } from "@/components/shared/bank-card";
import { money, useApp } from "@/lib/store";
import { cn } from "@/lib/utils";
import { BlockedOverlay, CardDetailsDialog } from "./card-details-dialog";
import { last4, slotStyle } from "./card-utils";

/**
 * Figma "My Cards": three cards in a grid on tablet/desktop, a snap carousel on mobile.
 * With more than three cards the tablet/desktop row becomes a horizontal scroller whose
 * items keep exactly the grid's column width, so the first three look identical.
 */
export function MyCards() {
  const cards = useApp((s) => s.cards);
  const [openId, setOpenId] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const show = (id: string) => {
    setOpenId(id);
    setOpen(true);
  };
  const scroller = useRef<HTMLDivElement>(null);
  const prevLen = useRef(cards.length);
  const many = cards.length > 3;

  useEffect(() => {
    if (cards.length > prevLen.current) {
      const el = scroller.current;
      setTimeout(() => el?.scrollTo({ left: el.scrollWidth, behavior: "smooth" }), 150);
    }
    prevLen.current = cards.length;
  }, [cards.length]);

  const scrollBy = (dir: 1 | -1) => {
    const el = scroller.current;
    if (el) el.scrollBy({ left: dir * (el.clientWidth / 3 + 20), behavior: "smooth" });
  };

  return (
    <div className="relative">
      <div
        ref={scroller}
        className={cn(
          "no-scrollbar -mx-[25px] flex snap-x scroll-px-[25px] gap-[20px] overflow-x-auto px-[25px] lg:mx-0 lg:gap-[25px] lg:px-0 xl:gap-[30px]",
          many ? "lg:-my-[10px] lg:scroll-px-0 lg:py-[10px]" : "lg:grid lg:grid-cols-3 lg:overflow-visible",
        )}
      >
        <AnimatePresence initial={false} mode="popLayout">
          {cards.map((c, i) => {
            const s = slotStyle(c, i);
            return (
              <motion.div
                key={c.id}
                layout
                initial={{ opacity: 0, scale: 0.85, x: 40 }}
                animate={{ opacity: 1, scale: 1, x: 0 }}
                exit={{ opacity: 0, scale: 0.85 }}
                transition={{ type: "spring", stiffness: 260, damping: 26 }}
                role="button"
                tabIndex={0}
                aria-label={`View details of ${c.bank} card ending ${last4(c)}${c.blocked ? " (blocked)" : ""}`}
                onClick={() => show(c.id)}
                onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), show(c.id))}
                className={cn(
                  "relative w-[265px] shrink-0 cursor-pointer snap-start rounded-[15px] outline-none focus-visible:ring-[3px] focus-visible:ring-bd-royal/30 lg:w-auto xl:rounded-[25px]",
                  many && "lg:w-[calc((100%-50px)/3)] xl:w-[calc((100%-60px)/3)]",
                )}
              >
                <BankCard
                  card={{ balance: money(c.balance), holder: c.holder, validThru: c.validThru, number: c.number, variant: s.variant }}
                  className={`xl:h-[225px] [&_p]:whitespace-nowrap lg:max-xl:[&_div]:min-w-0 ${s.className ?? ""}`}
                />
                <BlockedOverlay show={c.blocked} />
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {many && (
        <>
          <button
            type="button"
            aria-label="Previous cards"
            onClick={() => scrollBy(-1)}
            className="absolute top-1/2 -left-[14px] z-20 hidden size-[34px] -translate-y-1/2 items-center justify-center rounded-full bg-bd-surface text-bd-primary shadow-[0_6px_16px_-6px_rgba(52,60,106,0.4)] transition-colors hover:text-bd-royal lg:flex"
          >
            <ChevronLeft className="size-[18px]" />
          </button>
          <button
            type="button"
            aria-label="Next cards"
            onClick={() => scrollBy(1)}
            className="absolute top-1/2 -right-[14px] z-20 hidden size-[34px] -translate-y-1/2 items-center justify-center rounded-full bg-bd-surface text-bd-primary shadow-[0_6px_16px_-6px_rgba(52,60,106,0.4)] transition-colors hover:text-bd-royal lg:flex"
          >
            <ChevronRight className="size-[18px]" />
          </button>
        </>
      )}

      <CardDetailsDialog cardId={openId} open={open} onOpenChange={setOpen} />
    </div>
  );
}
