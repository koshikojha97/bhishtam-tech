"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Panel } from "@/components/shared/section";
import { SettingDialogs, type SettingAction } from "./card-setting-dialogs";
import { listContainer, listItem } from "@/components/shared/motion";
import { cn } from "@/lib/utils";
import { AppleIcon, BlockCardIcon, GoogleIcon, PadlockIcon } from "./icons";

/**
 * Copy differs per Figma frame (desktop says "Change Pin Code / Choose another pin code",
 * tablet & mobile say "Change Pic Code / Withdraw without any card") — kept verbatim.
 */
const ITEMS: {
  key: SettingAction;
  title: string;
  titleXl?: string;
  sub: string;
  subXl?: string;
  icon: (p: React.SVGProps<SVGSVGElement>) => React.ReactNode;
  bg: string;
  fg: string;
}[] = [
  { key: "block", title: "Block Card", sub: "Instantly block your card", icon: BlockCardIcon, bg: "bg-bd-tint-yellow", fg: "text-[#FFBB38]" },
  {
    key: "pin",
    title: "Change Pic Code",
    titleXl: "Change Pin Code",
    sub: "Withdraw without any card",
    subXl: "Choose another pin code",
    icon: PadlockIcon,
    bg: "bg-bd-tint-blue",
    fg: "text-[#396AFF]",
  },
  { key: "google", title: "Add to Google Pay", sub: "Withdraw without any card", icon: GoogleIcon, bg: "bg-bd-tint-pink", fg: "text-[#FF82AC]" },
  { key: "apple", title: "Add to Apple Pay", sub: "Withdraw without any card", icon: AppleIcon, bg: "bg-bd-tint-teal", fg: "text-[#16DBCC]" },
  { key: "appleStore", title: "Add to Apple Store", sub: "Withdraw without any card", icon: AppleIcon, bg: "bg-bd-tint-teal", fg: "text-[#16DBCC]" },
];

function Responsive({ base, xl }: { base: string; xl?: string }) {
  if (!xl) return <>{base}</>;
  return (
    <>
      <span className="xl:hidden">{base}</span>
      <span className="hidden xl:inline">{xl}</span>
    </>
  );
}

export function CardSetting() {
  const [action, setAction] = useState<SettingAction | null>(null);
  return (
    <Panel className="h-full p-[20px] lg:px-[18px] lg:py-[20px] xl:p-[30px]">
      <motion.ul variants={listContainer} initial="hidden" animate="show" className="flex flex-col gap-[15px] lg:gap-[14px] xl:gap-[20px]">
        {ITEMS.map((it) => (
          <motion.li key={it.title} variants={listItem}>
            <motion.button
              type="button"
              onClick={() => setAction(it.key)}
              whileHover={{ x: 4 }}
              whileTap={{ scale: 0.98 }}
              className="group flex w-full items-center gap-[12px] text-left lg:gap-[10px] xl:gap-[20px]"
            >
              <span
                className={cn(
                  "flex size-[45px] shrink-0 items-center justify-center rounded-[12px] transition-transform group-hover:scale-105 lg:rounded-[15px] xl:size-[60px] xl:rounded-[20px]",
                  it.bg,
                  it.fg,
                )}
              >
                <it.icon className="size-[20px] xl:size-[25px]" />
              </span>
              <span className="min-w-0">
                <span className="block text-[14px] leading-[17px] font-medium text-bd-text lg:text-[12px] lg:leading-[15px] xl:text-[16px] xl:leading-[19px]">
                  <Responsive base={it.title} xl={it.titleXl} />
                </span>
                <span className="mt-[4px] block text-[12px] leading-[15px] text-bd-muted lg:text-[11px] lg:leading-[13px] xl:mt-[7px] xl:text-[15px] xl:leading-[18px]">
                  <Responsive base={it.sub} xl={it.subXl} />
                </span>
              </span>
            </motion.button>
          </motion.li>
        ))}
      </motion.ul>
      <SettingDialogs action={action} onClose={() => setAction(null)} />
    </Panel>
  );
}
