"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Pie, PieChart, Sector, type PieSectorDataItem } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { Panel } from "@/components/shared/section";

/**
 * Figma "Group 346": four 90° wedges with different radii (rose-chart style),
 * a darker inner ring and a white hole. Radii measured from the desktop render
 * (box radius 100 → teal 100, blue 87, orange 79, pink 71, ring 48, hole 34).
 * Order is clockwise from 12 o'clock.
 */
const data = [
  { key: "abm", label: "ABM Bank", value: 25, fill: "#16DBCC", ring: "#1EC6B8", r: 1 },
  { key: "brc", label: "BRC Bank", value: 25, fill: "#FF82AC", ring: "#FF6195", r: 0.71 },
  { key: "mcp", label: "MCP Bank", value: 25, fill: "#FFBB38", ring: "#FFB11F", r: 0.79 },
  { key: "dbl", label: "DBL Bank", value: 25, fill: "#4C78FF", ring: "#3464F3", r: 0.87 },
];

const legend = [
  { key: "dbl", label: "DBL Bank", color: "#4C78FF" },
  { key: "brc", label: "BRC Bank", color: "#FF82AC" },
  { key: "abm", label: "ABM Bank", color: "#16DBCC" },
  { key: "mcp", label: "MCP Bank", color: "#FFBB38" },
];

const config = {
  abm: { label: "ABM Bank", color: "#16DBCC" },
  brc: { label: "BRC Bank", color: "#FF82AC" },
  mcp: { label: "MCP Bank", color: "#FFBB38" },
  dbl: { label: "DBL Bank", color: "#4C78FF" },
} satisfies ChartConfig;

type Datum = (typeof data)[number] & { hidden?: boolean };

function Wedge(props: PieSectorDataItem & { isActive?: boolean }) {
  const { cx, cy, outerRadius = 0, startAngle, endAngle, payload, isActive } = props;
  const p = payload as Datum;
  const r = outerRadius * p.r * (isActive ? 1.04 : 1);
  return (
    <Sector
      cx={cx}
      cy={cy}
      innerRadius={0}
      outerRadius={r}
      startAngle={startAngle}
      endAngle={endAngle}
      fill={p.fill}
      style={{ transition: "all .3s ease", opacity: p.hidden ? 0 : 1 }}
    />
  );
}

function RingWedge(props: PieSectorDataItem) {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, payload } = props;
  return (
    <Sector
      cx={cx}
      cy={cy}
      innerRadius={innerRadius}
      outerRadius={outerRadius}
      startAngle={startAngle}
      endAngle={endAngle}
      fill={(payload as Datum).ring}
      style={{ transition: "opacity .3s ease", opacity: (payload as Datum).hidden ? 0 : 1 }}
    />
  );
}

export function CardExpenseStatistics() {
  const [hidden, setHidden] = useState<string[]>([]);
  const toggle = (key: string) => setHidden((h) => (h.includes(key) ? h.filter((k) => k !== key) : [...h, key]));
  // Hidden slices keep their angle (rose-chart quadrants) but fade out.
  const shown = data.map((d) => ({ ...d, hidden: hidden.includes(d.key) }));
  return (
    <Panel className="flex h-full flex-col items-center px-[20px] pt-[20px] pb-[19px] lg:pb-[19px] xl:pt-[30px] xl:pb-[28px]">
      <ChartContainer
        config={config}
        className="aspect-square size-[213px] shrink-0 drop-shadow-[0_6px_10px_rgba(0,0,0,0.12)] lg:size-[150px] xl:size-[200px]"
      >
        <PieChart margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
          <ChartTooltip content={<ChartTooltipContent nameKey="key" hideLabel />} />
          <Pie
            data={shown}
            dataKey="value"
            nameKey="key"
            startAngle={90}
            endAngle={-270}
            outerRadius="100%"
            stroke="none"
            isAnimationActive
            animationDuration={1100}
            shape={Wedge}
          />
          <Pie
            data={shown}
            dataKey="value"
            nameKey="key"
            startAngle={90}
            endAngle={-270}
            innerRadius="34%"
            outerRadius="48%"
            stroke="none"
            isAnimationActive
            animationDuration={1100}
            shape={RingWedge}
          />
          <Pie
            data={[{ key: "hole", value: 1 }]}
            dataKey="value"
            outerRadius="34.5%"
            fill="#fff"
            stroke="none"
            isAnimationActive={false}
            tooltipType="none"
          />
        </PieChart>
      </ChartContainer>

      <motion.ul
        initial="hidden"
        animate="show"
        variants={{ hidden: {}, show: { transition: { staggerChildren: 0.08, delayChildren: 0.6 } } }}
        className="mt-[6px] grid grid-cols-[98px_auto] gap-y-[12px] lg:mt-0 xl:mt-[2px] xl:grid-cols-[149px_auto] xl:gap-y-[14px] xl:self-start xl:pl-[30px]"
      >
        {legend.map((l) => {
          const off = hidden.includes(l.key);
          return (
            <motion.li key={l.label} variants={{ hidden: { opacity: 0, y: 6 }, show: { opacity: 1, y: 0 } }}>
              <button
                type="button"
                aria-pressed={!off}
                title={off ? `Show ${l.label}` : `Hide ${l.label}`}
                onClick={() => toggle(l.key)}
                className={`flex items-center gap-[10px] text-left text-[12px] leading-[15px] font-medium text-bd-muted transition-opacity hover:text-bd-primary xl:gap-[12px] xl:text-[15px] xl:leading-[18px] ${off ? "line-through opacity-45" : ""}`}
              >
                <span
                  className="size-[12px] shrink-0 rounded-full border-2 transition-colors xl:size-[15px]"
                  style={{ background: off ? "transparent" : l.color, borderColor: l.color }}
                />
                {l.label}
              </button>
            </motion.li>
          );
        })}
      </motion.ul>
    </Panel>
  );
}
