"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";
import { REGEXP_ONLY_DIGITS } from "input-otp";
import { Check } from "lucide-react";
import { Field, SelectField } from "@/components/shared/form-controls";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Label } from "@/components/ui/label";
import { useApp, type Card } from "@/lib/store";
import { cn } from "@/lib/utils";
import { cardOptions, last4 } from "./card-utils";
import { BdDialog, ConfirmDialog, Shake, Spinner, dangerBtn, outlineBtn, primaryBtn, wait } from "./dialog-kit";

export type SettingAction = "block" | "pin" | "google" | "apple" | "appleStore";

const labelCls = "text-[13px] font-normal text-bd-text xl:text-[15px]";

function StatusChip({ ok, okText, noText }: { ok: boolean; okText: string; noText: string }) {
  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.span
        key={String(ok)}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className={cn(
          "inline-flex items-center gap-[5px] rounded-full px-[12px] py-[4px] text-[12px] font-medium xl:text-[13px]",
          ok ? "bg-bd-tint-teal text-[#16A99E]" : "bg-bd-page text-bd-muted",
        )}
      >
        {ok && <Check className="size-[13px]" />}
        {ok ? okText : noText}
      </motion.span>
    </AnimatePresence>
  );
}

/** Keeps the chosen card id valid even if cards change. */
function useCardChoice(cards: Card[], preferUnblocked = false) {
  const [id, setId] = useState("");
  const card = cards.find((c) => c.id === id) ?? (preferUnblocked ? cards.find((c) => !c.blocked) : undefined) ?? cards[0];
  return [card, setId] as const;
}

function CardPicker({ cards, card, onChange }: { cards: Card[]; card?: Card; onChange: (id: string) => void }) {
  return (
    <Field>
      <Label htmlFor="setting-card" className={labelCls}>
        Choose card
      </Label>
      <SelectField id="setting-card" value={card?.id ?? ""} onValueChange={onChange} options={cardOptions(cards)} placeholder="Select a card" className="text-bd-primary" />
    </Field>
  );
}

function NoCards() {
  return <p className="text-[14px] text-bd-muted">You don&apos;t have any cards yet. Add one with the form on this page.</p>;
}

/* ---------------- Block card ---------------- */
function BlockDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const cards = useApp((s) => s.cards);
  const updateCard = useApp((s) => s.updateCard);
  const notify = useApp((s) => s.notify);
  const [card, setId] = useCardChoice(cards);
  const [confirm, setConfirm] = useState(false);

  const apply = () => {
    if (!card) return;
    const blocked = !card.blocked;
    updateCard(card.id, { blocked });
    const title = blocked ? "Card blocked" : "Card unblocked";
    const body = `${card.bank} card ending ${last4(card)} was ${blocked ? "blocked" : "unblocked"}`;
    notify({ title, body, kind: "card", href: "/credit-cards" });
    toast.success(title, { description: body });
    onClose();
  };

  return (
    <>
      <BdDialog open={open} onOpenChange={(v) => !v && onClose()} title="Block Card" description="Instantly stop all payments and withdrawals on a card. You can unblock it any time.">
        {card ? (
          <div className="grid gap-[18px]">
            <CardPicker cards={cards} card={card} onChange={setId} />
            <div className="flex items-center justify-between">
              <span className="text-[13px] text-bd-muted xl:text-[14px]">Current status</span>
              <StatusChip ok={!card.blocked} okText="Active" noText="Blocked" />
            </div>
            <button type="button" className={card.blocked ? primaryBtn : dangerBtn} onClick={() => setConfirm(true)}>
              {card.blocked ? "Unblock card" : "Block card"}
            </button>
          </div>
        ) : (
          <NoCards />
        )}
      </BdDialog>
      {card && (
        <ConfirmDialog
          open={confirm}
          onOpenChange={setConfirm}
          title={card.blocked ? "Unblock this card?" : "Block this card?"}
          description={
            card.blocked
              ? `The ${card.bank} card ending ${last4(card)} will work again for payments and withdrawals.`
              : `All payments and withdrawals on the ${card.bank} card ending ${last4(card)} will be declined until you unblock it.`
          }
          confirmLabel={card.blocked ? "Unblock card" : "Block card"}
          destructive={!card.blocked}
          onConfirm={apply}
        />
      )}
    </>
  );
}

/* ---------------- Change PIN ---------------- */
function PinInput({ id, value, onChange, invalid }: { id: string; value: string; onChange: (v: string) => void; invalid?: boolean }) {
  return (
    <InputOTP id={id} maxLength={4} pattern={REGEXP_ONLY_DIGITS} value={value} onChange={onChange} inputMode="numeric">
      <InputOTPGroup className="gap-[10px]">
        {[0, 1, 2, 3].map((i) => (
          <InputOTPSlot
            key={i}
            index={i}
            aria-invalid={invalid || undefined}
            className="size-[50px] rounded-[12px] border border-bd-card-border text-[20px] font-semibold text-bd-primary shadow-none [-webkit-text-security:disc] first:rounded-[12px] first:border-l last:rounded-[12px] data-[active=true]:border-bd-royal data-[active=true]:ring-bd-royal/15 aria-invalid:border-bd-red"
          />
        ))}
      </InputOTPGroup>
    </InputOTP>
  );
}

function PinDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const cards = useApp((s) => s.cards);
  const updateCard = useApp((s) => s.updateCard);
  const notify = useApp((s) => s.notify);
  const [card, setId] = useCardChoice(cards);
  const [pin, setPin] = useState("");
  const [again, setAgain] = useState("");
  const [errors, setErrors] = useState<{ pin?: string; again?: string }>({});
  const [loading, setLoading] = useState(false);
  const [shake, setShake] = useState(0);

  const reset = () => {
    setPin("");
    setAgain("");
    setErrors({});
  };

  const save = async () => {
    if (!card) return;
    const e: typeof errors = {};
    if (pin.length !== 4) e.pin = "Enter a 4-digit PIN.";
    else if (/^(\d)\1{3}$/.test(pin) || "0123456789".includes(pin) || "9876543210".includes(pin)) e.pin = "Avoid repeated or sequential digits.";
    if (!e.pin && again !== pin) e.again = "PINs don't match.";
    setErrors(e);
    if (e.pin || e.again) {
      setShake((n) => n + 1);
      return;
    }
    setLoading(true);
    await wait(800);
    updateCard(card.id, { pin });
    setLoading(false);
    const body = `The PIN for your ${card.bank} card ending ${last4(card)} was changed`;
    notify({ title: "Card PIN changed", body, kind: "security", href: "/credit-cards" });
    toast.success("PIN updated", { description: body });
    reset();
    onClose();
  };

  return (
    <BdDialog
      open={open}
      onOpenChange={(v) => {
        if (!v) {
          reset();
          onClose();
        }
      }}
      title="Change Pin Code"
      description="Choose a new 4-digit PIN for ATM withdrawals and in-store payments."
    >
      {card ? (
        <Shake shakeKey={shake} className="grid gap-[18px]">
          <CardPicker cards={cards} card={card} onChange={setId} />
          <Field error={errors.pin}>
            <Label htmlFor="pin-new" className={labelCls}>
              New PIN
            </Label>
            <PinInput id="pin-new" value={pin} onChange={(v) => (setPin(v), setErrors({}))} invalid={!!errors.pin} />
          </Field>
          <Field error={errors.again}>
            <Label htmlFor="pin-again" className={labelCls}>
              Confirm new PIN
            </Label>
            <PinInput id="pin-again" value={again} onChange={(v) => (setAgain(v), setErrors((x) => ({ ...x, again: undefined })))} invalid={!!errors.again} />
          </Field>
          <div className="flex justify-end gap-[10px]">
            <button type="button" className={outlineBtn} onClick={() => (reset(), onClose())}>
              Cancel
            </button>
            <button type="button" className={primaryBtn} disabled={loading} onClick={save}>
              {loading && <Spinner />}
              {loading ? "Saving" : "Save PIN"}
            </button>
          </div>
        </Shake>
      ) : (
        <NoCards />
      )}
    </BdDialog>
  );
}

/* ---------------- Wallets ---------------- */
const WALLETS = {
  google: { name: "Google Pay", key: "google" },
  apple: { name: "Apple Pay", key: "apple" },
  appleStore: { name: "Apple Store", key: "appleStore" },
} as const;

function WalletDialog({ kind, open, onClose }: { kind: keyof typeof WALLETS; open: boolean; onClose: () => void }) {
  const cards = useApp((s) => s.cards);
  const updateCard = useApp((s) => s.updateCard);
  const notify = useApp((s) => s.notify);
  const [card, setId] = useCardChoice(cards, true);
  const [loading, setLoading] = useState(false);
  const w = WALLETS[kind];
  const added = !!card?.wallets[w.key];

  const toggle = async () => {
    if (!card) return;
    setLoading(true);
    await wait(700);
    const next = !added;
    updateCard(card.id, { wallets: { ...card.wallets, [w.key]: next } });
    setLoading(false);
    const title = next ? `Added to ${w.name}` : `Removed from ${w.name}`;
    const body = `${card.bank} card ending ${last4(card)} ${next ? "is now available in" : "was removed from"} ${w.name}`;
    notify({ title, body, kind: "card", href: "/credit-cards" });
    toast.success(title, { description: body });
  };

  return (
    <BdDialog open={open} onOpenChange={(v) => !v && onClose()} title={`Add to ${w.name}`} description={`Pay with your phone — no physical card needed. Pick a card to add to ${w.name}.`}>
      {card ? (
        <div className="grid gap-[18px]">
          <CardPicker cards={cards} card={card} onChange={setId} />
          <div className="flex items-center justify-between">
            <span className="text-[13px] text-bd-muted xl:text-[14px]">{w.name}</span>
            <StatusChip ok={added} okText="Added" noText="Not added" />
          </div>
          {card.blocked && !added && <p className="text-[12px] text-bd-red xl:text-[13px]">Blocked cards can&apos;t be added to a wallet. Unblock it first.</p>}
          <div className="flex justify-end gap-[10px]">
            {added && (
              <button type="button" className={outlineBtn} disabled={loading} onClick={toggle}>
                {loading && <Spinner />} Remove
              </button>
            )}
            <button
              type="button"
              className={cn(primaryBtn, added && "bg-bd-green disabled:opacity-100")}
              disabled={loading || (card.blocked && !added) || added}
              onClick={toggle}
            >
              {added ? <Check className="size-[16px]" /> : loading ? <Spinner /> : null}
              {added ? "Added" : loading ? "Adding" : `Add to ${w.name}`}
            </button>
          </div>
        </div>
      ) : (
        <NoCards />
      )}
    </BdDialog>
  );
}

export function SettingDialogs({ action, onClose }: { action: SettingAction | null; onClose: () => void }) {
  return (
    <>
      <BlockDialog open={action === "block"} onClose={onClose} />
      <PinDialog open={action === "pin"} onClose={onClose} />
      <WalletDialog kind="google" open={action === "google"} onClose={onClose} />
      <WalletDialog kind="apple" open={action === "apple"} onClose={onClose} />
      <WalletDialog kind="appleStore" open={action === "appleStore"} onClose={onClose} />
    </>
  );
}
