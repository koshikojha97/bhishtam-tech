"use client";

import { useState } from "react";
import { Bar, BarChart, Cell, LabelList, XAxis, YAxis } from "recharts";
import { ChartContainer, type ChartConfig } from "@/components/ui/chart";
import { Panel } from "@/components/shared/section";
import { useBreakpoint } from "@/hooks/use-breakpoint";

/** Bar heights from Figma (Aug 93 · Sep 142 · Oct 96 · Nov 49 · Dec 129 · Jan 88), scaled so Dec = $12,500. */
const data = [
  { month: "Aug", value: 9010 },
  { month: "Sep", value: 13760 },
  { month: "Oct", value: 9300 },
  { month: "Nov", value: 4750 },
  { month: "Dec", value: 12500 },
  { month: "Jan", value: 8530 },
];

const config = { value: { label: "Expense", color: "#16DBCC" } } satisfies ChartConfig;

const SIZES = {
  xl: { bar: 37, radius: 10, margin: -7, axis: 29, tickMargin: 8, tick: 13, label: 14, labelGap: 10 },
  lg: { bar: 22, radius: 6, margin: -6, axis: 25, tickMargin: 5, tick: 12, label: 12, labelGap: 4 },
  sm: { bar: 35, radius: 8, margin: -7, axis: 28, tickMargin: 8, tick: 12, label: 13, labelGap: 8 },
} as const;

export function MyExpense() {
  const bp = useBreakpoint();
  const s = SIZES[bp];
  const [active, setActive] = useState(4);

  return (
    <Panel className="px-[20px] pt-[17px] pb-[16px] lg:px-[18px] lg:pb-[11px] xl:px-[25px] xl:pt-[22px] xl:pb-[21px]">
      <ChartContainer config={config} className="aspect-auto h-[181px] w-full lg:h-[142px] xl:h-[182px]">
        <BarChart
          data={data}
          margin={{ left: s.margin, right: s.margin, top: 0, bottom: 0 }}
          onMouseLeave={() => setActive(4)}
        >
          <XAxis
            dataKey="month"
            interval={0}
            tickLine={false}
            axisLine={false}
            height={s.axis}
            tickMargin={s.tickMargin}
            tick={{ fill: "var(--color-bd-muted)", fontSize: s.tick }}
          />
          <YAxis hide domain={[0, (max: number) => (max * 153) / 142]} />
          <Bar
            dataKey="value"
            barSize={s.bar}
            radius={s.radius}
            animationDuration={900}
            onMouseEnter={(_, i) => setActive(i)}
            className="cursor-pointer"
          >
            {data.map((d, i) => (
              <Cell
                key={d.month}
                fill={i === active ? "#16DBCC" : "#EDF0F7"}
                style={{
                  transition: "fill 250ms ease",
                  filter: i === active ? "drop-shadow(0 0 17px rgba(18,136,126,0.25))" : undefined,
                }}
              />
            ))}
            <LabelList
              dataKey="value"
              content={(props) => {
                const { x, y, width, index, value } = props as { x: number; y: number; width: number; index: number; value: number };
                if (index !== active) return null;
                return (
                  <text
                    x={x + width / 2}
                    y={y - s.labelGap}
                    textAnchor="middle"
                    fill="#343C6A"
                    fontSize={s.label}
                    fontWeight={500}
                  >
                    ${value.toLocaleString("en-US")}
                  </text>
                );
              }}
            />
          </Bar>
        </BarChart>
      </ChartContainer>
    </Panel>
  );
}
