"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Panel } from "@/components/shared/section";
import { listContainer, listItem } from "@/components/shared/motion";
import { cn } from "@/lib/utils";
import { useApp, type Transaction } from "@/lib/store";
import { ArrowCircleIcon } from "./icons";
import { Pagination } from "./pagination";
import { TxDetailDialog, downloadReceipt, fmtTxDate } from "./tx-shared";

/** Extra local demo history appended after the store's transactions so tabs + pagination have something to do. */
const DEMO_HISTORY: Transaction[] = (
  [
    ["Netflix Premium", "#12548721", "Shopping", "1234 ****", "2021-01-12T21:15:00", -320],
    ["Upwork Payout", "#12548702", "Transfer", "3778 ****", "2021-01-10T11:20:00", 2150],
    ["Electricity Bill", "#12548688", "Service", "1234 ****", "2021-01-08T18:45:00", -210],
    ["Jemi Wilson", "#12548674", "Transfer", "3778 ****", "2021-01-06T14:10:00", 5400],
    ["Amazon Order", "#12548659", "Shopping", "1234 ****", "2021-01-05T20:05:00", -680],
    ["Dribbble Sales", "#12548641", "Transfer", "3778 ****", "2021-01-03T10:30:00", 1120],
    ["Internet Service", "#12548633", "Service", "1234 ****", "2021-01-02T16:40:00", -95],
    ["Apple Store", "#12548617", "Shopping", "1234 ****", "2020-12-30T13:15:00", -450],
    ["Randy Press", "#12548602", "Transfer", "3778 ****", "2020-12-28T19:55:00", 900],
    ["Gym Membership", "#12548590", "Service", "1234 ****", "2020-12-26T09:00:00", -60],
    ["Livia Bator", "#12548577", "Transfer", "3778 ****", "2020-12-24T17:25:00", 1300],
    ["Playstation", "#12548563", "Shopping", "1234 ****", "2020-12-22T11:40:00", -1085],
    ["Envato Sales", "#12548549", "Transfer", "3778 ****", "2020-12-20T15:35:00", 640],
    ["Water Bill", "#12548531", "Service", "1234 ****", "2020-12-18T10:10:00", -45],
    ["Workman", "#12548518", "Transfer", "3778 ****", "2020-12-16T18:20:00", 780],
  ] as const
).map(([description, txId, type, card, date, amount], i) => ({ id: `demo-${i}`, description, txId, type, card, date, amount }));

const TABS = [
  { key: "all", label: "All Transactions" },
  { key: "income", label: "Income" },
  { key: "expense", label: "Expense" },
] as const;
type TabKey = (typeof TABS)[number]["key"];

const PER_PAGE = 5;

/** Figma writes amounts like "-$2,500", "+$750", "-$1050" (no comma under 10k except the first) — keep that style. */
function formatAmount(n: number) {
  const abs = Math.abs(n);
  const s = abs >= 2000 ? abs.toLocaleString("en-US") : String(abs);
  return `${n < 0 ? "-" : "+"}$${s}`;
}

const COLS =
  "lg:grid-cols-[minmax(0,165fr)_minmax(0,104fr)_minmax(0,76fr)_minmax(0,83fr)_minmax(0,125fr)_minmax(0,70fr)_80px] " +
  "xl:grid-cols-[minmax(0,231fr)_minmax(0,154fr)_minmax(0,125fr)_minmax(0,134fr)_minmax(0,198fr)_minmax(0,108fr)_100px]";

export function RecentTransactions() {
  const [tab, setTab] = useState<TabKey>("all");
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState<Transaction | null>(null);
  const storeTx = useApp((s) => s.transactions);

  const filtered = useMemo(() => {
    const all = [...storeTx].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).concat(DEMO_HISTORY);
    return all.filter((t) => (tab === "all" ? true : tab === "income" ? t.amount > 0 : t.amount < 0));
  }, [tab, storeTx]);
  const pages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const safePage = Math.min(page, pages);
  const rows = filtered.slice((safePage - 1) * PER_PAGE, safePage * PER_PAGE);
  const listKey = `${tab}-${safePage}`;

  return (
    <div className="flex flex-col">
      {/* Tabs */}
      <div
        role="tablist"
        className="flex justify-between border-b border-bd-border lg:justify-start lg:gap-[40px] xl:mt-[7px] xl:gap-[60px]"
      >
        {TABS.map((t) => {
          const active = t.key === tab;
          return (
            <button
              key={t.key}
              role="tab"
              aria-selected={active}
              onClick={() => {
                setTab(t.key);
                setPage(1);
              }}
              className={cn(
                "relative -mb-px px-[10px] pb-[7px] text-[13px] font-medium transition-colors lg:pb-[6px] xl:px-[11px] xl:pb-[8px] xl:text-[16px]",
                active ? "text-bd-royal" : "text-bd-muted hover:text-bd-primary",
              )}
            >
              {t.label}
              {active && (
                <motion.span
                  layoutId="tx-tab-underline"
                  transition={{ type: "spring", stiffness: 420, damping: 34 }}
                  className="absolute inset-x-0 bottom-0 h-[2px] rounded-t-[10px] bg-bd-royal lg:h-[3px]"
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Table / list */}
      <Panel
        hover={false}
        className="mt-[16px] px-[20px] pt-[9px] pb-[10px] lg:mt-[20px] lg:px-[20px] lg:pt-[17px] lg:pb-[7px] xl:mt-[25px] xl:px-[30px] xl:pt-[22px] xl:pb-[15px]"
      >
        {/* header — tablet/desktop only */}
        <div
          className={cn(
            "hidden border-b border-bd-border pb-[7px] text-[12px] font-medium text-bd-muted lg:grid xl:pb-[11px] xl:text-[16px]",
            COLS,
          )}
        >
          <span>Description</span>
          <span>Transaction ID</span>
          <span>Type</span>
          <span>Card</span>
          <span>Date</span>
          <span>Amount</span>
          <span>Receipt</span>
        </div>

        <AnimatePresence mode="wait" initial={false}>
          <motion.ul
            key={listKey}
            variants={listContainer}
            initial="hidden"
            animate="show"
            exit={{ opacity: 0, transition: { duration: 0.15 } }}
          >
            {rows.map((t) => {
              const positive = t.amount > 0;
              return (
                <motion.li
                  key={t.id}
                  variants={listItem}
                  className="border-b border-bd-border last:border-b-0"
                >
                  {/* Mobile row */}
                  <button
                    type="button"
                    onClick={() => setOpen(t)}
                    className="flex w-full items-center gap-[12px] py-[10px] text-left outline-none focus-visible:ring-[3px] focus-visible:ring-bd-royal/20 lg:hidden"
                  >
                    <ArrowCircleIcon direction={positive ? "down" : "up"} className="size-[35px] shrink-0 text-bd-muted" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] leading-[16px] font-medium text-bd-text">{t.description}</p>
                      <p className="mt-[5px] text-[12px] leading-[15px] text-bd-muted">{fmtTxDate(t.date)}</p>
                    </div>
                    <p className={cn("shrink-0 text-[13px] font-medium", positive ? "text-[#16DBAA]" : "text-bd-pink")}>
                      {formatAmount(t.amount)}
                    </p>
                  </button>

                  {/* Tablet / desktop row */}
                  <motion.div
                    onClick={() => setOpen(t)}
                    whileHover={{ backgroundColor: "rgba(245,247,250,0.9)" }}
                    className={cn(
                      "-mx-[8px] hidden cursor-pointer items-center rounded-[10px] px-[8px] py-[8px] text-[12px] text-bd-text lg:grid xl:py-[15px] xl:text-[16px]",
                      COLS,
                    )}
                  >
                    <span className="flex min-w-0 items-center gap-[10px] xl:gap-[14px]">
                      <ArrowCircleIcon direction={positive ? "down" : "up"} className="size-[20px] shrink-0 text-bd-muted xl:size-[30px]" />
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setOpen(t);
                        }}
                        className="truncate rounded-[4px] text-left outline-none focus-visible:ring-[3px] focus-visible:ring-bd-royal/20"
                      >
                        {t.description}
                      </button>
                    </span>
                    <span className="truncate">{t.txId}</span>
                    <span className="truncate">{t.type}</span>
                    <span className="truncate">{t.card}</span>
                    <span className="truncate">{fmtTxDate(t.date)}</span>
                    <span className={cn("font-medium", positive ? "text-[#16DBAA]" : "text-bd-pink")}>{formatAmount(t.amount)}</span>
                    <motion.button
                      type="button"
                      aria-label={`Download receipt for ${t.description}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        downloadReceipt(t);
                      }}
                      whileHover={{ scale: 1.04 }}
                      whileTap={{ scale: 0.96 }}
                      className="h-[30px] w-[80px] rounded-[50px] border border-bd-primary text-[12px] text-bd-primary transition-colors hover:border-bd-royal hover:bg-bd-royal hover:text-white xl:h-[35px] xl:w-[100px] xl:text-[15px]"
                    >
                      Download
                    </motion.button>
                  </motion.div>
                </motion.li>
              );
            })}
          </motion.ul>
        </AnimatePresence>
      </Panel>

      <TxDetailDialog tx={open} onOpenChange={(o) => !o && setOpen(null)} />
      <Pagination page={safePage} pages={pages} onChange={setPage} className="mt-[16px] lg:mt-[20px] xl:mt-[30px]" />
    </div>
  );
}
