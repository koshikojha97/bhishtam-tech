import type { SVGProps } from "react";

/** Thin outlined circle with an arrow — "Group 73" in Figma. Up = money out, down = money in. */
export function ArrowCircleIcon({ direction = "up", ...p }: SVGProps<SVGSVGElement> & { direction?: "up" | "down" }) {
  return (
    <svg width={30} height={30} viewBox="0 0 30 30" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" {...p}>
      <circle cx="15" cy="15" r="14.25" />
      <g transform={direction === "down" ? "rotate(180 15 15)" : undefined}>
        <path d="M15 21.5V8.5" />
        <path d="M10 13.5 15 8.5l5 5" />
      </g>
    </svg>
  );
}

export function ChevronIcon({ direction = "right", ...p }: SVGProps<SVGSVGElement> & { direction?: "left" | "right" }) {
  return (
    <svg width={7} height={12} viewBox="0 0 7 12" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d={direction === "right" ? "M1 1l5 5-5 5" : "M6 1 1 6l5 5"} />
    </svg>
  );
}
