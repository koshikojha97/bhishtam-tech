"use client";

import { format } from "date-fns";
import { motion } from "framer-motion";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { downloadFile, receiptHtml } from "@/lib/download";
import { money, type Transaction } from "@/lib/store";
import { cn } from "@/lib/utils";

/** Shared BankDash dialog styling (white, radius 20–25, 22px title). */
export const dialogBox = "rounded-[20px] border-none bg-bd-surface p-[24px] text-bd-text sm:max-w-[440px] xl:rounded-[25px] xl:p-[30px]";
export const dialogTitle = "text-[20px] font-semibold text-bd-primary xl:text-[22px]";
export const primaryBtn = "h-[44px] rounded-[12px] bg-bd-royal px-[24px] text-[15px] font-medium text-white hover:bg-bd-royal/90";
export const ghostBtn = "h-[44px] rounded-[12px] border border-bd-card-border bg-bd-surface px-[24px] text-[15px] font-medium text-bd-primary hover:bg-bd-input";

export const fmtTxDate = (iso: string, pattern = "dd MMM, hh.mm a") => {
  const d = new Date(iso);
  return isNaN(d.getTime()) ? iso : format(d, pattern);
};

export function downloadReceipt(t: Transaction) {
  const html = receiptHtml(`Transaction receipt ${t.txId}`, [
    ["Description", t.description],
    ["Transaction ID", t.txId],
    ["Type", t.type],
    ["Card", t.card],
    ["Date", fmtTxDate(t.date, "dd MMM yyyy, hh:mm a")],
    ["Amount", money(t.amount, true)],
    ["Status", "Completed"],
  ]);
  downloadFile(`receipt-${t.txId.replace("#", "")}.html`, html, "text/html;charset=utf-8");
}

export function TxDetailDialog({ tx, onOpenChange }: { tx: Transaction | null; onOpenChange: (open: boolean) => void }) {
  return (
    <Dialog open={!!tx} onOpenChange={onOpenChange}>
      <DialogContent className={dialogBox}>
        {tx && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }} className="flex flex-col gap-[18px]">
            <DialogHeader>
              <DialogTitle className={dialogTitle}>Transaction Details</DialogTitle>
              <DialogDescription className="text-[14px] text-bd-muted">{tx.description}</DialogDescription>
            </DialogHeader>
            <p className={cn("text-[28px] font-semibold", tx.amount > 0 ? "text-bd-green" : "text-bd-red")}>{money(tx.amount, true)}</p>
            <dl className="divide-y divide-bd-border text-[14px]">
              {(
                [
                  ["Transaction ID", tx.txId],
                  ["Type", tx.type],
                  ["Card", tx.card],
                  ["Date", fmtTxDate(tx.date, "dd MMM yyyy, hh:mm a")],
                  ["Status", "Completed"],
                ] as const
              ).map(([k, v]) => (
                <div key={k} className="flex justify-between gap-4 py-[10px]">
                  <dt className="text-bd-muted">{k}</dt>
                  <dd className="font-medium text-bd-primary">{v}</dd>
                </div>
              ))}
            </dl>
            <DialogFooter className="gap-[10px]">
              <Button variant="outline" className={ghostBtn} onClick={() => onOpenChange(false)}>
                Close
              </Button>
              <Button className={primaryBtn} onClick={() => downloadReceipt(tx)}>
                Download receipt
              </Button>
            </DialogFooter>
          </motion.div>
        )}
      </DialogContent>
    </Dialog>
  );
}
