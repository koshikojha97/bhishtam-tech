"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { ChevronIcon } from "./icons";

export function Pagination({
  page,
  pages,
  onChange,
  className,
}: {
  page: number;
  pages: number;
  onChange: (p: number) => void;
  className?: string;
}) {
  const btn =
    "flex items-center gap-[10px] text-[12px] font-medium text-bd-royal transition-opacity disabled:cursor-default xl:gap-[13px] xl:text-[15px]";
  return (
    <nav aria-label="Pagination" className={cn("flex items-center justify-end", className)}>
      <button className={cn(btn, "mr-[10px] xl:mr-[12px]")} disabled={page === 1} onClick={() => onChange(page - 1)}>
        <ChevronIcon direction="left" className="h-[10px] w-[6px] xl:h-[12px] xl:w-[7px]" />
        Previous
      </button>
      {Array.from({ length: pages }, (_, i) => i + 1).map((p) => {
        const active = p === page;
        return (
          <button
            key={p}
            aria-current={active ? "page" : undefined}
            onClick={() => onChange(p)}
            className={cn(
              "relative flex size-[30px] items-center justify-center text-[12px] font-medium transition-colors xl:h-[40px] xl:w-[37px] xl:text-[15px]",
              active ? "text-white" : "text-bd-royal hover:text-bd-blue",
            )}
          >
            {active && (
              <motion.span
                layoutId="tx-page-active"
                transition={{ type: "spring", stiffness: 420, damping: 34 }}
                className="absolute inset-0 rounded-[8px] bg-bd-royal xl:-inset-x-[1.5px] xl:rounded-[10px]"
              />
            )}
            <span className="relative">{p}</span>
          </button>
        );
      })}
      <button className={cn(btn, "ml-[22px] xl:ml-[29px]")} disabled={page === pages} onClick={() => onChange(page + 1)}>
        Next
        <ChevronIcon direction="right" className="h-[10px] w-[6px] xl:h-[12px] xl:w-[7px]" />
      </button>
    </nav>
  );
}
