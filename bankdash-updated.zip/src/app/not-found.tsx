import Link from "next/link";
import { Logo } from "@/components/shared/logo";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-[20px] bg-bd-page px-[25px] text-center">
      <Logo />
      <p className="text-[80px] leading-none font-bold text-bd-royal">404</p>
      <p className="text-[16px] text-bd-muted">This page doesn&apos;t exist.</p>
      <Link href="/" className="rounded-[15px] bg-bd-royal px-[30px] py-[14px] text-[16px] font-medium text-white">
        Back to Dashboard
      </Link>
    </div>
  );
}
