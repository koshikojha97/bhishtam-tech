import type { Metadata } from "next";
import { AuthShell } from "@/components/auth/auth-shell";
import { SignupForm } from "@/components/auth/signup-form";

export const metadata: Metadata = { title: "Sign Up" };

export default function SignupPage() {
  return (
    <AuthShell title="Create your account" subtitle="Start managing cards, transactions and investments in one place.">
      <SignupForm />
    </AuthShell>
  );
}
