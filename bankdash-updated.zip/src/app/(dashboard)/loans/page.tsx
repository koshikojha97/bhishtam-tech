import type { Metadata } from "next";
import { Stagger } from "@/components/shared/motion";
import { Section } from "@/components/shared/section";
import { LoanStats } from "@/components/loans/loan-stats";
import { LoansTable } from "@/components/loans/loans-table";

export const metadata: Metadata = { title: "Loans" };

export default function LoansPage() {
  return (
    // Mobile Figma puts white cards on the #F5F7FA page colour, so bleed the grey under the content below lg.
    <Stagger className="-mx-[25px] -mt-[20px] -mb-[30px] flex flex-col gap-[22px] min-h-[calc(100svh-140px)] bg-bd-page px-[25px] pt-[25px] pb-[43px] lg:m-0 lg:min-h-0 lg:gap-[20px] lg:bg-transparent lg:p-0 xl:gap-[24px]">
      <LoanStats />
      <Section title="Active Loans Overview">
        <LoansTable />
      </Section>
    </Stagger>
  );
}
