"use client";

import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { CheckCircle2, Lock } from "lucide-react";
import { Panel } from "@/components/shared/section";
import { CreditCardIcon, InvestmentIcon, LoanIcon, PrivilegeIcon } from "@/components/icons";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { BdDialog, ConfirmDialog, outlineBtn, primaryBtn } from "@/components/credit-cards/dialog-kit";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";

type Status = "Active" | "Eligible" | "Locked";

const PERKS = [
  {
    id: "cashback",
    title: "Cashback Rewards",
    desc: "Earn up to 5% back on card spend",
    icon: CreditCardIcon,
    bg: "bg-bd-tint-blue",
    fg: "text-[#396AFF]",
    status: "Active" as Status,
    benefits: ["5% back on groceries and fuel", "1% back on everything else", "Cashback credited monthly"],
    usage: "Earned $42.50 this month",
    requirement: "",
  },
  {
    id: "loans",
    title: "Priority Loans",
    desc: "Pre-approved rates from 6.5%",
    icon: LoanIcon,
    bg: "bg-bd-tint-pink",
    fg: "text-[#FF82AC]",
    status: "Eligible" as Status,
    benefits: ["Pre-approved up to $50,000", "Rates from 6.5% APR", "Same-day disbursement"],
    usage: "No loans taken with this privilege yet",
    requirement: "",
  },
  {
    id: "advisory",
    title: "Investment Advisory",
    desc: "Free monthly portfolio review",
    icon: InvestmentIcon,
    bg: "bg-bd-tint-teal",
    fg: "text-bd-teal",
    status: "Active" as Status,
    benefits: ["Monthly 30-minute review call", "Personalised rebalancing tips", "Quarterly market outlook report"],
    usage: "Next review: first Monday of next month",
    requirement: "",
  },
  {
    id: "lounge",
    title: "Lounge Access",
    desc: "4 complimentary visits per year",
    icon: PrivilegeIcon,
    bg: "bg-bd-tint-yellow",
    fg: "text-bd-orange",
    status: "Locked" as Status,
    benefits: [],
    usage: "",
    requirement: "Unlocks when you hold a Platinum card or spend $25,000 on cards within 12 months.",
  },
];
type Perk = (typeof PERKS)[number];

const chipCls = "shrink-0 rounded-[50px] border px-[14px] py-[6px] text-[12px] font-medium transition-colors xl:px-[20px] xl:text-[15px]";

function LockedChip({ perk }: { perk: Perk }) {
  const [open, setOpen] = useState(false);
  // Touch: Radix closes on click and on the pointerleave that follows a tap — ignore closes right after a tap.
  const tapAt = useRef(0);
  return (
    <Tooltip open={open} onOpenChange={(v) => (v || Date.now() - tapAt.current > 400) && setOpen(v)}>
      <TooltipTrigger asChild>
        <button
          type="button"
          onClick={(e) => {
            e.preventDefault(); // stop Radix closing on click so a tap opens it (tap outside closes)
            tapAt.current = Date.now();
            setOpen(true);
          }}
          aria-label={`${perk.title} is locked: ${perk.requirement}`}
          className={cn(chipCls, "inline-flex items-center gap-[6px] border-bd-card-border text-bd-muted hover:border-bd-muted")}
        >
          <Lock className="size-[12px] xl:size-[14px]" />
          Locked
        </button>
      </TooltipTrigger>
      <TooltipContent side="top" sideOffset={6} collisionPadding={12} className="max-w-[240px] rounded-[10px] bg-bd-primary px-[12px] py-[8px] text-[12px] leading-[17px] text-white [&_svg]:bg-bd-primary [&_svg]:fill-bd-primary">
        {perk.requirement}
      </TooltipContent>
    </Tooltip>
  );
}

export function PrivilegesList() {
  const notify = useApp((s) => s.notify);
  const [status, setStatus] = useState<Record<string, Status>>(() => Object.fromEntries(PERKS.map((p) => [p.id, p.status])));
  const [alerts, setAlerts] = useState<Record<string, boolean>>({ cashback: true, loans: true, advisory: false });
  const [manageId, setManageId] = useState<string>(PERKS[0].id);
  const [manageOpen, setManageOpen] = useState(false);
  const [activateId, setActivateId] = useState<string>(PERKS[1].id);
  const [activateOpen, setActivateOpen] = useState(false);
  const [deactivate, setDeactivate] = useState(false);

  const manage = PERKS.find((p) => p.id === manageId)!;
  const activate = PERKS.find((p) => p.id === activateId);

  const doActivate = () => {
    if (!activate) return;
    setStatus((s) => ({ ...s, [activate.id]: "Active" }));
    notify({ title: "Privilege activated", body: `${activate.title} is now active on your account`, kind: "info", href: "/privileges" });
    toast.success(`${activate.title} activated`, { description: activate.desc });
  };

  const doDeactivate = () => {
    setStatus((s) => ({ ...s, [manage.id]: "Eligible" }));
    setManageOpen(false);
    notify({ title: "Privilege deactivated", body: `${manage.title} was turned off. You can re-activate it any time.`, kind: "info", href: "/privileges" });
    toast.success(`${manage.title} deactivated`);
  };

  return (
    <>
      <div className="grid gap-[15px] sm:grid-cols-2 xl:gap-[30px]">
        {PERKS.map((p) => {
          const st = status[p.id];
          return (
            <Panel key={p.title} className="flex items-center gap-[15px] p-[20px] xl:gap-[20px] xl:p-[25px]">
              <span className={`flex size-[50px] shrink-0 items-center justify-center rounded-full xl:size-[70px] ${p.bg} ${p.fg}`}>
                <p.icon className="size-[22px] xl:size-[30px]" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-bd-text xl:text-[16px]">{p.title}</p>
                <p className="mt-[4px] text-[12px] text-bd-muted xl:text-[15px]">{p.desc}</p>
              </div>
              {st === "Locked" ? (
                <LockedChip perk={p} />
              ) : (
                <motion.button
                  key={st}
                  type="button"
                  initial={{ scale: 0.85, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    if (st === "Active") {
                      setManageId(p.id);
                      setManageOpen(true);
                    } else {
                      setActivateId(p.id);
                      setActivateOpen(true);
                    }
                  }}
                  title={st === "Active" ? `Manage ${p.title}` : `Activate ${p.title}`}
                  className={cn(chipCls, "border-bd-royal text-bd-royal hover:bg-bd-royal hover:text-white")}
                >
                  {st}
                </motion.button>
              )}
            </Panel>
          );
        })}
      </div>

      <BdDialog open={manageOpen} onOpenChange={setManageOpen} title={`Manage ${manage.title}`} description={manage.desc}>
        <div className="grid gap-[16px]">
          <ul className="grid gap-[10px]">
            {manage.benefits.map((b) => (
              <li key={b} className="flex items-center gap-[10px] text-[13px] text-bd-primary xl:text-[15px]">
                <CheckCircle2 className="size-[18px] shrink-0 text-bd-teal" />
                {b}
              </li>
            ))}
          </ul>
          <p className="rounded-[12px] bg-bd-page px-[14px] py-[10px] text-[13px] text-bd-muted xl:text-[14px]">{manage.usage}</p>
          <div className="flex items-center justify-between gap-[12px]">
            <Label htmlFor="perk-alerts" className="cursor-pointer text-[13px] font-normal text-bd-text xl:text-[15px]">
              Notify me about this privilege
            </Label>
            <Switch
              id="perk-alerts"
              checked={!!alerts[manage.id]}
              onCheckedChange={(v) => {
                setAlerts((a) => ({ ...a, [manage.id]: v }));
                toast.success(v ? "Alerts turned on" : "Alerts turned off", { description: manage.title });
              }}
              className="cursor-pointer data-[state=checked]:bg-bd-teal data-[state=unchecked]:bg-bd-card-border"
            />
          </div>
          <div className="mt-[4px] flex justify-end gap-[10px]">
            <button type="button" className={outlineBtn} onClick={() => setDeactivate(true)}>
              Deactivate
            </button>
            <button type="button" className={primaryBtn} onClick={() => setManageOpen(false)}>
              Done
            </button>
          </div>
        </div>
      </BdDialog>

      <ConfirmDialog
        open={deactivate}
        onOpenChange={setDeactivate}
        title={`Deactivate ${manage.title}?`}
        description="You'll stop receiving this benefit straight away. You can activate it again at any time."
        confirmLabel="Deactivate"
        destructive
        onConfirm={doDeactivate}
      />

      <ConfirmDialog
        open={activateOpen}
        onOpenChange={setActivateOpen}
        title={`Activate ${activate?.title ?? ""}?`}
        description={activate ? `${activate.desc}. ${activate.benefits.join(" · ")}.` : ""}
        confirmLabel="Activate"
        onConfirm={doActivate}
      />
    </>
  );
}
