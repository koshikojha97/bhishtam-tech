import type { Metadata } from "next";
import { Stagger } from "@/components/shared/motion";
import { Section } from "@/components/shared/section";
import { PrivilegesList } from "./privileges-list";

export const metadata: Metadata = { title: "My Privileges" };

/* Not in the Figma file — built from the same components/tokens so the nav item isn't a dead link. */
export default function PrivilegesPage() {
  return (
    <Stagger className="flex flex-col gap-[22px] xl:gap-[24px]">
      <Section title="My Privileges">
        <PrivilegesList />
      </Section>
    </Stagger>
  );
}
