import type { Metadata } from "next";
import { Stagger } from "@/components/shared/motion";
import { Section } from "@/components/shared/section";
import { MyCards } from "@/components/dashboard/my-cards";
import { RecentTransactions } from "@/components/dashboard/recent-transactions";
import { WeeklyActivity } from "@/components/dashboard/weekly-activity";
import { ExpenseStatistics } from "@/components/dashboard/expense-statistics";
import { QuickTransfer } from "@/components/dashboard/quick-transfer";
import { BalanceHistory } from "@/components/dashboard/balance-history";

export const metadata: Metadata = { title: "Dashboard" };

export default function DashboardPage() {
  return (
    <Stagger className="-mx-[25px] -mt-[20px] -mb-[30px] flex flex-col gap-[22px] bg-bd-surface px-[25px] pt-[20px] pb-[30px] lg:m-0 lg:gap-[20px] lg:bg-transparent lg:p-0 xl:gap-[24px]">
      {/* Row 1 — My Cards + Recent Transaction */}
      <div className="grid gap-[22px] lg:grid-cols-[minmax(0,73fr)_minmax(0,35fr)] lg:gap-[25px] xl:gap-[30px]">
        <Section title="My Cards" action="See All" actionHref="/credit-cards">
          <MyCards />
        </Section>
        <Section title="Recent Transaction">
          <RecentTransactions />
        </Section>
      </div>

      {/* Row 2 — Weekly Activity + Expense Statistics */}
      <div className="grid gap-[22px] lg:grid-cols-[minmax(0,73fr)_minmax(0,35fr)] lg:gap-[25px] xl:gap-[30px]">
        <Section title="Weekly Activity">
          <WeeklyActivity />
        </Section>
        <Section title="Expense Statistics">
          <ExpenseStatistics />
        </Section>
      </div>

      {/* Row 3 — Quick Transfer + Balance History */}
      <div className="grid gap-[22px] lg:grid-cols-[minmax(0,445fr)_minmax(0,635fr)] lg:gap-[25px] xl:gap-[30px]">
        <Section id="quick-transfer" title="Quick Transfer">
          <QuickTransfer />
        </Section>
        <Section title="Balance History">
          <BalanceHistory />
        </Section>
      </div>
    </Stagger>
  );
}
