import type { Metadata } from "next";
import { Stagger, FadeUp } from "@/components/shared/motion";
import { Section } from "@/components/shared/section";
import { MyCard } from "@/components/accounts/my-card";
import { StatCards } from "@/components/accounts/stat-cards";
import { LastTransaction } from "@/components/accounts/last-transaction";
import { DebitCreditOverview } from "@/components/accounts/debit-credit-overview";
import { InvoicesSent } from "@/components/accounts/invoices-sent";

export const metadata: Metadata = { title: "Accounts" };

const ROW = "grid gap-[22px] lg:grid-cols-[minmax(0,487fr)_minmax(0,231fr)] lg:gap-[25px] xl:grid-cols-[minmax(0,730fr)_minmax(0,350fr)] xl:gap-[30px]";

export default function AccountsPage() {
  return (
    <Stagger className="flex flex-col gap-[22px] lg:gap-[20px] xl:gap-[23px]">
      <FadeUp>
        <StatCards />
      </FadeUp>

      {/* Row 2 — Last Transaction + My Card */}
      <div className={ROW}>
        <Section title="Last Transaction">
          <LastTransaction />
        </Section>
        <Section title="My Card" action="See All" actionHref="/credit-cards">
          <MyCard />
        </Section>
      </div>

      {/* Row 3 — Debit & Credit Overview + Invoices Sent */}
      <div className={ROW}>
        <DebitCreditOverview />
        <Section title="Invoices Sent">
          <InvoicesSent />
        </Section>
      </div>
    </Stagger>
  );
}
