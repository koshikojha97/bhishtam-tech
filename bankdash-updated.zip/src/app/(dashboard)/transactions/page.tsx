import type { Metadata } from "next";
import { Stagger } from "@/components/shared/motion";
import { Section } from "@/components/shared/section";
import { MyCards } from "@/components/dashboard/my-cards";
import { MyExpense } from "@/components/transactions/my-expense";
import { RecentTransactions } from "@/components/transactions/recent-transactions";

export const metadata: Metadata = { title: "Transactions" };

export default function TransactionsPage() {
  return (
    <Stagger className="flex flex-col gap-[22px] lg:gap-[20px] xl:gap-[24px]">
      {/* Row 1 — My Cards + My Expense */}
      <div className="grid gap-[22px] lg:grid-cols-[minmax(0,487fr)_minmax(0,231fr)] lg:gap-[25px] xl:grid-cols-[minmax(0,730fr)_minmax(0,350fr)] xl:gap-[30px]">
        <Section title="My Cards" action="+ Add Card" actionHref="/credit-cards#add-card">
          <MyCards cardClassName="xl:h-[225px]" />
        </Section>
        <Section title="My Expense">
          <MyExpense />
        </Section>
      </div>

      {/* Row 2 — Recent Transactions */}
      <Section title="Recent Transactions">
        <RecentTransactions />
      </Section>
    </Stagger>
  );
}
