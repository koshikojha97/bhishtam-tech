import type { Metadata } from "next";
import { FadeUp, Stagger } from "@/components/shared/motion";
import { Section } from "@/components/shared/section";
import { ServiceHighlights } from "@/components/services/service-highlights";
import { ServicesList } from "@/components/services/services-list";

export const metadata: Metadata = { title: "Services" };

export default function ServicesPage() {
  return (
    <Stagger className="flex flex-col gap-[22px] lg:gap-[20px] xl:gap-[24px]">
      <FadeUp className="mt-[5px] lg:mt-[1px] xl:mt-[6px]">
        <ServiceHighlights />
      </FadeUp>

      <Section title="Bank Services List">
        {/* Figma spacing heading→list: 12 / 16 / 28px vs Section's 15 / 18 / 20px */}
        <div className="-mt-[3px] lg:-mt-[2px] xl:mt-[8px]">
          <ServicesList />
        </div>
      </Section>
    </Stagger>
  );
}
