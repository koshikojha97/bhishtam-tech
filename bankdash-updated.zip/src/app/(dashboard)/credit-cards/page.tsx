import type { Metadata } from "next";
import { Stagger } from "@/components/shared/motion";
import { Section } from "@/components/shared/section";
import { MyCards } from "@/components/credit-cards/my-cards";
import { CardExpenseStatistics } from "@/components/credit-cards/card-expense-statistics";
import { CardList } from "@/components/credit-cards/card-list";
import { AddCardForm } from "@/components/credit-cards/add-card-form";
import { CardSetting } from "@/components/credit-cards/card-setting";

export const metadata: Metadata = { title: "Credit Cards" };

export default function CreditCardsPage() {
  return (
    <Stagger className="flex flex-col gap-[22px] lg:gap-[20px] xl:gap-[24px]">
      {/* Row 1 — My Cards */}
      <Section title="My Cards">
        <MyCards />
      </Section>

      {/* Row 2 — Card Expense Statistics + Card List */}
      <div className="grid gap-[22px] lg:grid-cols-[minmax(0,231fr)_minmax(0,487fr)] lg:gap-[25px] xl:grid-cols-[minmax(0,350fr)_minmax(0,730fr)] xl:gap-[30px]">
        <Section title="Card Expense Statistics">
          <CardExpenseStatistics />
        </Section>
        <Section title="Card List">
          <CardList />
        </Section>
      </div>

      {/* Row 3 — Add New Card + Card Setting */}
      <div className="grid gap-[22px] lg:grid-cols-[minmax(0,487fr)_minmax(0,231fr)] lg:gap-[25px] xl:grid-cols-[minmax(0,730fr)_minmax(0,350fr)] xl:gap-[30px]">
        {/* id target for deep links (/credit-cards#add-card); grid wrapper keeps the panel full-height */}
        <div id="add-card" className="grid min-w-0 scroll-mt-[110px]">
          <Section title="Add New Card">
            <AddCardForm />
          </Section>
        </div>
        <Section title="Card Setting">
          <CardSetting />
        </Section>
      </div>
    </Stagger>
  );
}
