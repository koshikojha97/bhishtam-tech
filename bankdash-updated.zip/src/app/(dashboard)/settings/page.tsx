import type { Metadata } from "next";
import { Suspense } from "react";
import { FadeUp, Stagger } from "@/components/shared/motion";
import { SettingsTabs } from "@/components/settings/settings-tabs";

export const metadata: Metadata = { title: "Setting" };

export default function SettingsPage() {
  return (
    // Mobile frame shows the white card on the #F5F7FA page background, so paint it here (layout is white < lg).
    <div className="-mx-[25px] -mt-[20px] -mb-[30px] min-h-[calc(100dvh-140px)] bg-bd-page px-[25px] pt-[25px] pb-[25px] lg:m-0 lg:min-h-0 lg:bg-transparent lg:p-0">
      <Stagger>
        <FadeUp>
          <Suspense fallback={<div className="h-[600px] rounded-[15px] bg-bd-surface lg:rounded-[20px] xl:rounded-[25px]" />}>
            <SettingsTabs />
          </Suspense>
        </FadeUp>
      </Stagger>
    </div>
  );
}
