import type { Metadata } from "next";
import { Stagger } from "@/components/shared/motion";
import { Section } from "@/components/shared/section";
import { InvestmentStats } from "@/components/investments/investment-stats";
import { MonthlyRevenueChart, YearlyInvestmentChart } from "@/components/investments/investment-charts";
import { MyInvestments } from "@/components/investments/my-investments";
import { TrendingStock } from "@/components/investments/trending-stock";

export const metadata: Metadata = { title: "Investments" };

export default function InvestmentsPage() {
  return (
    // Mobile Figma puts white cards on the #F5F7FA page colour, so bleed the grey under the content below lg.
    <Stagger className="-mx-[25px] -mt-[20px] -mb-[30px] flex flex-col gap-[22px] min-h-[calc(100svh-140px)] bg-bd-page px-[25px] pt-[25px] pb-[25px] lg:m-0 lg:min-h-0 lg:gap-[20px] lg:bg-transparent lg:p-0 xl:gap-[24px]">
      <InvestmentStats />

      <div className="grid gap-[22px] lg:grid-cols-2 lg:gap-[25px] xl:gap-[30px]">
        <YearlyInvestmentChart />
        <Section title="Monthly Revenue">
          <MonthlyRevenueChart />
        </Section>
      </div>

      <div className="grid gap-[22px] lg:grid-cols-[minmax(0,423fr)_minmax(0,295fr)] lg:gap-[25px] xl:grid-cols-[minmax(0,635fr)_minmax(0,445fr)] xl:gap-[30px]">
        <Section title="My Investment">
          <MyInvestments />
        </Section>
        <Section title="Trending Stock">
          <TrendingStock />
        </Section>
      </div>
    </Stagger>
  );
}
