"use client";

/**
 * App-wide client state (Zustand + localStorage persistence).
 * Replace the actions' bodies with API calls when wiring a real backend.
 *
 * Hydration: `skipHydration: true` keeps the first client render identical to SSR;
 * <StoreHydrator/> (in the root layout) rehydrates from localStorage after mount.
 */
import { create } from "zustand";
import { persist } from "zustand/middleware";

export type CardVariant = "blue" | "white" | "dark" | "lightBlue";

export interface Card {
  id: string;
  balance: number;
  holder: string;
  validThru: string; // MM/YY
  number: string; // masked display, e.g. "3778 **** **** 1234"
  variant: CardVariant;
  bank: string;
  type: "Primary" | "Secondary";
  nameOnCard: string;
  blocked: boolean;
  pin?: string;
  wallets: { google: boolean; apple: boolean; appleStore?: boolean };
}

export type TxType = "Shopping" | "Transfer" | "Service" | "Deposit";

export interface Transaction {
  id: string;
  description: string;
  txId: string;
  type: TxType;
  card: string; // "1234 ****"
  date: string; // ISO
  amount: number; // negative = expense
}

export interface Notification {
  id: string;
  title: string;
  body: string;
  date: string; // ISO
  read: boolean;
  kind: "transaction" | "security" | "card" | "loan" | "info";
  href?: string;
}

export interface User {
  name: string;
  username: string;
  email: string;
  dob: string; // ISO date yyyy-mm-dd
  presentAddress: string;
  permanentAddress: string;
  city: string;
  postalCode: string;
  country: string;
  avatar: string; // url or data URL
}

export interface Preferences {
  currency: string;
  timeZone: string;
  notifyDigitalCurrency: boolean;
  notifyMerchantOrder: boolean;
  notifyRecommendations: boolean;
}

export interface Security {
  twoFactor: boolean;
  passwordUpdatedAt?: string;
}

const uid = () => Math.random().toString(36).slice(2, 10);
const daysAgo = (d: number, h = 10, m = 40) => {
  const t = new Date();
  t.setDate(t.getDate() - d);
  t.setHours(h, m, 0, 0);
  return t.toISOString();
};

const SEED_CARDS: Card[] = [
  { id: "c1", balance: 5756, holder: "Eddy Cusuma", validThru: "12/22", number: "3778 **** **** 1234", variant: "blue", bank: "DBL Bank", type: "Primary", nameOnCard: "William", blocked: false, wallets: { google: false, apple: false } },
  { id: "c2", balance: 5756, holder: "Eddy Cusuma", validThru: "12/22", number: "3778 **** **** 1234", variant: "white", bank: "BRC Bank", type: "Secondary", nameOnCard: "Michel", blocked: false, wallets: { google: false, apple: false } },
  { id: "c3", balance: 5756, holder: "Eddy Cusuma", validThru: "12/22", number: "3778 **** **** 1234", variant: "blue", bank: "ABM Bank", type: "Secondary", nameOnCard: "Edward", blocked: false, wallets: { google: false, apple: false } },
];

const SEED_TX: Transaction[] = [
  { id: "t1", description: "Spotify Subscription", txId: "#12548796", type: "Shopping", card: "1234 ****", date: "2021-01-28T00:30:00", amount: -2500 },
  { id: "t2", description: "Freepik Sales", txId: "#12548796", type: "Transfer", card: "1234 ****", date: "2021-01-25T22:40:00", amount: 750 },
  { id: "t3", description: "Mobile Service", txId: "#12548796", type: "Service", card: "1234 ****", date: "2021-01-20T22:40:00", amount: -150 },
  { id: "t4", description: "Wilson", txId: "#12548796", type: "Transfer", card: "1234 ****", date: "2021-01-15T15:29:00", amount: -1050 },
  { id: "t5", description: "Emilly", txId: "#12548796", type: "Transfer", card: "1234 ****", date: "2021-01-14T22:40:00", amount: 840 },
];

const SEED_NOTIFICATIONS: Notification[] = [
  { id: "n1", title: "Payment received", body: "Jemi Wilson sent you $5,400", date: daysAgo(0, 9, 12), read: false, kind: "transaction", href: "/transactions" },
  { id: "n2", title: "New sign-in", body: "Your account was accessed from Chrome on Windows", date: daysAgo(0, 7, 3), read: false, kind: "security", href: "/settings?tab=security" },
  { id: "n3", title: "Card payment", body: "$850 charged to card ending 1234", date: daysAgo(1), read: false, kind: "card", href: "/credit-cards" },
  { id: "n4", title: "Loan repayment due", body: "Business loan installment of $2,000 is due in 3 days", date: daysAgo(2), read: true, kind: "loan", href: "/loans" },
  { id: "n5", title: "Statement ready", body: "Your January statement is available", date: daysAgo(4), read: true, kind: "info", href: "/accounts" },
];

const SEED_USER: User = {
  name: "Charlene Reed",
  username: "Charlene Reed",
  email: "charlenereed@gmail.com",
  dob: "1990-01-25",
  presentAddress: "San Jose, California, USA",
  permanentAddress: "San Jose, California, USA",
  city: "San Jose",
  postalCode: "45962",
  country: "USA",
  avatar: "/images/avatars/settings-profile.png",
};

interface AppState {
  user: User;
  preferences: Preferences;
  security: Security;
  cards: Card[];
  transactions: Transaction[];
  notifications: Notification[];
  sidebarCollapsed: boolean;

  toggleSidebar: () => void;
  updateUser: (patch: Partial<User>) => void;
  updatePreferences: (patch: Partial<Preferences>) => void;
  updateSecurity: (patch: Partial<Security>) => void;

  addCard: (c: Omit<Card, "id" | "blocked" | "wallets" | "balance" | "variant" | "bank" | "type"> & Partial<Card>) => Card;
  updateCard: (id: string, patch: Partial<Card>) => void;
  removeCard: (id: string) => void;

  addTransaction: (t: Omit<Transaction, "id" | "txId" | "date"> & Partial<Transaction>) => Transaction;

  notify: (n: Omit<Notification, "id" | "date" | "read">) => void;
  markRead: (id: string) => void;
  markAllRead: () => void;
  removeNotification: (id: string) => void;
  clearNotifications: () => void;

  reset: () => void;
}

const seed = () => ({
  user: SEED_USER,
  preferences: {
    currency: "USD",
    timeZone: "(GMT-12:00) International Date Line West",
    notifyDigitalCurrency: true,
    notifyMerchantOrder: false,
    notifyRecommendations: true,
  },
  security: { twoFactor: true },
  cards: SEED_CARDS,
  transactions: SEED_TX,
  notifications: SEED_NOTIFICATIONS,
});

export const useApp = create<AppState>()(
  persist(
    (set, get) => ({
      ...seed(),
      sidebarCollapsed: false,

      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),

      updateUser: (patch) => set((s) => ({ user: { ...s.user, ...patch } })),
      updatePreferences: (patch) => set((s) => ({ preferences: { ...s.preferences, ...patch } })),
      updateSecurity: (patch) => set((s) => ({ security: { ...s.security, ...patch } })),

      addCard: (c) => {
        const card: Card = {
          balance: 0,
          variant: "white",
          bank: "DBL Bank",
          type: "Secondary",
          blocked: false,
          wallets: { google: false, apple: false },
          ...c,
          id: uid(),
        };
        set((s) => ({ cards: [...s.cards, card] }));
        get().notify({ title: "Card added", body: `${card.nameOnCard}'s card ending ${card.number.slice(-4)} was added`, kind: "card", href: "/credit-cards" });
        return card;
      },
      updateCard: (id, patch) => set((s) => ({ cards: s.cards.map((c) => (c.id === id ? { ...c, ...patch } : c)) })),
      removeCard: (id) => set((s) => ({ cards: s.cards.filter((c) => c.id !== id) })),

      addTransaction: (t) => {
        const tx: Transaction = {
          txId: `#${Math.floor(10000000 + Math.random() * 89999999)}`,
          date: new Date().toISOString(),
          ...t,
          id: uid(),
        };
        set((s) => ({ transactions: [tx, ...s.transactions] }));
        return tx;
      },

      notify: (n) => set((s) => ({ notifications: [{ ...n, id: uid(), date: new Date().toISOString(), read: false }, ...s.notifications] })),
      markRead: (id) => set((s) => ({ notifications: s.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)) })),
      markAllRead: () => set((s) => ({ notifications: s.notifications.map((n) => ({ ...n, read: true })) })),
      removeNotification: (id) => set((s) => ({ notifications: s.notifications.filter((n) => n.id !== id) })),
      clearNotifications: () => set({ notifications: [] }),

      reset: () => set(seed()),
    }),
    { name: "bankdash-store", version: 1, skipHydration: true },
  ),
);

/* ---------- formatting helpers ---------- */
export const money = (n: number, signed = false) =>
  `${signed ? (n < 0 ? "-" : "+") : n < 0 ? "-" : ""}$${Math.abs(n).toLocaleString("en-US")}`;

export function timeAgo(iso: string) {
  const s = Math.max(1, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return "just now";
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short" });
}

/* ---------- session (demo auth) ---------- */
export const SESSION_COOKIE = "bd_session";
export function setSession(email: string, remember: boolean) {
  const maxAge = remember ? 60 * 60 * 24 * 30 : undefined;
  document.cookie = `${SESSION_COOKIE}=${encodeURIComponent(email)}; path=/; SameSite=Lax${maxAge ? `; max-age=${maxAge}` : ""}`;
}
export function clearSession() {
  document.cookie = `${SESSION_COOKIE}=; path=/; max-age=0`;
}
