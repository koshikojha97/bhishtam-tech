/** Client-side file downloads (receipts, invoices, statements). */

export function downloadFile(filename: string, content: string, mime = "text/plain;charset=utf-8") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function toCsv(rows: Record<string, string | number>[]) {
  if (!rows.length) return "";
  const head = Object.keys(rows[0]);
  const esc = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;
  return [head.map(esc).join(","), ...rows.map((r) => head.map((h) => esc(r[h] ?? "")).join(","))].join("\n");
}

/** Printable HTML receipt — opens nicely in any browser and can be "Saved as PDF". */
export function receiptHtml(title: string, fields: [string, string][]) {
  const rows = fields.map(([k, v]) => `<tr><td>${k}</td><td>${v}</td></tr>`).join("");
  return `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
<style>body{font-family:Inter,Arial,sans-serif;color:#232323;max-width:520px;margin:40px auto;padding:0 20px}
h1{color:#343C6A;font-size:22px}.brand{color:#1814F3;font-weight:900;font-size:20px}
table{width:100%;border-collapse:collapse;margin-top:16px}td{padding:10px 0;border-bottom:1px solid #E6EFF5}
td:first-child{color:#718EBF}td:last-child{text-align:right;font-weight:500}</style></head>
<body><div class="brand">BankDash.</div><h1>${title}</h1><table>${rows}</table>
<p style="color:#718EBF;font-size:12px;margin-top:24px">Generated ${new Date().toLocaleString()}</p></body></html>`;
}
