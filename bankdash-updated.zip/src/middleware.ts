import { NextResponse, type NextRequest } from "next/server";

/**
 * Demo auth guard: dashboard routes need the `bd_session` cookie (set on Sign In / Sign Up).
 * Signed-in users visiting auth pages are sent to the dashboard.
 * Swap for NextAuth / your own session check in production.
 */
const AUTH_ROUTES = ["/login", "/signup", "/forgot-password"];

export function middleware(req: NextRequest) {
  const { pathname, search } = req.nextUrl;
  const hasSession = Boolean(req.cookies.get("bd_session")?.value);
  const isAuthRoute = AUTH_ROUTES.some((r) => pathname.startsWith(r));

  if (!hasSession && !isAuthRoute) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.search = pathname === "/" ? "" : `?next=${encodeURIComponent(pathname + search)}`;
    return NextResponse.redirect(url);
  }
  if (hasSession && (pathname.startsWith("/login") || pathname.startsWith("/signup"))) {
    return NextResponse.redirect(new URL("/", req.url));
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|images|fonts|.*\\.(?:png|jpg|jpeg|svg|webp|ico|woff2?)$).*)"],
};
